// x86_encoder.cpp - x86-64 instruction encoding
#include "assembler.h"
#include <cstring>
#include <iostream>

// Helper to get register encoding
int get_register_code(const std::string& reg) {
    if (reg == "rax" || reg == "eax" || reg == "ax" || reg == "al") return 0;
    if (reg == "rcx" || reg == "ecx" || reg == "cx" || reg == "cl") return 1;
    if (reg == "rdx" || reg == "edx" || reg == "dx" || reg == "dl") return 2;
    if (reg == "rbx" || reg == "ebx" || reg == "bx" || reg == "bl") return 3;
    if (reg == "rsp" || reg == "esp" || reg == "sp") return 4;
    if (reg == "rbp" || reg == "ebp" || reg == "bp") return 5;
    if (reg == "rsi" || reg == "esi" || reg == "si") return 6;
    if (reg == "rdi" || reg == "edi" || reg == "di") return 7;
    if (reg == "r8" || reg == "r8d") return 8;
    if (reg == "r9" || reg == "r9d") return 9;
    if (reg == "r10" || reg == "r10d") return 10;
    if (reg == "r11" || reg == "r11d") return 11;
    if (reg == "r12" || reg == "r12d") return 12;
    if (reg == "r13" || reg == "r13d") return 13;
    if (reg == "r14" || reg == "r14d") return 14;
    if (reg == "r15" || reg == "r15d") return 15;
    return -1;
}

// Check if register needs REX prefix
bool needs_rex(int reg_code) {
    return reg_code >= 8;
}

// Encode ModRM byte
uint8_t encode_modrm(int mod, int reg, int rm) {
    return ((mod & 3) << 6) | ((reg & 7) << 3) | (rm & 7);
}

// Encode SIB byte (Scale-Index-Base)
uint8_t encode_sib(int scale, int index, int base) {
    int scale_bits = 0;
    if (scale == 2) scale_bits = 1;
    else if (scale == 4) scale_bits = 2;
    else if (scale == 8) scale_bits = 3;
    
    return ((scale_bits & 3) << 6) | ((index & 7) << 3) | (base & 7);
}

// Main instruction encoder dispatch
std::vector<uint8_t> InstructionEncoder::encode(const Instruction& instr,
                                                uint64_t offset,
                                                std::vector<Relocation>& relocs,
                                                Assembler* assembler) {
    std::vector<uint8_t> code;
    
    if (instr.mnemonic == "mov") {
        code = encode_mov(instr.operands, offset);
    } else if (instr.mnemonic == "add") {
        code = encode_add(instr.operands);
    } else if (instr.mnemonic == "sub") {
        code = encode_sub(instr.operands);
    } else if (instr.mnemonic == "imul") {
        code = encode_imul(instr.operands);
    } else if (instr.mnemonic == "jmp") {
        code = encode_jmp(instr.operands, offset, relocs, assembler);
    } else if (instr.mnemonic == "call") {
        code = encode_call(instr.operands, offset, relocs, assembler);
    }
    // System-level and privileged instructions
    else if (instr.mnemonic == "cli") {  // Clear interrupt flag (ring 0 only)
        code.push_back(0xFA);
    } else if (instr.mnemonic == "sti") {  // Set interrupt flag (ring 0 only)
        code.push_back(0xFB);
    } else if (instr.mnemonic == "hlt") {  // Halt processor (ring 0 only)
        code.push_back(0xF4);
    } else if (instr.mnemonic == "lgdt") {  // Load Global Descriptor Table
        code = encode_lgdt(instr.operands);
    } else if (instr.mnemonic == "sgdt") {  // Store Global Descriptor Table
        code = encode_sgdt(instr.operands);
    } else if (instr.mnemonic == "lidt") {  // Load Interrupt Descriptor Table
        code = encode_lidt(instr.operands);
    } else if (instr.mnemonic == "sidt") {  // Store Interrupt Descriptor Table
        code = encode_sidt(instr.operands);
    } else if (instr.mnemonic == "ltr") {  // Load Task Register
        code = encode_ltr(instr.operands);
    } else if (instr.mnemonic == "str") {  // Store Task Register
        code = encode_str(instr.operands);
    } else if (instr.mnemonic == "rdmsr") {  // Read Model Specific Register
        code.push_back(0x0F);
        code.push_back(0x32);
    } else if (instr.mnemonic == "wrmsr") {  // Write Model Specific Register
        code.push_back(0x0F);
        code.push_back(0x30);
    } else if (instr.mnemonic == "rdtsc") {  // Read Time-Stamp Counter
        code.push_back(0x0F);
        code.push_back(0x31);
    } else if (instr.mnemonic == "rdpmc") {  // Read Performance Monitoring Counters
        code.push_back(0x0F);
        code.push_back(0x33);
    } else if (instr.mnemonic == "sysret") {  // Return from system call (long mode)
        code.push_back(0x48);  // REX.W
        code.push_back(0x0F);
        code.push_back(0x07);
    } else if (instr.mnemonic == "sysexit") {  // Exit system call (long mode)
        code.push_back(0x48);  // REX.W
        code.push_back(0x0F);
        code.push_back(0x35);
    } else if (instr.mnemonic == "invlpg") {  // Invalidate TLB entry
        code = encode_invlpg(instr.operands);
    } else if (instr.mnemonic == "wbinvd") {  // Write-back and invalidate cache
        code.push_back(0x0F);
        code.push_back(0x09);
    } else if (instr.mnemonic == "invpcid") {  // Invalidate Process-Context ID
        code = encode_invpcid(instr.operands);
    } else if (instr.mnemonic == "xsetbv") {  // Set extended control register
        code.push_back(0x0F);
        code.push_back(0x01);
        code.push_back(0xD1);
    } else if (instr.mnemonic == "xgetbv") {  // Get extended control register
        code.push_back(0x0F);
        code.push_back(0x01);
        code.push_back(0xD0);
    } else if (instr.mnemonic == "vmcall") {  // VM call (VMX)
        code.push_back(0x0F);
        code.push_back(0x01);
        code.push_back(0xC1);
    } else if (instr.mnemonic == "vmlaunch") {  // VM launch (VMX)
        code.push_back(0x0F);
        code.push_back(0x01);
        code.push_back(0xC2);
    } else if (instr.mnemonic == "vmresume") {  // VM resume (VMX)
        code.push_back(0x0F);
        code.push_back(0x01);
        code.push_back(0xC3);
    } else if (instr.mnemonic == "vmxoff") {  // VMX off (VMX)
        code.push_back(0x0F);
        code.push_back(0x01);
        code.push_back(0xC4);
    } else if (instr.mnemonic == "vmxon") {  // VMX on (VMX)
        code.push_back(0xF3);
        code.push_back(0x0F);
        code.push_back(0xC7);
        // Need ModR/M byte for vmxon
        if (instr.operands.size() == 1 && instr.operands[0].type == Operand::Type::MEMORY) {
            // Encode memory operand for ModR/M
            code.push_back(0x30);  // ModR/M for [rax] (just as example)
        }
    } else if (instr.mnemonic == "emms") {  // Empty MMX state
        code.push_back(0x0F);
        code.push_back(0x77);
    } else if (instr.mnemonic == "lfence") {  // Load fence
        code.push_back(0x0F);
        code.push_back(0xAE);
        code.push_back(0xE8);
    } else if (instr.mnemonic == "mfence") {  // Memory fence
        code.push_back(0x0F);
        code.push_back(0xAE);
        code.push_back(0xF0);
    } else if (instr.mnemonic == "sfence") {  // Store fence
        code.push_back(0x0F);
        code.push_back(0xAE);
        code.push_back(0xF8);
    } else if (instr.mnemonic == "ud2") {  // Undefined instruction (for debugging)
        code.push_back(0x0F);
        code.push_back(0x0B);
    }
    // ... more instructions could be added here
    
    return code;
}

// MOV implementation
std::vector<uint8_t> InstructionEncoder::encode_mov(const std::vector<Operand>& ops,
                                                   uint64_t offset) {
    std::vector<uint8_t> code;
    
    if (ops.size() != 2) return code;
    
    const Operand& dst = ops[0];
    const Operand& src = ops[1];
    
    // mov reg, imm64
    if (dst.type == Operand::Type::REGISTER && src.type == Operand::Type::IMMEDIATE) {
        int dst_reg = get_register_code(dst.reg_name);
        if (dst_reg < 0) return code;
        
        // Construct REX byte properly: 0x40 | W<<3 | R<<2 | X<<1 | B
        int rex = 0x40;
        rex |= 0x08; // W = 1 for 64-bit operand
        // For opcode B8+reg, the register extension is in B (low bit)
        if (dst_reg >= 8) rex |= 0x01; // B
        code.push_back(static_cast<uint8_t>(rex));
        
        code.push_back(0xB8 + (dst_reg & 7));  // opcode + reg
        
        // Add 64-bit immediate (little endian)
        int64_t imm = src.immediate_value;
        code.push_back((imm) & 0xFF);
        code.push_back((imm >> 8) & 0xFF);
        code.push_back((imm >> 16) & 0xFF);
        code.push_back((imm >> 24) & 0xFF);
        code.push_back((imm >> 32) & 0xFF);
        code.push_back((imm >> 40) & 0xFF);
        code.push_back((imm >> 48) & 0xFF);
        code.push_back((imm >> 56) & 0xFF);
        
        return code;
    }
    
    // mov reg, [base_reg]
    if (dst.type == Operand::Type::REGISTER && src.type == Operand::Type::MEMORY) {
        int dst_reg = get_register_code(dst.reg_name);
        int src_base = get_register_code(src.base_reg);
        
        if (dst_reg < 0 || src_base < 0) return code;
        
        // Construct REX with W=1, R = dst_reg>>3, B = src_base>>3
        int rex = 0x40 | 0x08;
        if ( (dst_reg >> 3) & 1 ) rex |= 0x04; // R
        if ( (src_base >> 3) & 1 ) rex |= 0x01; // B
        code.push_back(static_cast<uint8_t>(rex));

        // Opcode: 8B /r (mov r64, r/m64)
        code.push_back(0x8B);

        // ModRM: 00 dst src (register indirect)
        code.push_back(encode_modrm(0, dst_reg & 7, src_base & 7));
        
        return code;
    }
    
    // mov [dst_base], src_reg
    if (dst.type == Operand::Type::MEMORY && src.type == Operand::Type::REGISTER) {
        int dst_base = get_register_code(dst.base_reg);
        int src_reg = get_register_code(src.reg_name);
        
        if (dst_base < 0 || src_reg < 0) return code;
        
        // Construct REX with W=1, R = src_reg>>3, B = dst_base>>3
        int rex = 0x40 | 0x08;
        if ( (src_reg >> 3) & 1 ) rex |= 0x04; // R
        if ( (dst_base >> 3) & 1 ) rex |= 0x01; // B
        code.push_back(static_cast<uint8_t>(rex));

        // Opcode: 89 /r (mov r/m64, r64)
        code.push_back(0x89);

        // ModRM: 00 src dst
        code.push_back(encode_modrm(0, src_reg & 7, dst_base & 7));
        
        return code;
    }
    
    return code;
}

// ADD implementation
std::vector<uint8_t> InstructionEncoder::encode_add(const std::vector<Operand>& ops) {
    std::vector<uint8_t> code;
    
    if (ops.size() != 2) return code;
    
    const Operand& dst = ops[0];
    const Operand& src = ops[1];
    
    // add reg, reg
    if (dst.type == Operand::Type::REGISTER && src.type == Operand::Type::REGISTER) {
        int dst_reg = get_register_code(dst.reg_name);
        int src_reg = get_register_code(src.reg_name);
        
        if (dst_reg < 0 || src_reg < 0) return code;
        
        // Construct REX with W=1, R = src_reg>>3, B = dst_reg>>3
        int rex = 0x40 | 0x08;
        if ( (src_reg >> 3) & 1 ) rex |= 0x04; // R
        if ( (dst_reg >> 3) & 1 ) rex |= 0x01; // B
        code.push_back(static_cast<uint8_t>(rex));

        // Opcode: 01 /r (add r/m64, r64)
        code.push_back(0x01);

        // ModRM: 11 src dst
        code.push_back(encode_modrm(3, src_reg & 7, dst_reg & 7));
        
        return code;
    }
    
    return code;
}

// LGDT implementation (Load Global Descriptor Table)
std::vector<uint8_t> InstructionEncoder::encode_lgdt(const std::vector<Operand>& ops) {
    std::vector<uint8_t> code;

    if (ops.size() != 1) return code;

    const Operand& operand = ops[0];

    if (operand.type == Operand::Type::MEMORY) {
        // lgdt m16&64 (memory operand containing GDTR)
        code.push_back(0x0F);
        code.push_back(0x01);

        // ModRM byte: reg field is 000 (for lgdt), r/m is the memory operand
        // For lgdt, the reg field in ModRM is 2 (010 in binary)
        // So we need ModRM = [mod][010][r/m]
        if (operand.base_reg.empty()) {
            // [disp32] addressing
            code.push_back(encode_modrm(0, 2, 5));  // mod=00, reg=010, r/m=101
            // Add displacement (would need to handle this properly)
        } else {
            int base_reg = get_register_code(operand.base_reg);
            if (base_reg >= 0) {
                if (operand.displacement == 0 && base_reg != 4) { // RSP can't use [r/m] form
                    // [base_reg] addressing
                    code.push_back(encode_modrm(0, 2, base_reg & 7));
                } else {
                    // [base_reg + disp32] addressing
                    code.push_back(encode_modrm(2, 2, base_reg & 7));  // mod=10, reg=010
                    // Add displacement as 32-bit little-endian
                    uint32_t disp = static_cast<uint32_t>(operand.displacement);
                    code.push_back(disp & 0xFF);
                    code.push_back((disp >> 8) & 0xFF);
                    code.push_back((disp >> 16) & 0xFF);
                    code.push_back((disp >> 24) & 0xFF);
                }
            }
        }
    }

    return code;
}

// SGDT implementation (Store Global Descriptor Table)
std::vector<uint8_t> InstructionEncoder::encode_sgdt(const std::vector<Operand>& ops) {
    std::vector<uint8_t> code;

    if (ops.size() != 1) return code;

    const Operand& operand = ops[0];

    if (operand.type == Operand::Type::MEMORY) {
        // sgdt m16&64 (store GDTR to memory)
        code.push_back(0x0F);
        code.push_back(0x01);

        // ModRM byte: reg field is 001 (for sgdt), r/m is the memory operand
        int base_reg = get_register_code(operand.base_reg);
        if (base_reg >= 0) {
            if (operand.displacement == 0 && base_reg != 4) { // RSP can't use [r/m] form
                // [base_reg] addressing
                code.push_back(encode_modrm(0, 1, base_reg & 7));  // mod=00, reg=001
            } else {
                // [base_reg + disp32] addressing
                code.push_back(encode_modrm(2, 1, base_reg & 7));  // mod=10, reg=001
                // Add displacement as 32-bit little-endian
                uint32_t disp = static_cast<uint32_t>(operand.displacement);
                code.push_back(disp & 0xFF);
                code.push_back((disp >> 8) & 0xFF);
                code.push_back((disp >> 16) & 0xFF);
                code.push_back((disp >> 24) & 0xFF);
            }
        }
    }

    return code;
}

// LIDT implementation (Load Interrupt Descriptor Table)
std::vector<uint8_t> InstructionEncoder::encode_lidt(const std::vector<Operand>& ops) {
    std::vector<uint8_t> code;

    if (ops.size() != 1) return code;

    const Operand& operand = ops[0];

    if (operand.type == Operand::Type::MEMORY) {
        // lidt m16&64 (load IDTR from memory)
        code.push_back(0x0F);
        code.push_back(0x01);

        // ModRM byte: reg field is 011 (for lidt), r/m is the memory operand
        int base_reg = get_register_code(operand.base_reg);
        if (base_reg >= 0) {
            if (operand.displacement == 0 && base_reg != 4) { // RSP can't use [r/m] form
                // [base_reg] addressing
                code.push_back(encode_modrm(0, 3, base_reg & 7));  // mod=00, reg=011
            } else {
                // [base_reg + disp32] addressing
                code.push_back(encode_modrm(2, 3, base_reg & 7));  // mod=10, reg=011
                // Add displacement as 32-bit little-endian
                uint32_t disp = static_cast<uint32_t>(operand.displacement);
                code.push_back(disp & 0xFF);
                code.push_back((disp >> 8) & 0xFF);
                code.push_back((disp >> 16) & 0xFF);
                code.push_back((disp >> 24) & 0xFF);
            }
        }
    }

    return code;
}

// SIDT implementation (Store Interrupt Descriptor Table)
std::vector<uint8_t> InstructionEncoder::encode_sidt(const std::vector<Operand>& ops) {
    std::vector<uint8_t> code;

    if (ops.size() != 1) return code;

    const Operand& operand = ops[0];

    if (operand.type == Operand::Type::MEMORY) {
        // sidt m16&64 (store IDTR to memory)
        code.push_back(0x0F);
        code.push_back(0x01);

        // ModRM byte: reg field is 100 (for sidt), r/m is the memory operand
        int base_reg = get_register_code(operand.base_reg);
        if (base_reg >= 0) {
            if (operand.displacement == 0 && base_reg != 4) { // RSP can't use [r/m] form
                // [base_reg] addressing
                code.push_back(encode_modrm(0, 4, base_reg & 7));  // mod=00, reg=100
            } else {
                // [base_reg + disp32] addressing
                code.push_back(encode_modrm(2, 4, base_reg & 7));  // mod=10, reg=100
                // Add displacement as 32-bit little-endian
                uint32_t disp = static_cast<uint32_t>(operand.displacement);
                code.push_back(disp & 0xFF);
                code.push_back((disp >> 8) & 0xFF);
                code.push_back((disp >> 16) & 0xFF);
                code.push_back((disp >> 24) & 0xFF);
            }
        }
    }

    return code;
}

// LTR implementation (Load Task Register)
std::vector<uint8_t> InstructionEncoder::encode_ltr(const std::vector<Operand>& ops) {
    std::vector<uint8_t> code;

    if (ops.size() != 1) return code;

    const Operand& operand = ops[0];

    if (operand.type == Operand::Type::REGISTER) {
        // ltr r16 (load task register)
        code.push_back(0x0F);
        code.push_back(0x00);

        int reg = get_register_code(operand.reg_name);
        if (reg >= 0) {
            // ModRM byte: reg field is 101 (for ltr), r/m is the register
            code.push_back(encode_modrm(3, 3, reg & 7));  // mod=11, reg=011, r/m=reg
        }
    } else if (operand.type == Operand::Type::MEMORY) {
        // ltr m16 (load task register from memory)
        code.push_back(0x0F);
        code.push_back(0x00);

        int base_reg = get_register_code(operand.base_reg);
        if (base_reg >= 0) {
            if (operand.displacement == 0 && base_reg != 4) {
                // [base_reg] addressing
                code.push_back(encode_modrm(0, 3, base_reg & 7));  // mod=00, reg=011
            } else {
                // [base_reg + disp32] addressing
                code.push_back(encode_modrm(2, 3, base_reg & 7));  // mod=10, reg=011
                // Add displacement
                uint32_t disp = static_cast<uint32_t>(operand.displacement);
                code.push_back(disp & 0xFF);
                code.push_back((disp >> 8) & 0xFF);
                code.push_back((disp >> 16) & 0xFF);
                code.push_back((disp >> 24) & 0xFF);
            }
        }
    }

    return code;
}

// STR implementation (Store Task Register)
std::vector<uint8_t> InstructionEncoder::encode_str(const std::vector<Operand>& ops) {
    std::vector<uint8_t> code;

    if (ops.size() != 1) return code;

    const Operand& operand = ops[0];

    if (operand.type == Operand::Type::REGISTER) {
        // str r16 (store task register)
        code.push_back(0x0F);
        code.push_back(0x00);

        int reg = get_register_code(operand.reg_name);
        if (reg >= 0) {
            // ModRM byte: reg field is 100 (for str), r/m is the register
            code.push_back(encode_modrm(3, 2, reg & 7));  // mod=11, reg=010, r/m=reg
        }
    }

    return code;
}

// INVLPG implementation (Invalidate TLB Entry)
std::vector<uint8_t> InstructionEncoder::encode_invlpg(const std::vector<Operand>& ops) {
    std::vector<uint8_t> code;

    if (ops.size() != 1) return code;

    const Operand& operand = ops[0];

    if (operand.type == Operand::Type::MEMORY) {
        // invlpg m (invalidate TLB entry for page containing m)
        code.push_back(0x0F);
        code.push_back(0x01);

        int base_reg = get_register_code(operand.base_reg);
        if (base_reg >= 0) {
            if (operand.displacement == 0 && base_reg != 4) { // RSP can't use [r/m] form
                // [base_reg] addressing
                code.push_back(encode_modrm(0, 7, base_reg & 7));  // mod=00, reg=111 (for invlpg)
            } else {
                // [base_reg + disp32] addressing
                code.push_back(encode_modrm(2, 7, base_reg & 7));  // mod=10, reg=111
                // Add displacement
                uint32_t disp = static_cast<uint32_t>(operand.displacement);
                code.push_back(disp & 0xFF);
                code.push_back((disp >> 8) & 0xFF);
                code.push_back((disp >> 16) & 0xFF);
                code.push_back((disp >> 24) & 0xFF);
            }
        }
    }

    return code;
}

// INVPCID implementation (Invalidate Process-Context ID)
std::vector<uint8_t> InstructionEncoder::encode_invpcid(const std::vector<Operand>& ops) {
    std::vector<uint8_t> code;

    if (ops.size() != 2) return code;  // INVPCID requires two operands

    const Operand& type = ops[0];      // PCID type (register)
    const Operand& desc = ops[1];      // Descriptor (memory)

    // invlpcid r32/m64, r64 (invalidate PCID)
    code.push_back(0x66);  // Operand-size override prefix
    code.push_back(0x0F);
    code.push_back(0x38);
    code.push_back(0x82);  // INVPCID opcode

    // Need to encode both operands properly
    // This is a complex instruction that needs proper ModRM encoding
    // For now, we'll implement a basic version
    if (desc.type == Operand::Type::MEMORY) {
        int base_reg = get_register_code(desc.base_reg);
        int type_reg = get_register_code(type.reg_name);
        if (base_reg >= 0 && type_reg >= 0) {
            code.push_back(encode_modrm(0, type_reg & 7, base_reg & 7));  // Basic encoding
        }
    }

    return code;
}

// SUB implementation
std::vector<uint8_t> InstructionEncoder::encode_sub(const std::vector<Operand>& ops) {
    std::vector<uint8_t> code;

    if (ops.size() != 2) return code;

    const Operand& dst = ops[0];
    const Operand& src = ops[1];

    // sub reg, reg
    if (dst.type == Operand::Type::REGISTER && src.type == Operand::Type::REGISTER) {
        int dst_reg = get_register_code(dst.reg_name);
        int src_reg = get_register_code(src.reg_name);
        
        if (dst_reg < 0 || src_reg < 0) return code;
        
        // Construct REX with W=1, R = src_reg>>3, B = dst_reg>>3
        int rex = 0x40 | 0x08;
        if ( (src_reg >> 3) & 1 ) rex |= 0x04; // R
        if ( (dst_reg >> 3) & 1 ) rex |= 0x01; // B
        code.push_back(static_cast<uint8_t>(rex));

        // Opcode: 29 /r (sub r/m64, r64)
        code.push_back(0x29);

        // ModRM: 11 src dst
        code.push_back(encode_modrm(3, src_reg & 7, dst_reg & 7));
        
        return code;
    }
    
    return code;
}

// IMUL implementation
std::vector<uint8_t> InstructionEncoder::encode_imul(const std::vector<Operand>& ops) {
    std::vector<uint8_t> code;
    
    if (ops.size() != 2) return code;
    
    const Operand& dst = ops[0];
    const Operand& src = ops[1];
    
    // imul reg, reg
    if (dst.type == Operand::Type::REGISTER && src.type == Operand::Type::REGISTER) {
        int dst_reg = get_register_code(dst.reg_name);
        int src_reg = get_register_code(src.reg_name);
        
        if (dst_reg < 0 || src_reg < 0) return code;
        
        // Construct REX with W=1, R = dst_reg>>3, B = src_reg>>3
        int rex = 0x40 | 0x08;
        if ( (dst_reg >> 3) & 1 ) rex |= 0x04; // R
        if ( (src_reg >> 3) & 1 ) rex |= 0x01; // B
        code.push_back(static_cast<uint8_t>(rex));

        // Opcode: 0F AF /r (imul r64, r/m64)
        code.push_back(0x0F);
        code.push_back(0xAF);

        // ModRM: 11 dst src
        code.push_back(encode_modrm(3, dst_reg & 7, src_reg & 7));
        
        return code;
    }
    
    return code;
}

// JMP implementation
std::vector<uint8_t> InstructionEncoder::encode_jmp(const std::vector<Operand>& ops,
                                                   uint64_t offset,
                                                   std::vector<Relocation>& relocs,
                                                   Assembler* assembler) {
    std::vector<uint8_t> code;
    
    if (ops.size() != 1) return code;
    
    const Operand& target = ops[0];
    
    // jmp label
    if (target.type == Operand::Type::LABEL) {
        // Opcode: E9 cd (jmp rel32)
        code.push_back(0xE9);
        
        // Add relocation for label
        Relocation reloc;
        reloc.type = Relocation::Type::REL32;
        reloc.offset = offset + 1;  // After opcode
        reloc.symbol_name = target.label_name;
        reloc.addend = -4;  // Adjustment for immediate size
        relocs.push_back(reloc);
        
        // Placeholder 4-byte offset (will be filled by linker)
        code.push_back(0x00);
        code.push_back(0x00);
        code.push_back(0x00);
        code.push_back(0x00);
        
        return code;
    }
    
    // jmp reg
    if (target.type == Operand::Type::REGISTER) {
        int reg = get_register_code(target.reg_name);
        if (reg < 0) return code;
        
        // Opcode: FF /4 (jmp r/m64)
        code.push_back(0xFF);
        code.push_back(encode_modrm(3, 4, reg & 7));
        
        return code;
    }
    
    return code;
}

// CALL implementation
std::vector<uint8_t> InstructionEncoder::encode_call(const std::vector<Operand>& ops,
                                                    uint64_t offset,
                                                    std::vector<Relocation>& relocs,
                                                    Assembler* assembler) {
    std::vector<uint8_t> code;
    
    if (ops.size() != 1) return code;
    
    const Operand& target = ops[0];
    
    // call label
    if (target.type == Operand::Type::LABEL) {
        // Opcode: E8 cd (call rel32)
        code.push_back(0xE8);
        
        // Add relocation for label
        Relocation reloc;
        reloc.type = Relocation::Type::REL32;
        reloc.offset = offset + 1;
        reloc.symbol_name = target.label_name;
        reloc.addend = -4;
        relocs.push_back(reloc);
        
        // Placeholder 4-byte offset
        code.push_back(0x00);
        code.push_back(0x00);
        code.push_back(0x00);
        code.push_back(0x00);
        
        return code;
    }
    
    // call reg
    if (target.type == Operand::Type::REGISTER) {
        int reg = get_register_code(target.reg_name);
        if (reg < 0) return code;
        
        // Opcode: FF /2 (call r/m64)
        code.push_back(0xFF);
        code.push_back(encode_modrm(3, 2, reg & 7));
        
        return code;
    }
    
    return code;
}