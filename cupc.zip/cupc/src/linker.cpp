// cupld.cpp - Custom linker for C-UP
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <cstring>
#include <cstdint>
#include "log.h"

// Object file structure (simplified version)
struct Symbol {
    std::string name;
    uint64_t value = 0;
    int section = -1;  // -1 for external symbols
    bool is_defined = false;
    bool is_global = false;
};

struct Relocation {
    uint64_t offset = 0;
    std::string symbol_name;
    int type = 0;  // 0=ABS64, 1=REL32, etc.
};

struct Section {
    std::string name;
    std::vector<uint8_t> data;
    std::vector<Relocation> relocations;
};

struct ObjectFile {
    std::vector<Section> sections;
    std::vector<Symbol> symbols;
    std::map<std::string, Symbol*> symbol_map;  // For quick lookup
};

class Linker {
private:
    std::vector<ObjectFile> object_files;
    std::vector<Symbol> global_symbols;
    std::map<std::string, Symbol*> global_symbol_map;
    std::vector<Section> final_sections;
    std::string target_platform;

public:
    Linker(const std::string& platform = "linux") : target_platform(platform) {}

    bool parse_elf_file(std::ifstream& file, ObjectFile& obj) {
        // ELF header structure (first 52/64 bytes)
        char e_ident[16];
        uint16_t e_type, e_machine, e_version;
        uint32_t e_entry, e_phoff, e_shoff, e_flags;
        uint16_t e_ehsize, e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx;

        file.read(e_ident, 16);
        if (e_ident[0] != 0x7F || e_ident[1] != 'E' || e_ident[2] != 'L' || e_ident[3] != 'F') {
            return false; // Not ELF
        }

        file.read(reinterpret_cast<char*>(&e_type), 2);
        file.read(reinterpret_cast<char*>(&e_machine), 2);
        file.read(reinterpret_cast<char*>(&e_version), 4);
        file.read(reinterpret_cast<char*>(&e_entry), 4);
        file.read(reinterpret_cast<char*>(&e_phoff), 4);
        file.read(reinterpret_cast<char*>(&e_shoff), 4);
        file.read(reinterpret_cast<char*>(&e_flags), 4);
        file.read(reinterpret_cast<char*>(&e_ehsize), 2);
        file.read(reinterpret_cast<char*>(&e_phentsize), 2);
        file.read(reinterpret_cast<char*>(&e_phnum), 2);
        file.read(reinterpret_cast<char*>(&e_shentsize), 2);
        file.read(reinterpret_cast<char*>(&e_shnum), 2);
        file.read(reinterpret_cast<char*>(&e_shstrndx), 2);

        // Read section headers
        std::vector<char> section_header_table(e_shnum * e_shentsize);
        file.seekg(e_shoff);
        file.read(section_header_table.data(), e_shnum * e_shentsize);

        // Read string table for section names
        uint64_t shstrtab_off = 0;
        uint64_t shstrtab_size = 0;
        if (e_shstrndx < e_shnum) {
            // Get string table section header
            char* shstr_header = section_header_table.data() + e_shstrndx * e_shentsize;
            uint32_t sh_name, sh_type;
            uint64_t sh_offset, sh_size;

            std::memcpy(&sh_name, shstr_header, 4);
            std::memcpy(&sh_type, shstr_header + 4, 4);
            std::memcpy(&sh_offset, shstr_header + 16, 8);
            std::memcpy(&sh_size, shstr_header + 24, 8);

            shstrtab_off = sh_offset;
            shstrtab_size = sh_size;
        }

        // Read string table
        std::vector<char> strtab(shstrtab_size);
        file.seekg(shstrtab_off);
        file.read(strtab.data(), shstrtab_size);

        // Process sections
        for (int i = 0; i < e_shnum; i++) {
            char* section_header = section_header_table.data() + i * e_shentsize;
            uint32_t sh_name, sh_type;
            uint64_t sh_offset, sh_size;

            std::memcpy(&sh_name, section_header, 4);
            std::memcpy(&sh_type, section_header + 4, 4);
            std::memcpy(&sh_offset, section_header + 16, 8);
            std::memcpy(&sh_size, section_header + 24, 8);

            // Get section name
            const char* name = strtab.data() + sh_name;

            // Add section to object file
            Section sec;
            sec.name = name;
            sec.data.resize(sh_size);
            file.seekg(sh_offset);
            file.read(reinterpret_cast<char*>(sec.data.data()), sh_size);
            obj.sections.push_back(sec);
        }

        return true;
    }

    bool parse_coff_file(std::ifstream& file, ObjectFile& obj) {
        // DOS header (first 64 bytes, but we only care about PE offset at 0x3C)
        char dos_header[64];
        file.seekg(0);
        file.read(dos_header, 64);

        // PE signature offset is at 0x3C
        uint32_t pe_offset;
        file.seekg(0x3C);
        file.read(reinterpret_cast<char*>(&pe_offset), 4);

        // Read PE header
        file.seekg(pe_offset);
        char pe_signature[4];
        file.read(pe_signature, 4);
        if (pe_signature[0] != 'P' || pe_signature[1] != 'E' || pe_signature[2] != 0 || pe_signature[3] != 0) {
            return false; // Not valid PE
        }

        // COFF header (20 bytes after PE signature)
        uint16_t machine, num_sections;
        uint32_t time_date_stamp, ptr_to_syms, num_syms;
        uint16_t opt_header_size, characteristics;

        file.read(reinterpret_cast<char*>(&machine), 2);
        file.read(reinterpret_cast<char*>(&num_sections), 2);
        file.read(reinterpret_cast<char*>(&time_date_stamp), 4);
        file.read(reinterpret_cast<char*>(&ptr_to_syms), 4);
        file.read(reinterpret_cast<char*>(&num_syms), 4);
        file.read(reinterpret_cast<char*>(&opt_header_size), 2);
        file.read(reinterpret_cast<char*>(&characteristics), 2);

        // Skip optional header if present
        if (opt_header_size > 0) {
            file.seekg(opt_header_size, std::ios::cur);
        }

        // Read section headers (40 bytes each)
        for (int i = 0; i < num_sections; i++) {
            char section_header[40];
            file.read(section_header, 40);

            // First 8 bytes are the name (null-padded)
            char name[9];
            std::memcpy(name, section_header, 8);
            name[8] = 0; // null terminate

            // Bytes 16-19 are virtual size, 20-23 are virtual address
            // Bytes 24-27 are raw data size, 28-31 are pointer to raw data
            uint32_t virtual_size, virtual_address, raw_size, ptr_to_raw;
            std::memcpy(&raw_size, section_header + 16, 4);
            std::memcpy(&ptr_to_raw, section_header + 20, 4);

            // Read section data
            Section sec;
            sec.name = name;
            sec.data.resize(raw_size);
            uint64_t current_pos = file.tellg(); // Save current position
            file.seekg(ptr_to_raw);
            file.read(reinterpret_cast<char*>(sec.data.data()), raw_size);
            file.seekg(current_pos); // Restore position

            obj.sections.push_back(sec);
        }

        return true;
    }

    bool load_object_file(const std::string& filename) {
        std::ifstream file(filename, std::ios::binary);
        if (!file) {
            log_error() << "Cannot open object file: " << filename << std::endl;
            return false;
        }

        // Determine file format by reading magic bytes
        char magic[4];
        file.read(magic, 4);
        file.seekg(0); // Reset to beginning

        ObjectFile obj;
        if (magic[0] == 0x7F && magic[1] == 'E' && magic[2] == 'L' && magic[3] == 'F') {
            // ELF file
            if (!parse_elf_file(file, obj)) {
                log_error() << "Failed to parse ELF file: " << filename << std::endl;
                return false;
            }
        } else if (magic[0] == 0x4D && magic[1] == 0x5A) { // DOS header
            // Likely PE/COFF file - check for PE signature
            file.seekg(0x3C);
            uint32_t pe_offset;
            file.read(reinterpret_cast<char*>(&pe_offset), 4);
            file.seekg(pe_offset);

            char pe_magic[4];
            file.read(pe_magic, 4);
            if (pe_magic[0] == 'P' && pe_magic[1] == 'E' && pe_magic[2] == 0 && pe_magic[3] == 0) {
                // PE/COFF file
                file.seekg(0);
                if (!parse_coff_file(file, obj)) {
                    log_error() << "Failed to parse COFF file: " << filename << std::endl;
                    return false;
                }
            } else {
                log_error() << "Unknown object file format: " << filename << std::endl;
                return false;
            }
        } else {
            log_error() << "Unknown object file format: " << filename << std::endl;
            return false;
        }

        object_files.push_back(obj);
        return true;
    }

    bool link(const std::vector<std::string>& input_files, const std::string& output_file) {
        log_info() << "Starting link process for " << input_files.size() << " files\n";

        // Load all object files
        for (const auto& file : input_files) {
            if (!load_object_file(file)) {
                log_error() << "Failed to load object file: " << file << std::endl;
                return false;
            }
        }

        // Resolve symbols across object files
        if (!resolve_symbols()) {
            log_error() << "Symbol resolution failed\n";
            return false;
        }

        // Perform relocations
        if (!perform_relocations()) {
            log_error() << "Relocation failed\n";
            return false;
        }

        // Generate final executable
        if (!generate_executable(output_file)) {
            log_error() << "Failed to generate executable: " << output_file << std::endl;
            return false;
        }

        log_info() << "Successfully linked to: " << output_file << std::endl;
        return true;
    }

private:
    bool resolve_symbols() {
        // Create global symbol table
        std::map<std::string, std::vector<Symbol*>> symbol_definitions;

        // Collect all symbol definitions from all object files
        for (auto& obj : object_files) {
            for (auto& sym : obj.symbols) {
                if (sym.is_global) {
                    symbol_definitions[sym.name].push_back(&sym);
                }
            }
        }

        // Resolve symbol references
        for (auto& obj : object_files) {
            for (auto& section : obj.sections) {
                for (auto& reloc : section.relocations) {
                    // Find the symbol in global symbol table
                    auto it = symbol_definitions.find(reloc.symbol_name);
                    if (it != symbol_definitions.end()) {
                        // Found the symbol - resolve it
                        // For now, just mark as resolved
                    } else {
                        // Undefined symbol - this is an error unless it's an external symbol
                        log_error() << "Undefined symbol: " << reloc.symbol_name << std::endl;
                        return false;
                    }
                }
            }
        }

        return true;
    }

    bool perform_relocations() {
        // Apply relocations to fix up addresses
        for (auto& obj : object_files) {
            for (auto& section : obj.sections) {
                for (auto& reloc : section.relocations) {
                    // Apply the relocation based on its type
                    // This is where we'd modify the section data at reloc.offset
                    // to fix up the address
                }
            }
        }
        return true;
    }

    bool generate_executable(const std::string& filename) {
        // Generate the final executable file
        std::ofstream file(filename, std::ios::binary);
        if (!file) {
            return false;
        }

        // Write executable header based on platform
        if (target_platform == "windows") {
            // Write PE header for Windows
            write_pe_header(file);
        } else {
            // Write ELF header for Linux
            write_elf_header(file);
        }

        // Write sections
        for (const auto& sect : final_sections) {
            file.write(reinterpret_cast<const char*>(sect.data.data()), sect.data.size());
        }

        file.close();
        return true;
    }

    void write_elf_header(std::ofstream& file) {
        // Write ELF header (simplified)
        uint8_t header[64];
        std::memset(header, 0, 64);

        // ELF magic
        header[0] = 0x7F;
        header[1] = 'E';
        header[2] = 'L';
        header[3] = 'F';
        header[4] = 2;  // 64-bit
        header[5] = 1;  // Little endian
        header[6] = 1;  // Version
        header[7] = 0;  // System V ABI

        file.write(reinterpret_cast<const char*>(header), 64);
    }

    void write_pe_header(std::ofstream& file) {
        // Write PE header (simplified)
        // This is more complex and platform-specific
        log_info() << "Writing PE header for Windows executable\n";
    }
};

void print_usage(const char* program_name) {
    std::cout << "Usage: " << program_name << " [options] <input1.o> <input2.o> ... -o <output>\n"
              << "Options:\n"
              << "  -h, --help          Show this help message\n"
              << "  -p, --platform PLAT Target platform (linux or windows)\n"
              << "  -v, --verbose       Verbose output\n";
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        print_usage(argv[0]);
        return 1;
    }

    std::vector<std::string> input_files;
    std::string output_file;
    std::string platform = "linux";
    bool verbose = false;

    // Parse command line arguments
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];

        if (arg == "-h" || arg == "--help") {
            print_usage(argv[0]);
            return 0;
        } else if (arg == "-p" || arg == "--platform") {
            if (i + 1 < argc) {
                platform = argv[++i];
            }
        } else if (arg == "-v" || arg == "--verbose") {
            verbose = true;
        } else if (arg == "-o") {
            if (i + 1 < argc) {
                output_file = argv[++i];
            }
        } else if (arg[0] != '-') {
            // Input file
            input_files.push_back(arg);
        }
    }

    if (input_files.empty()) {
        log_error() << "Error: No input files specified\n";
        print_usage(argv[0]);
        return 1;
    }

    if (output_file.empty()) {
        log_error() << "Error: No output file specified (use -o)\n";
        print_usage(argv[0]);
        return 1;
    }

    Linker linker(platform);

    if (!linker.link(input_files, output_file)) {
        log_error() << "Linking failed\n";
        return 1;
    }

    return 0;
}