// build_manager.cpp - C-UP Build Manager
// Entry point for building C-UP programs, managing dependencies, and running tests

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <algorithm>
#include "process.h"
#include "log.h"
#include <filesystem>

// Simple filesystem helpers (avoid C++17 filesystem requirement)
#ifdef _WIN32
    #include <windows.h>
    #include <shlwapi.h>
    #pragma comment(lib, "shlwapi.lib")
    inline bool file_exists(const std::string& path) {
        DWORD attrs = GetFileAttributesA(path.c_str());
        return (attrs != INVALID_FILE_ATTRIBUTES && !(attrs & FILE_ATTRIBUTE_DIRECTORY));
    }
    inline bool dir_exists(const std::string& path) {
        DWORD attrs = GetFileAttributesA(path.c_str());
        return (attrs != INVALID_FILE_ATTRIBUTES && (attrs & FILE_ATTRIBUTE_DIRECTORY));
    }
    inline void create_dirs(const std::string& path) {
        CreateDirectoryA(path.c_str(), NULL);
    }
#else
    #include <sys/stat.h>
    #include <unistd.h>
    inline bool file_exists(const std::string& path) {
        struct stat buffer;
        return (stat(path.c_str(), &buffer) == 0 && S_ISREG(buffer.st_mode));
    }
    inline bool dir_exists(const std::string& path) {
        struct stat buffer;
        return (stat(path.c_str(), &buffer) == 0 && S_ISDIR(buffer.st_mode));
    }
    inline void create_dirs(const std::string& path) {
        mkdir(path.c_str(), 0755);
    }
#endif

#ifdef _WIN32
    #define IS_WINDOWS true
    #include <windows.h>
    #include <shlwapi.h>
    #pragma comment(lib, "shlwapi.lib")
#else
    #define IS_WINDOWS false
    #include <unistd.h>
#endif

bool check_command_exists(const std::string& cmd) {
    #ifdef _WIN32
        // On Windows, check if command exists in PATH
        char path[MAX_PATH];
        return SearchPathA(NULL, cmd.c_str(), ".exe", MAX_PATH, path, NULL) != 0;
    #else
        // On Unix-like systems, use which via run_process (no shell)
        int rc = run_process({"which", cmd});
        return rc == 0;
    #endif
}

void check_dependencies() {
    std::cout << "Checking dependencies...\n";
    
    bool all_good = true;
    
    if (!check_command_exists("nasm")) {
        log_error() << "[FAIL] nasm not found (required for assembly)\n";
        all_good = false;
    } else {
        log_info() << "[OK] nasm found\n";
    }
    
    if (!check_command_exists("gcc")) {
        log_error() << "[FAIL] gcc not found (required for linking)\n";
        all_good = false;
    } else {
        log_info() << "[OK] gcc found\n";
    }
    
    if (!all_good) {
        log_error() << "\nPlease install missing dependencies and try again.\n";
        std::exit(1);
    }
    
    std::cout << "[OK] All dependencies satisfied.\n\n";
}

void show_usage() {
    std::cout << "C-UP Build Manager (cup.exe)\n";
    std::cout << "Usage: cup [command] [options]\n\n";
    std::cout << "Commands:\n";
    std::cout << "  build <source.cup> <output>   Build a C-UP program\n";
    std::cout << "  test                           Run tests\n";
    std::cout << "  install                        Install compiler\n";
    std::cout << "  clean                          Clean build artifacts\n";
    std::cout << "  check                          Check system dependencies\n";
    std::cout << "  --version, -v                  Show version\n";
    std::cout << "  --help, -h                     Show this help\n\n";
}

void show_version() {
    std::cout << "cup (C-UP Build Manager) version 1.0.0\n";
    std::cout << "C-UP Compiler Toolchain\n";
    std::cout << "Copyright (C) 2024 Hadron Buzz\n";
}

// Simple project specification for cupconstruct
struct ProjectSpec {
    std::vector<std::string> sources;
    std::vector<std::string> helpers;
    std::string output;
    std::vector<std::string> derives;
    std::vector<std::string> includes;
};

static inline std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

// Parse a cupconstruct file: key=value per line. Keys: source, helper, output, derive, include
ProjectSpec parse_cupconstruct(const std::string& path) {
    ProjectSpec spec;
    std::ifstream in(path);
    if (!in) throw std::runtime_error("Cannot open cupconstruct: " + path);
    std::string line;
    while (std::getline(in, line)) {
        std::string t = trim(line);
        if (t.empty() || t[0] == '#') continue;
        auto eq = t.find('=');
        if (eq == std::string::npos) continue;
        std::string key = trim(t.substr(0, eq));
        std::string val = trim(t.substr(eq + 1));
        // normalize key
        for (auto& c : key) c = static_cast<char>(std::tolower(c));
        if (key == "source") {
            spec.sources.push_back(val);
        } else if (key == "helper") {
            spec.helpers.push_back(val);
        } else if (key == "output") {
            spec.output = val;
        } else if (key == "derive") {
            spec.derives.push_back(val);
        } else if (key == "include") {
            spec.includes.push_back(val);
        }
    }
    return spec;
}

void build_program(const std::string& source, const std::string& output) {
    std::cout << "Building " << source << " -> " << output << "\n";
    
    // Check if source file exists
    if (!file_exists(source)) {
        log_error() << "Error: Source file not found: " << source << "\n";
        std::exit(1);
    }
    
    // Check if compiler exists
    std::string compiler = "bin/cupc";
    #ifdef _WIN32
        compiler += ".exe";
    #endif
    
    if (!file_exists(compiler)) {
        log_error() << "Error: Compiler not found: " << compiler << "\n";
        log_error() << "Please build the compiler first with: scons\n";
        std::exit(1);
    }
    
    // Incremental build: if output exists and is newer than source + runtime helpers + compiler, skip build
    try {
        if (file_exists(output)) {
            auto out_time = std::filesystem::last_write_time(output);

            // gather relevant files to compare against: source, compiler, lib/cup/runtime/*
            std::vector<std::string> check_files;
            check_files.push_back(source);
            check_files.push_back(compiler);

            // add runtime helpers if directory exists
            std::error_code ec;
            if (std::filesystem::exists("lib/cup/runtime", ec)) {
                for (auto &p : std::filesystem::directory_iterator("lib/cup/runtime", ec)) {
                    if (!ec && p.exists()) check_files.push_back(p.path().string());
                }
            }

            bool stale = false;
            for (const auto &f : check_files) {
                if (!file_exists(f)) continue;
                try {
                    auto t = std::filesystem::last_write_time(f);
                    if (t > out_time) { stale = true; break; }
                } catch (...) {
                    stale = true; break;
                }
            }

            if (!stale) {
                log_info() << "Output is up-to-date. Skipping build: " << output << "\n";
                return;
            }
        }
    } catch (...) {
        // If filesystem queries fail, fall back to full build
    }
    
    // Build command
    std::vector<std::string> args = {compiler, source, output};
    std::cout << "Running: " << compiler << " " << source << " " << output << "\n";
    int rc = run_process(args);
    if (rc != 0) {
        log_error() << "Build failed!\n";
        std::exit(1);
    }
    
    std::cout << "[OK] Build successful!\n";
}

void run_tests() {
    std::cout << "Running tests...\n";
    
    // Simple test file
    std::string test_file = "test/test.cup";
    
    if (!file_exists(test_file)) {
        log_info() << "No test file found at " << test_file << "\n";
        log_info() << "Creating sample test...\n";
        
        // Create test directory
        if (!dir_exists("test")) {
            create_dirs("test");
        }
        
        // Create simple test
        std::ofstream test(test_file);
        test << "// Simple test\n";
        test << "int64: start() {\n";
        test << "    int64: x = 42;\n";
        test << "    return x;\n";
        test << "}\n";
        test.close();
    }
    
    build_program(test_file, "test/test_out");
    std::cout << "✓ Tests passed\n";
}

void clean_artifacts() {
    std::cout << "Cleaning build artifacts...\n";
    
    std::vector<std::string> patterns = {
        "*.o", "*.asm", "test/*.o", "test/*.asm"
    };
    
    for (const auto& pattern : patterns) {
        // Support simple patterns: "*.ext" and "dir/*.ext"
        std::string dir = ".";
        std::string pat = pattern;
        auto slash = pattern.find('/');
        if (slash != std::string::npos) {
            dir = pattern.substr(0, slash);
            pat = pattern.substr(slash + 1);
        }
        // Only support prefix '*' patterns like "*.o" for now
        if (pat.size() >= 2 && pat[0] == '*') {
            std::string suffix = pat.substr(1);
            try {
                for (auto& p : std::filesystem::directory_iterator(dir)) {
                    auto name = p.path().filename().string();
                    if (name.size() >= suffix.size() && name.compare(name.size() - suffix.size(), suffix.size(), suffix) == 0) {
                        std::error_code ec;
                        std::filesystem::remove(p.path(), ec);
                    }
                }
            } catch (...) {
                // ignore
            }
        }
    }
    
    std::cout << "✓ Cleaned\n";
}

void install_compiler() {
    std::cout << "Installing compiler...\n";
    
    #ifdef _WIN32
        std::vector<std::string> args = {"scons", "install"};
    #else
        std::vector<std::string> args = {"scons", "install", "PREFIX=/usr/local"};
    #endif

    int rc = run_process(args);
    if (rc != 0) {
        log_error() << "Installation failed!\n";
        std::exit(1);
    }
    
    std::cout << "✓ Installation complete\n";
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        show_usage();
        return 1;
    }
    
    std::string command = argv[1];
    
    if (command == "--version" || command == "-v") {
        show_version();
        return 0;
    }
    
    if (command == "--help" || command == "-h") {
        show_usage();
        return 0;
    }
    
    if (command == "check") {
        check_dependencies();
        return 0;
    }
    
    if (command == "build") {
        if (argc < 4) {
            // If no explicit source was given, attempt to parse a local `cupconstruct` in cwd
            if (argc == 2) {
                std::string cwd_file = "cupconstruct";
                if (!file_exists(cwd_file)) {
                    log_error() << "Error: build requires source and output arguments or a local 'cupconstruct'\n";
                    log_error() << "Usage: cup build <source.cup> <output>\n";
                    return 1;
                }
                try {
                    check_dependencies();
                    auto spec = parse_cupconstruct(cwd_file);
                    std::cout << "Parsed cupconstruct:\n";
                    std::cout << "  output: " << spec.output << "\n";
                    for (const auto& s : spec.sources) std::cout << "  source: " << s << "\n";
                    for (const auto& h : spec.helpers) std::cout << "  helper: " << h << "\n";
                    for (const auto& d : spec.derives) std::cout << "  derive: " << d << "\n";
                    for (const auto& p : spec.includes) std::cout << "  include: " << p << "\n";
                    return 0;
                } catch (const std::exception& e) {
                    log_error() << "Error parsing cupconstruct: " << e.what() << "\n";
                    return 1;
                }
            }

            log_error() << "Error: build requires source and output arguments\n";
            log_error() << "Usage: cup build <source.cup> <output>\n";
            return 1;
        }
        check_dependencies();
        build_program(argv[2], argv[3]);
        return 0;
    }
    
    if (command == "test") {
        check_dependencies();
        run_tests();
        return 0;
    }
    
    if (command == "clean") {
        clean_artifacts();
        return 0;
    }
    
    if (command == "install") {
        install_compiler();
        return 0;
    }
    
    log_error() << "Error: Unknown command: " << command << "\n";
    show_usage();
    return 1;
}