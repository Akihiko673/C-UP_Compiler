// coff_writer.cpp - Windows COFF object file writer
#include "assembler.h"
#include <fstream>
#include <cstring>
#include "log.h"
#include <iostream>

// COFF symbol table entry (18 bytes)
struct COFFSymbol {
    union {
        uint8_t name[8];        // Short name (8 bytes, null-padded)
        struct {
            uint32_t zeros;     // Must be 0
            uint32_t offset;    // Offset in string table
        } name_string;
    } n_name;
    uint32_t value;             // Symbol value (offset or absolute)
    int16_t section_number;     // Section number (1-based, -1 = external)
    uint16_t type;              // Basic type (0 for most)
    uint8_t storage_class;      // Storage class (2 = external)
    uint8_t num_aux;            // Number of auxiliary symbols (0)
} __attribute__((packed));

// COFF file header structure (20 bytes)
struct COFFFileHeader {
    uint16_t machine;           // Machine type (0x8664 = x86-64)
    uint16_t num_sections;      // Number of sections
    uint32_t timestamp;         // Timestamp
    uint32_t symbol_table_ptr;  // Pointer to symbol table
    uint32_t num_symbols;       // Number of symbols
    uint16_t opt_header_size;   // Optional header size (0 for object files)
    uint16_t flags;             // Characteristics
} __attribute__((packed));

// Section header structure (40 bytes)
struct COFFSectionHeader {
    uint8_t name[8];            // Section name
    uint32_t virtual_size;      // Virtual size
    uint32_t virtual_addr;      // Virtual address
    uint32_t size_raw_data;     // Size of raw data
    uint32_t ptr_raw_data;      // Pointer to raw data
    uint32_t ptr_relocs;        // Pointer to relocations
    uint32_t ptr_line_nums;     // Pointer to line numbers
    uint16_t num_relocs;        // Number of relocations
    uint16_t num_line_nums;     // Number of line numbers
    uint32_t characteristics;   // Section flags
} __attribute__((packed));

// Relocation entry (10 bytes)
struct COFFRelocation {
    uint32_t offset;            // Offset in section
    uint32_t symbol_index;      // Index in symbol table
    uint16_t type;              // Relocation type
} __attribute__((packed));

void Assembler::write_coff_file(const std::string& filename, const ObjectFile& obj) {
    std::ofstream file(filename, std::ios::binary);
    if (!file) {
        log_error() << "Error: Cannot open " << filename << " for writing\n";
        return;
    }
    
    // Build section data
    std::vector<std::vector<uint8_t>> section_data;
    std::vector<std::vector<COFFRelocation>> section_relocs;
    
    for (const auto& section : obj.sections) {
        section_data.push_back(section.data);
        
        // Convert relocations
        std::vector<COFFRelocation> relocs;
        for (const auto& reloc : section.relocations) {
            COFFRelocation coff_reloc;
            coff_reloc.offset = reloc.offset;
            coff_reloc.symbol_index = 0;  // Will update below
            
            // Convert relocation type
            if (reloc.type == Relocation::Type::REL32) {
                coff_reloc.type = 4;  // IMAGE_REL_AMD64_REL32
            } else if (reloc.type == Relocation::Type::ABS64) {
                coff_reloc.type = 1;  // IMAGE_REL_AMD64_ADDR64
            } else {
                coff_reloc.type = 0;  // IMAGE_REL_AMD64_ABSOLUTE
            }
            relocs.push_back(coff_reloc);
        }
        section_relocs.push_back(relocs);
    }
    
    // Build symbol table
    std::vector<COFFSymbol> symbols;
    std::string string_table;
    string_table.push_back('\0');  // String table starts with null byte
    
    std::map<std::string, uint32_t> symbol_indices;
    uint32_t symbol_index = 0;
    
    // Add all defined symbols
    for (const auto& sym : defined_symbols) {
        COFFSymbol coff_sym;
        std::memset(&coff_sym, 0, sizeof(coff_sym));
        
        coff_sym.value = sym.offset;
        coff_sym.section_number = sym.section_index + 1;  // 1-based
        coff_sym.type = 0;
        coff_sym.storage_class = 2;  // C_EXT
        coff_sym.num_aux = 0;
        
        // Add symbol name
        if (sym.name.length() <= 8) {
            std::memcpy(coff_sym.n_name.name, sym.name.c_str(), sym.name.length());
        } else {
            coff_sym.n_name.name_string.zeros = 0;
            coff_sym.n_name.name_string.offset = string_table.length();
            string_table += sym.name;
            string_table.push_back('\0');
        }
        
        symbol_indices[sym.name] = symbol_index;
        symbols.push_back(coff_sym);
        symbol_index++;
    }
    
    // Add all external symbols
    for (const auto& sym : external_symbols) {
        COFFSymbol coff_sym;
        std::memset(&coff_sym, 0, sizeof(coff_sym));
        
        coff_sym.value = 0;
        coff_sym.section_number = 0;  // External
        coff_sym.type = 0;
        coff_sym.storage_class = 2;  // C_EXT
        coff_sym.num_aux = 0;
        
        // Add symbol name
        if (sym.name.length() <= 8) {
            std::memcpy(coff_sym.n_name.name, sym.name.c_str(), sym.name.length());
        } else {
            coff_sym.n_name.name_string.zeros = 0;
            coff_sym.n_name.name_string.offset = string_table.length();
            string_table += sym.name;
            string_table.push_back('\0');
        }
        
        symbol_indices[sym.name] = symbol_index;
        symbols.push_back(coff_sym);
        symbol_index++;
    }
    
    // Update relocation symbol indices
    for (size_t i = 0; i < section_relocs.size(); i++) {
        for (size_t j = 0; j < section_relocs[i].size(); j++) {
            if (j < obj.sections[i].relocations.size()) {
                const auto& orig_reloc = obj.sections[i].relocations[j];
                auto it = symbol_indices.find(orig_reloc.symbol_name);
                if (it != symbol_indices.end()) {
                    section_relocs[i][j].symbol_index = it->second;
                }
            }
        }
    }
    
    // Calculate offsets
    uint32_t file_offset = sizeof(COFFFileHeader) + (obj.sections.size() * sizeof(COFFSectionHeader));
    
    // Offsets for section data
    std::vector<uint32_t> section_data_offsets;
    uint32_t current_offset = file_offset;
    for (size_t i = 0; i < section_data.size(); i++) {
        section_data_offsets.push_back(current_offset);
        current_offset += section_data[i].size();
    }
    
    // Offsets for relocations
    std::vector<uint32_t> section_reloc_offsets;
    for (size_t i = 0; i < section_relocs.size(); i++) {
        section_reloc_offsets.push_back(current_offset);
        current_offset += section_relocs[i].size() * sizeof(COFFRelocation);
    }
    
    // Symbol table offset
    uint32_t symbol_table_offset = current_offset;
    
    // String table offset
    uint32_t string_table_offset = symbol_table_offset + (symbols.size() * sizeof(COFFSymbol));
    
    // Write COFF file header
    COFFFileHeader header;
    std::memset(&header, 0, sizeof(header));
    header.machine = 0x8664;            // x86-64
    header.num_sections = obj.sections.size();
    header.timestamp = 0;
    header.symbol_table_ptr = symbols.empty() ? 0 : symbol_table_offset;
    header.num_symbols = symbols.size();
    header.opt_header_size = 0;
    header.flags = 0x0103;
    
    file.write(reinterpret_cast<const char*>(&header), sizeof(header));
    
    // Write section headers
    for (size_t i = 0; i < obj.sections.size(); i++) {
        // Write section name (8 bytes, zero-padded)
        std::string name = obj.sections[i].name;
        if (name.length() > 8) name = name.substr(0, 8);
        
        // Pad with zeros to 8 bytes
        uint8_t name_buf[8];
        std::memset(name_buf, 0, 8);
        std::memcpy(name_buf, name.c_str(), name.length());
        file.write(reinterpret_cast<const char*>(name_buf), 8);
        
        // Write remaining header fields
        uint32_t virtual_size = section_data[i].size();
        uint32_t virtual_addr = 0;
        uint32_t size_raw_data = section_data[i].size();
        uint32_t ptr_raw_data = section_data_offsets[i];
        uint32_t ptr_relocs = section_relocs[i].empty() ? 0 : section_reloc_offsets[i];
        uint32_t ptr_line_nums = 0;
        uint16_t num_relocs = section_relocs[i].size();
        uint16_t num_line_nums = 0;
        uint32_t characteristics = obj.sections[i].flags;
        
        file.write(reinterpret_cast<const char*>(&virtual_size), 4);
        file.write(reinterpret_cast<const char*>(&virtual_addr), 4);
        file.write(reinterpret_cast<const char*>(&size_raw_data), 4);
        file.write(reinterpret_cast<const char*>(&ptr_raw_data), 4);
        file.write(reinterpret_cast<const char*>(&ptr_relocs), 4);
        file.write(reinterpret_cast<const char*>(&ptr_line_nums), 4);
        file.write(reinterpret_cast<const char*>(&num_relocs), 2);
        file.write(reinterpret_cast<const char*>(&num_line_nums), 2);
        file.write(reinterpret_cast<const char*>(&characteristics), 4);
    }
    
    // Write section data
    for (size_t i = 0; i < section_data.size(); i++) {
        if (!section_data[i].empty()) {
            file.write(reinterpret_cast<const char*>(section_data[i].data()), section_data[i].size());
        }
    }
    
    // Write relocations
    for (size_t i = 0; i < section_relocs.size(); i++) {
        for (const auto& reloc : section_relocs[i]) {
            file.write(reinterpret_cast<const char*>(&reloc), sizeof(reloc));
        }
    }
    
    // Write symbol table
    for (const auto& sym : symbols) {
        file.write(reinterpret_cast<const char*>(&sym), sizeof(sym));
    }
    
    // Write string table
    uint32_t string_table_size = string_table.length() + 4;
    file.write(reinterpret_cast<const char*>(&string_table_size), 4);
    file.write(string_table.c_str(), string_table.length());
    
    file.flush();
    file.close();
    
    log_info() << "Wrote COFF object file: " << filename << " (" 
              << std::to_string(obj.sections.size()) << " sections, " 
              << std::to_string(symbols.size()) << " symbols)\n";
}

void Assembler::write_elf_file(const std::string& filename, const ObjectFile& obj) {
    std::ofstream file(filename, std::ios::binary);
    if (!file) {
        log_error() << "Error: Cannot open " << filename << " for writing\n";
        return;
    }
    
    // ELF header
    uint8_t elf_header[64];
    std::memset(elf_header, 0, 64);
    
    // ELF magic number
    elf_header[0] = 0x7F;
    elf_header[1] = 'E';
    elf_header[2] = 'L';
    elf_header[3] = 'F';
    
    elf_header[4] = 2;             // 64-bit
    elf_header[5] = 1;             // Little-endian
    elf_header[6] = 1;             // Current version
    elf_header[7] = 0;             // System V ABI
    
    // Type: object file
    uint16_t e_type = 1;            // ET_REL
    std::memcpy(&elf_header[16], &e_type, 2);
    
    // Machine: x86-64
    uint16_t e_machine = 0x3E;     // EM_X86_64
    std::memcpy(&elf_header[18], &e_machine, 2);
    
    // Version
    uint32_t e_version = 1;
    std::memcpy(&elf_header[20], &e_version, 4);
    
    // Entry point (0 for object files)
    uint64_t e_entry = 0;
    std::memcpy(&elf_header[32], &e_entry, 8);
    
    // Program header offset (0 for object files)
    uint64_t e_phoff = 0;
    std::memcpy(&elf_header[40], &e_phoff, 8);
    
    // Section header offset
    uint64_t e_shoff = 64;
    std::memcpy(&elf_header[48], &e_shoff, 8);
    
    // Flags
    uint32_t e_flags = 0;
    std::memcpy(&elf_header[56], &e_flags, 4);
    
    // ELF header size
    uint16_t e_ehsize = 64;
    std::memcpy(&elf_header[58], &e_ehsize, 2);
    
    // Program header entry size (0 for object files)
    uint16_t e_phentsize = 0;
    std::memcpy(&elf_header[32], &e_phentsize, 2);
    
    // Number of program header entries
    uint16_t e_phnum = 0;
    std::memcpy(&elf_header[56], &e_phnum, 2);
    
    // Section header entry size
    uint16_t e_shentsize = 64;
    std::memcpy(&elf_header[60], &e_shentsize, 2);
    
    // Number of section headers
    uint16_t e_shnum = obj.sections.size() + 2;  // +2 for null and string table
    std::memcpy(&elf_header[62], &e_shnum, 2);
    
    file.write(reinterpret_cast<char*>(elf_header), 64);
    
    // Write section headers (simplified)
    for (const auto& section : obj.sections) {
        uint8_t sec_header[64];
        std::memset(sec_header, 0, 64);
        
        // Write section headers here...
        // (Simplified version - full implementation would be more detailed)
        
        file.write(reinterpret_cast<char*>(sec_header), 64);
    }
    
    // Write section data
    for (const auto& section : obj.sections) {
        file.write(reinterpret_cast<const char*>(section.data.data()), section.data.size());
    }
    
    file.close();
    log_info() << "Wrote ELF object file: " << filename << std::endl;
}
