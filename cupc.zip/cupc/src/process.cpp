#include "process.h"
#include <iostream>

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>

static std::string make_cmdline(const std::vector<std::string>& args) {
    // Build a quoted command line for CreateProcess
    std::string cmd;
    for (size_t i = 0; i < args.size(); ++i) {
        const std::string& a = args[i];
        bool need_quote = a.find(' ') != std::string::npos || a.empty();
        if (need_quote) cmd.push_back('"');
        for (char c : a) {
            if (c == '"') cmd += '\\', cmd += '"';
            else cmd += c;
        }
        if (need_quote) cmd.push_back('"');
        if (i + 1 < args.size()) cmd.push_back(' ');
    }
    return cmd;
}

int run_process(const std::vector<std::string>& args) {
    if (args.empty()) return -1;
    std::string cmdline = make_cmdline(args);

    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    BOOL ok = CreateProcessA(NULL, const_cast<char*>(cmdline.c_str()), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
    if (!ok) return -1;

    WaitForSingleObject(pi.hProcess, INFINITE);
    DWORD exit_code = 0;
    GetExitCodeProcess(pi.hProcess, &exit_code);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    return static_cast<int>(exit_code);
}

#else
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>

int run_process(const std::vector<std::string>& args) {
    if (args.empty()) return -1;
    pid_t pid = fork();
    if (pid < 0) return -1;
    if (pid == 0) {
        // Child
        std::vector<char*> cargs;
        cargs.reserve(args.size() + 1);
        for (const auto& s : args) cargs.push_back(const_cast<char*>(s.c_str()));
        cargs.push_back(nullptr);
        execvp(cargs[0], cargs.data());
        _exit(127);
    }
    int status = 0;
    if (waitpid(pid, &status, 0) == -1) return -1;
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return -1;
}

#endif
