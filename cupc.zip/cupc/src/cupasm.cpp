// cupasm.cpp - Main assembler executable
#include "assembler.h"
#include <iostream>
#include "log.h"
#include <cstring>

void print_usage(const char* program_name) {
    std::cout << "Usage: " << program_name << " <input.asm> <output.o> [options]\n"
              << "Options:\n"
              << "  -h, --help          Show this help message\n"
              << "  -p, --platform PLAT Target platform (linux or windows)\n"
              << "  -v, --verbose       Verbose output\n";
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        print_usage(argv[0]);
        return 1;
    }
    
    std::string input_file = argv[1];
    std::string output_file = argv[2];
    std::string platform = "linux";  // Default
    bool verbose = false;
    
    // Parse options
    for (int i = 3; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "-h" || arg == "--help") {
            print_usage(argv[0]);
            return 0;
        } else if (arg == "-p" || arg == "--platform") {
            if (i + 1 < argc) {
                platform = argv[++i];
            }
        } else if (arg == "-v" || arg == "--verbose") {
            verbose = true;
        }
    }
    
    // Create assembler
    Assembler assembler(platform);
    
    if (verbose) {
        std::cout << "Assembling " << input_file << " for " << platform << "...\n";
    }
    
    // Parse input file
    if (!assembler.parse_file(input_file)) {
        log_error() << "Error: Failed to parse input file " << input_file << std::endl;
        return 1;
    }
    
    if (verbose) {
        std::cout << "Parsed successfully. Generating code...\n";
    }
    
    // Assemble
    ObjectFile object = assembler.assemble();
    
    if (verbose) {
        std::cout << "Generated " << object.sections.size() << " section(s).\n";
    }
    
    // Write object file
    if (!assembler.write_object(output_file, object)) {
        log_error() << "Error: Failed to write object file " << output_file << std::endl;
        return 1;
    }
    
    if (verbose) {
        std::cout << "Successfully wrote " << output_file << "\n";
    }
    
    return 0;
}
