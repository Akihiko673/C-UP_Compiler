#include "lexer.h"
#include <cctype>
#include <stdexcept>
#include <iostream>

const std::unordered_map<std::string, TokenType> Lexer::keywords = {
    {"int8", TokenType::INT8}, {"int16", TokenType::INT16}, {"int32", TokenType::INT32}, {"int64", TokenType::INT64}, {"int128", TokenType::INT128},
    {"dec32", TokenType::DEC32}, {"dec64", TokenType::DEC64}, {"dec128", TokenType::DEC128},
    {"u8", TokenType::U8}, {"bool", TokenType::BOOL}, {"null", TokenType::NULL_TYPE},
    {"struct", TokenType::STRUCT}, {"auto", TokenType::AUTO}, {"extern", TokenType::EXTERN},
    {"var", TokenType::VAR},
    {"const", TokenType::CONST},
    {"true", TokenType::TRUE}, {"false", TokenType::FALSE},
    {"if", TokenType::IF}, {"else", TokenType::ELSE},
    {"while", TokenType::WHILE}, {"for", TokenType::FOR}, {"loop", TokenType::LOOP}, {"match", TokenType::MATCH},
    {"defer", TokenType::DEFER}, {"return", TokenType::RETURN}, {"default", TokenType::DEFAULT},
    {"get", TokenType::GET},
    {"asm", TokenType::ASM}, {"tick", TokenType::TICK}, {"len", TokenType::LEN},
    {"catch", TokenType::CATCH},
    {"alloc", TokenType::ALLOC}, {"free", TokenType::FREE}, {"copy", TokenType::COPY},
    {"open", TokenType::OPEN}, {"close", TokenType::CLOSE},
    {"read", TokenType::READ}, {"write", TokenType::WRITE},
    {"create", TokenType::CREATE}, {"delete", TokenType::DELETE},
    {"rename", TokenType::RENAME}, {"mkdir", TokenType::MKDIR},
    {"rmdir", TokenType::RMDIR}, {"read_dir", TokenType::READ_DIR},
    {"get_size", TokenType::GET_SIZE}, {"get_mtime", TokenType::GET_MTIME},
    {"set_perms", TokenType::SET_PERMS},
    {"socket", TokenType::SOCKET}, {"connect", TokenType::CONNECT},
    {"listen", TokenType::LISTEN}, {"accept", TokenType::ACCEPT},
    {"module", TokenType::MODULE}, {"import", TokenType::IMPORT},
    {"namespace", TokenType::NAMESPACE},
    {"test", TokenType::TEST},
    {"say_ass_nasm", TokenType::SAY_ASS_NASM},
    {"say_ld_gcc", TokenType::SAY_LD_GCC},
    {"say_dbg", TokenType::SAY_DBG},
        // ifdef windows &  #else if haven't been implemented, but where used in the inline assembly.
        // I'd have to chack in codegen to see I've taken care of them.
        // endif also hasn't been implemented. if it's needed anyways.
};

char Lexer::advance() {
    current++;
    column++;
    return source[current - 1];
}

char Lexer::peek() const {
    if (is_at_end()) return '\0';
    return source[current];
}

char Lexer::peek_next() const {
    if (current + 1 >= source.size()) return '\0';
    return source[current + 1];
}

bool Lexer::is_at_end() const { return current >= source.size(); }

bool Lexer::match(char expected) {
    if (is_at_end() || source[current] != expected) return false;
    advance();
    return true;
}

Token Lexer::make_token(TokenType type) {
    return Token{type, source.substr(start, current - start), line, column, start};
}

Token Lexer::error_token(const std::string& message) {
    return Token{TokenType::INVALID, message, line, column, start};
}

Token Lexer::number() {
    while (std::isdigit(peek())) advance();
    
    // Check for decimal
    if (peek() == '.' && std::isdigit(peek_next())) {
        advance(); // consume '.'
        while (std::isdigit(peek())) advance();
    }
    
    return make_token(TokenType::NUMBER);
}

Token Lexer::string() {
    std::string value;
    while (peek() != '"' && !is_at_end()) {
        if (peek() == '\n') {
            line++;
            column = 1;
        }
        if (peek() == '\\') {
            advance(); // consume backslash
            if (is_at_end()) {
                return error_token("Unterminated escape sequence.");
            }
            char escaped = peek();
            switch (escaped) {
                case 'n':  value += '\n'; break;  // newline
                case 't':  value += '\t'; break;  // tab
                case 'r':  value += '\r'; break;  // carriage return
                case '0':  value += '\0'; break;  // null
                case 'f':  value += '\f'; break;  // form feed
                case 'b':  value += '\b'; break;  // backspace
                case 'v':  value += '\v'; break;  // vertical tab
                case '"':  value += '"'; break;   // escaped quote
                case '\\': value += '\\'; break;  // escaped backslash
                default:
                    // Unknown escape sequence - include the backslash and character as-is
                    value += '\\';
                    value += escaped;
                    break;
            }
            advance(); // consume the escaped character
        } else {
            value += peek();
            advance();
        }
    }
    
    if (is_at_end()) return error_token("Unterminated string.");
    advance(); // Closing "
    
    return Token{TokenType::STRING, value, line, column, start};
}

Token Lexer::identifier() {
    while (std::isalnum(peek()) || peek() == '_') advance();
    
    std::string text = source.substr(start, current - start);
    TokenType type = TokenType::IDENTIFIER;
    
    if (keywords.count(text)) {
        type = keywords.at(text);
    }
    
    return Token{type, text, line, column, start};
}

void Lexer::skip_whitespace() {
    while (true) {
        char c = peek();
        switch (c) {
            case ' ':
            case '\r':
            case '\t':
                advance();
                break;
            case '\n':
                line++;
                column = 1;
                advance();
                break;
            case '/':
                if (peek_next() == '/') {
                    skip_comment();
                } else if (peek_next() == '*') {
                    // Consume '/*'
                    advance();
                    advance();
                    if (!skip_block_comment()) {
                        // Unterminated block comment; let tokenize handle error reporting
                        return;
                    }
                } else {
                    return;
                }
                break;
            default:
                return;
        }
    }
}

void Lexer::skip_comment() {
    while (peek() != '\n' && !is_at_end()) advance();
}

bool Lexer::skip_block_comment() {
    while (!is_at_end()) {
        char c = advance();
        if (c == '\n') {
            line++; column = 1;
        } else if (c == '*' && peek() == '/') {
            advance(); // consume '/'
            return true;
        }
    }
    // Unterminated block comment
    unterminated_block_comment = true;
    return false;
}

std::vector<Token> Lexer::tokenize() {
    std::vector<Token> tokens;
    
    while (!is_at_end()) {
        skip_whitespace();
        if (unterminated_block_comment) { start = current; tokens.push_back(error_token("Unterminated block comment")); break; }
        if (is_at_end()) break;
        start = current;
        
        char c = advance();
        
        switch (c) {
            case '(': tokens.push_back(make_token(TokenType::LEFT_PAREN)); break;
            case ')': tokens.push_back(make_token(TokenType::RIGHT_PAREN)); break;
            case '{': tokens.push_back(make_token(TokenType::LEFT_BRACE)); break;
            case '}': tokens.push_back(make_token(TokenType::RIGHT_BRACE)); break;
            case '[': tokens.push_back(make_token(TokenType::LEFT_BRACKET)); break;
            case ']': tokens.push_back(make_token(TokenType::RIGHT_BRACKET)); break;
            case ',': tokens.push_back(make_token(TokenType::COMMA)); break;
            case ';': tokens.push_back(make_token(TokenType::SEMICOLON)); break;
            case '@': tokens.push_back(make_token(TokenType::AT)); break;
            case '.': 
                if (match('*')) {
                    tokens.push_back(make_token(TokenType::DOT_STAR));
                } else {
                    tokens.push_back(make_token(TokenType::DOT));
                }
                break;
            case '+':
                if (match('+')) {
                    tokens.push_back(make_token(TokenType::INCREMENT));
                } else if (match('=')) {
                    tokens.push_back(make_token(TokenType::PLUS_EQUAL));
                } else {
                    tokens.push_back(make_token(TokenType::PLUS));
                }
                break;
            case '-':
                if (match('>')) {
                    tokens.push_back(make_token(TokenType::ARROW));
                } else if (match('-')) {
                    tokens.push_back(make_token(TokenType::DECREMENT));
                } else if (match('=')) {
                    tokens.push_back(make_token(TokenType::MINUS_EQUAL));
                } else {
                    tokens.push_back(make_token(TokenType::MINUS));
                }
                break;
            case '*':
                if (match('=')) {
                    tokens.push_back(make_token(TokenType::STAR_EQUAL));
                } else {
                    tokens.push_back(make_token(TokenType::STAR));
                }
                break;
            case '/':
                if (match('=')) {
                    tokens.push_back(make_token(TokenType::SLASH_EQUAL));
                } else {
                    tokens.push_back(make_token(TokenType::SLASH));
                }
                break;
            case '%':
                if (match('=')) {
                    tokens.push_back(make_token(TokenType::MODULO_EQUAL));
                } else {
                    tokens.push_back(make_token(TokenType::MODULO));
                }
                break;
            case '^':
                tokens.push_back(make_token(TokenType::CARET));
                break;
            case '!':
                if (match('=')) {
                    tokens.push_back(make_token(TokenType::BANG_EQUAL));
                } else {
                    tokens.push_back(make_token(TokenType::BANG));
                }
                break;
            case '=':
                if (match('=')) {
                    tokens.push_back(make_token(TokenType::EQUAL_EQUAL));
                } else if (match('>')) {
                    tokens.push_back(make_token(TokenType::ARROW));
                } else {
                    tokens.push_back(make_token(TokenType::EQUAL));
                }
                break;
            case '<':
                if (match('=')) {
                    tokens.push_back(make_token(TokenType::LESS_EQUAL));
                } else {
                    tokens.push_back(make_token(TokenType::LESS));
                }
                break;
            case '>':
                if (match('=')) {
                    tokens.push_back(make_token(TokenType::GREATER_EQUAL));
                } else {
                    tokens.push_back(make_token(TokenType::GREATER));
                }
                break;
            case '&':
                if (match('&')) {
                    tokens.push_back(make_token(TokenType::AMP_AMP));
                } else {
                    tokens.push_back(make_token(TokenType::AMP));
                }
                break;
            case '|':
                if (match('|')) {
                    tokens.push_back(make_token(TokenType::PIPE_PIPE));
                } else {
                    tokens.push_back(make_token(TokenType::PIPE));
                }
                break;
            case '?':
                tokens.push_back(make_token(TokenType::QUESTION));
                break;
            case '"':
                tokens.push_back(string());
                break;
            case '#':
                // Handle directives like #derive, #const, etc.
                // Important: 'derive' is ONLY a directive now (must be prefixed by '#').
                if (std::isalpha(peek()) || peek() == '_') {
                    size_t directive_start = current; // right after '#'
                    while (std::isalnum(peek()) || peek() == '_') advance();
                    std::string text = source.substr(directive_start, current - directive_start);

                    if (text == "derive") {
                        tokens.push_back(Token{TokenType::DERIVE, text, line, column, start});
                    } else if (text == "say_ass_nasm") {
                        tokens.push_back(Token{TokenType::SAY_ASS_NASM, text, line, column, start});
                    } else if (text == "say_ld_gcc") {
                        tokens.push_back(Token{TokenType::SAY_LD_GCC, text, line, column, start});
                    } else if (text == "say_dbg") {
                        tokens.push_back(Token{TokenType::SAY_DBG, text, line, column, start});
                    } else {
                        tokens.push_back(Token{TokenType::IDENTIFIER, text, line, column, start});
                    }
                }
                break;
            case ':':
                if (match(':')) {
                    tokens.push_back(make_token(TokenType::COLON_COLON));
                } else {
                    tokens.push_back(make_token(TokenType::COLON));
                }
                break;
            default:
                if (std::isdigit(c)) {
                    tokens.push_back(number());
                } else if (std::isalpha(c) || c == '_') {
                    Token t = identifier();
                    // Special handling for asm { ... } blocks: capture raw assembly until matching '}'
                    if (t.type == TokenType::ASM) {
                        // Skip whitespace (but keep line counting for newlines)
                        while (peek() == ' ' || peek() == '\t' || peek() == '\r') advance();
                        if (peek() == '{') {
                            advance(); // consume '{'
                            std::string asm_text;
                            int depth = 1;
                            while (!is_at_end() && depth > 0) {
                                char ch = advance();
                                if (ch == '{') {
                                    depth++; asm_text += ch;
                                } else if (ch == '}') {
                                    depth--; if (depth > 0) asm_text += ch;
                                } else {
                                    if (ch == '\n') { line++; column = 1; }
                                    asm_text += ch;
                                }
                            }
                            if (depth != 0) {
                                tokens.push_back(error_token("Unterminated asm block"));
                            } else {
                                tokens.push_back(Token{TokenType::ASM, asm_text, line, column, start});
                            }
                            break;
                        }
                    }
                    tokens.push_back(t);
                } else {
                    tokens.push_back(error_token("Unexpected character: " + std::string(1, c)));
                }
                break;
        }
    }
    
    tokens.push_back(Token{TokenType::END_OF_FILE, "", line, column, start});
    return tokens;
}