// assembler.cpp - Main assembler something
#include "assembler.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <cstring>
#include "log.h"
#include <iostream>

Assembler::Assembler(const std::string& platform) 
    : target_platform(platform), 
      symbol_table(),
      defined_symbols(),
      external_symbols(),
      current_section(0),
      current_offset(0) {}

bool Assembler::parse_file(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        log_error() << "Error: Cannot open file " << filename << std::endl;
        return false;
    }
    
    std::string line;
    int line_num = 0;
    
    while (std::getline(file, line)) {
        line_num++;
        
        // Remove comments
        size_t comment_pos = line.find(';');
        if (comment_pos != std::string::npos) {
            line = line.substr(0, comment_pos);
        }
        
        // Trim whitespace
        line.erase(0, line.find_first_not_of(" \t\r\n"));
        line.erase(line.find_last_not_of(" \t\r\n") + 1);
        
        // Skip empty lines
        if (line.empty()) continue;
        
        source_lines.push_back(line);
        if (!parse_line(line, line_num)) {
            log_error() << "Error parsing line " << line_num << ": " << line << std::endl;
            return false;
        }
    }
    
    return true;
}

bool Assembler::parse_line(const std::string& line, int line_num) {
    // Check if it's a label (ends with :)
    if (!line.empty() && line.back() == ':') {
        // Label definition - remove the colon
        std::string label_name = line.substr(0, line.length() - 1);
        define_symbol(label_name, current_offset, 0);  // 0 = .text section
        return true;
    }
    
    // Check if it's a directive (starts with . or is a keyword)
    size_t first_non_space = line.find_first_not_of(" \t");
    if (first_non_space != std::string::npos) {
        std::string trimmed_line = line.substr(first_non_space);
        
        // Check for directives and keywords
        if (trimmed_line[0] == '.' || 
            (trimmed_line.length() >= 6 && trimmed_line.substr(0, 6) == "extern") || 
            (trimmed_line.length() >= 6 && trimmed_line.substr(0, 6) == "global") ||
            (trimmed_line.length() >= 7 && trimmed_line.substr(0, 7) == "section")) {
            return parse_directive(trimmed_line);
        }
        
        // Parse as instruction
        Instruction instr;
        if (parse_instruction(trimmed_line, instr)) {
            instr.raw_line = line;
            instr.line_number = line_num;
            instructions.push_back(instr);
            current_offset += 8;  // Estimated instruction size (will be refined during encoding)
            return true;
        }
    }
    
    return false;
}

bool Assembler::parse_instruction(const std::string& line, Instruction& instr) {
    std::istringstream iss(line);
    
    // Extract mnemonic
    std::string token;
    iss >> token;
    
    // Handle instruction with size suffix (movsd, movq, etc.)
    instr.mnemonic = token;
    
    // Extract operands
    std::string rest;
    std::getline(iss, rest);
    
    // Trim leading whitespace from rest
    rest.erase(0, rest.find_first_not_of(" \t"));
    
    if (!rest.empty()) {
        instr.operands = parse_operands(rest);
    }
    
    return true;
}

std::vector<Operand> Assembler::parse_operands(const std::string& operand_str) {
    std::vector<Operand> operands;
    std::string current;
    int bracket_depth = 0;
    
    for (size_t i = 0; i < operand_str.length(); i++) {
        char c = operand_str[i];
        
        if (c == '[') {
            bracket_depth++;
            current += c;
        } else if (c == ']') {
            bracket_depth--;
            current += c;
        } else if (c == ',' && bracket_depth == 0) {
            // End of operand
            current.erase(0, current.find_first_not_of(" \t"));
            current.erase(current.find_last_not_of(" \t") + 1);
            if (!current.empty()) {
                operands.push_back(parse_operand(current));
            }
            current.clear();
        } else {
            current += c;
        }
    }
    
    // Handle last operand
    current.erase(0, current.find_first_not_of(" \t"));
    current.erase(current.find_last_not_of(" \t") + 1);
    if (!current.empty()) {
        operands.push_back(parse_operand(current));
    }
    
    return operands;
}

Operand Assembler::parse_operand(const std::string& operand_str) {
    Operand op;
    
    // Memory operand: [...]
    if (operand_str[0] == '[' && operand_str.back() == ']') {
        op.type = Operand::Type::MEMORY;
        std::string mem_content = operand_str.substr(1, operand_str.length() - 2);
        
        // Check for rip-relative
        if (mem_content.find("rel ") == 0) {
            op.rip_relative = true;
            op.label = mem_content.substr(4);
        } else {
            // Parse base + displacement + scaled index
            // Simple case: [reg], [reg + offset], [reg + reg*scale]
            // For now, just store as-is
            op.base_reg = mem_content;
        }
        return op;
    }
    
    // Immediate: number or hex
    if (std::isdigit(operand_str[0]) || operand_str[0] == '-') {
        op.type = Operand::Type::IMMEDIATE;
        if (operand_str.find("0x") != std::string::npos) {
            op.immediate_value = std::stoll(operand_str, nullptr, 16);
        } else {
            op.immediate_value = std::stoll(operand_str);
        }
        return op;
    }
    
    // Register or label
    if (operand_str.find("rax") != std::string::npos ||
        operand_str.find("rbx") != std::string::npos ||
        operand_str.find("rcx") != std::string::npos ||
        operand_str.find("rdx") != std::string::npos ||
        operand_str.find("rsi") != std::string::npos ||
        operand_str.find("rdi") != std::string::npos ||
        operand_str.find("rbp") != std::string::npos ||
        operand_str.find("rsp") != std::string::npos ||
        operand_str.find("r8") != std::string::npos ||
        operand_str.find("r9") != std::string::npos ||
        operand_str.find("r10") != std::string::npos ||
        operand_str.find("r11") != std::string::npos ||
        operand_str.find("r12") != std::string::npos ||
        operand_str.find("r13") != std::string::npos ||
        operand_str.find("r14") != std::string::npos ||
        operand_str.find("r15") != std::string::npos ||
        operand_str.find("xmm") != std::string::npos ||
        operand_str.find("al") != std::string::npos ||
        operand_str.find("eax") != std::string::npos) {
        
        op.type = Operand::Type::REGISTER;
        op.reg_name = operand_str;
    } else {
        // Assume it's a label
        op.type = Operand::Type::LABEL;
        op.label_name = operand_str;
    }
    
    return op;
}

ObjectFile Assembler::assemble() {
    if (target_platform == "linux") {
        return generate_elf();
    } else {
        return generate_coff();
    }
}

ObjectFile Assembler::generate_elf() {
    ObjectFile obj;
    obj.format = "elf64";
    
    Section code_section;
    code_section.name = ".text";
    code_section.flags = 0x6;  // SHF_ALLOC | SHF_EXECINSTR
    
    std::vector<Relocation> relocs;
    uint64_t offset = 0;
    
    // Assemble each instruction
    for (const auto& instr : instructions) {
        auto machine_code = assemble_instruction(instr, offset, relocs);
        code_section.data.insert(code_section.data.end(),
                                machine_code.begin(),
                                machine_code.end());
        offset += machine_code.size();
    }
    
    code_section.relocations = relocs;
    obj.sections.push_back(code_section);
    
    // Copy symbol tables to ObjectFile
    for (const auto& sym : defined_symbols) {
        obj.global_symbols[sym.name] = sym;
    }
    for (const auto& sym : external_symbols) {
        obj.external_symbols[sym.name] = sym;
    }
    
    return obj;
}

ObjectFile Assembler::generate_coff() {
    ObjectFile obj;
    obj.format = "coff";
    
    Section code_section;
    code_section.name = ".text";
    code_section.flags = 0x60000020;  // IMAGE_SCN_CNT_CODE | IMAGE_SCN_MEM_EXECUTE | IMAGE_SCN_MEM_READ
    
    std::vector<Relocation> relocs;
    uint64_t offset = 0;
    
    // Assemble each instruction
    for (const auto& instr : instructions) {
        auto machine_code = assemble_instruction(instr, offset, relocs);
        code_section.data.insert(code_section.data.end(),
                                machine_code.begin(),
                                machine_code.end());
        offset += machine_code.size();
    }
    
    code_section.relocations = relocs;
    obj.sections.push_back(code_section);
    
    // Copy symbol tables to ObjectFile
    for (const auto& sym : defined_symbols) {
        obj.global_symbols[sym.name] = sym;
    }
    for (const auto& sym : external_symbols) {
        obj.external_symbols[sym.name] = sym;
    }
    
    return obj;
}

std::vector<uint8_t> Assembler::assemble_instruction(const Instruction& instr,
                                                     uint64_t offset,
                                                     std::vector<Relocation>& relocs) {
    return InstructionEncoder::encode(instr, offset, relocs, this);
}

bool Assembler::write_object(const std::string& filename, const ObjectFile& obj) {
    if (obj.format == "elf64") {
        write_elf_file(filename, obj);
    } else if (obj.format == "coff") {
        write_coff_file(filename, obj);
    } else {
        return false;
    }
    return true;
}

// Symbol management implementation
bool Assembler::parse_directive(const std::string& line) {
    // Handle "extern" or ".extern"
    if (line.substr(0, 6) == "extern" || line.substr(0, 7) == ".extern") {
        size_t start = (line[0] == '.') ? 7 : 6;
        if (start < line.length()) {
            std::string symbol_name = line.substr(start);
            symbol_name.erase(0, symbol_name.find_first_not_of(" \t"));
            symbol_name.erase(symbol_name.find_last_not_of(" \t") + 1);
            if (!symbol_name.empty()) {
                reference_external(symbol_name);
            }
        }
        return true;
    }
    
    // Handle "global" or ".global"
    if (line.substr(0, 6) == "global" || line.substr(0, 7) == ".global") {
        size_t start = (line[0] == '.') ? 7 : 6;
        if (start < line.length()) {
            std::string symbol_name = line.substr(start);
            symbol_name.erase(0, symbol_name.find_first_not_of(" \t"));
            symbol_name.erase(symbol_name.find_last_not_of(" \t") + 1);
            // Mark symbol as globally visible (will be handled during object file generation)
            if (!symbol_name.empty() && symbol_table.find(symbol_name) != symbol_table.end()) {
                symbol_table[symbol_name].is_external = false;  // It's defined globally
            }
        }
        return true;
    }
    
    // Handle "section" or ".section"
    if (line.substr(0, 7) == "section" || line.substr(0, 8) == ".section") {
        // Section directive: .section .text
        // For now, we only support .text section
        return true;
    }
    
    // Ignore unknown directives
    return true;
}

void Assembler::define_symbol(const std::string& name, uint64_t offset, int section) {
    if (symbol_table.find(name) != symbol_table.end()) {
        // Symbol already defined - for now allow redefinition
        symbol_table[name].offset = offset;
        symbol_table[name].section_index = section;
        symbol_table[name].is_defined = true;
    } else {
        Symbol sym;
        sym.name = name;
        sym.offset = offset;
        sym.section_index = section;
        sym.is_defined = true;
        sym.is_external = false;
        sym.storage_class = 2;  // C_EXT (external symbol)
        sym.num_aux_symbols = 0;
        symbol_table[name] = sym;
        defined_symbols.push_back(sym);
    }
}

void Assembler::reference_external(const std::string& name) {
    if (symbol_table.find(name) == symbol_table.end()) {
        Symbol sym;
        sym.name = name;
        sym.is_external = true;
        sym.is_defined = false;
        sym.section_index = -1;  // External symbols don't have a section
        sym.storage_class = 2;   // C_EXT
        symbol_table[name] = sym;
        external_symbols.push_back(sym);
    }
}

Symbol* Assembler::resolve_symbol(const std::string& name) {
    auto it = symbol_table.find(name);
    if (it != symbol_table.end()) {
        return &it->second;
    }
    return nullptr;
}

// Object file writing implementations are in coff_writer.cpp
// Instruction Encoder Implementation moved to x86_encoder.cpp
// (See x86_encoder.cpp for actual encoder implementations)
