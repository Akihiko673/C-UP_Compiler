#include "parser.h"
#include <stdexcept>
#include <iostream>
#include <memory>

Parser::Parser(const std::vector<Token>& t, SymbolTable& st) 
    : tokens(t), symbol_table(st) {}

const Token& Parser::peek() {
    return tokens[current];
}

const Token& Parser::previous() {
    return tokens[current - 1];
}

bool Parser::is_at_end() {
    return peek().type == TokenType::END_OF_FILE;
}

bool Parser::check(TokenType type) {
    if (is_at_end()) return false;
    return peek().type == type;
}

bool Parser::match(TokenType type) {
    if (!check(type)) return false;
    current++;
    return true;
}

Token Parser::consume(TokenType type, const std::string& message) {
    if (check(type)) {
        current++;
        return previous();
    }
    errors.push_back({message, peek()});
    return Token{TokenType::INVALID, "", 0, 0, 0};
}

void Parser::synchronize() {
    while (!is_at_end()) {
        if (previous().type == TokenType::SEMICOLON) return;
        switch (peek().type) {
            case TokenType::IF:
            case TokenType::WHILE:
            case TokenType::LOOP:
            case TokenType::MATCH:
            case TokenType::DEFER:
            case TokenType::RETURN:
                return;
            default:
                break;
        }
        current++;
    }
}

std::unique_ptr<ExprNode> Parser::expression() {
    return logical_or();
}

std::unique_ptr<ExprNode> Parser::logical_or() {
    auto left = logical_and();
    while (match(TokenType::PIPE_PIPE)) {
        auto right = logical_and();
        left = std::make_unique<BinaryExpr>(TokenType::PIPE_PIPE, std::move(left), std::move(right));
    }
    return left;
}

std::unique_ptr<ExprNode> Parser::logical_and() {
    auto left = bitwise_or();
    while (match(TokenType::AMP_AMP)) {
        auto right = bitwise_or();
        left = std::make_unique<BinaryExpr>(TokenType::AMP_AMP, std::move(left), std::move(right));
    }
    return left;
}

std::unique_ptr<ExprNode> Parser::bitwise_or() {
    auto left = bitwise_xor();
    while (match(TokenType::PIPE)) {
        auto right = bitwise_xor();
        left = std::make_unique<BinaryExpr>(TokenType::PIPE, std::move(left), std::move(right));
    }
    return left;
}

std::unique_ptr<ExprNode> Parser::bitwise_xor() {
    auto left = bitwise_and();
    while (match(TokenType::CARET)) {
        auto right = bitwise_and();
        left = std::make_unique<BinaryExpr>(TokenType::CARET, std::move(left), std::move(right));
    }
    return left;
}

std::unique_ptr<ExprNode> Parser::bitwise_and() {
    auto left = equality();
    while (match(TokenType::AMP)) {
        auto right = equality();
        left = std::make_unique<BinaryExpr>(TokenType::AMP, std::move(left), std::move(right));
    }
    return left;
}

std::unique_ptr<ExprNode> Parser::equality() {
    auto left = comparison();
    while (match(TokenType::EQUAL_EQUAL) || match(TokenType::BANG_EQUAL)) {
        TokenType op = previous().type;
        auto right = comparison();
        left = std::make_unique<BinaryExpr>(op, std::move(left), std::move(right));
    }
    return left;
}

std::unique_ptr<ExprNode> Parser::comparison() {
    auto left = term();
    while (match(TokenType::LESS) || match(TokenType::GREATER) || 
           match(TokenType::LESS_EQUAL) || match(TokenType::GREATER_EQUAL)) {
        TokenType op = previous().type;
        auto right = term();
        left = std::make_unique<BinaryExpr>(op, std::move(left), std::move(right));
    }
    return left;
}

std::unique_ptr<ExprNode> Parser::term() {
    auto left = factor();
    while (match(TokenType::PLUS) || match(TokenType::MINUS)) {
        TokenType op = previous().type;
        auto right = factor();
        left = std::make_unique<BinaryExpr>(op, std::move(left), std::move(right));
    }
    return left;
}

std::unique_ptr<ExprNode> Parser::factor() {
    auto left = unary();
    while (match(TokenType::STAR) || match(TokenType::SLASH) || match(TokenType::MODULO)) {
        TokenType op = previous().type;
        auto right = unary();
        left = std::make_unique<BinaryExpr>(op, std::move(left), std::move(right));
    }
    return left;
}

std::unique_ptr<ExprNode> Parser::unary() {
    if (match(TokenType::BANG) || match(TokenType::MINUS)) {
        TokenType op = previous().type;
        auto right = unary();
        return std::make_unique<UnaryExpr>(op, std::move(right));
    }
    if (match(TokenType::INCREMENT) || match(TokenType::DECREMENT)) {
        TokenType op = previous().type;
        auto expr = unary();
        return std::make_unique<IncrementExpr>(op, std::move(expr));
    }
    if (match(TokenType::GET)) {
        auto expr = unary();
        return std::make_unique<GetExpr>(std::move(expr));
    }
    return call();
}

std::unique_ptr<ExprNode> Parser::call() {
    auto expr = primary();
    
    while (true) {
        if (match(TokenType::LEFT_PAREN)) {
            // Function call
            std::string func_name;
            std::string module_name = "";
            
            // Check if this is a module.function call
            if (auto* field = dynamic_cast<FieldAccessExpr*>(expr.get())) {
                if (auto* obj = dynamic_cast<IdentifierExpr*>(field->object.get())) {
                    module_name = obj->name;
                    func_name = field->field_name;
                    expr.reset();  // Clear expr since we extracted the info
                            } else {
                                errors.push_back({"Expected module name before function call", previous()});
                                return nullptr;
                            }
                        } else if (auto* id = dynamic_cast<IdentifierExpr*>(expr.get())) {
                            func_name = id->name;
                        } else {
                            errors.push_back({"Expected function name", previous()});
                            return nullptr;
                        }            
            std::vector<std::unique_ptr<ExprNode>> arguments;
            if (!check(TokenType::RIGHT_PAREN)) {
                do {
                    arguments.push_back(expression());
                } while (match(TokenType::COMMA));
            }
            consume(TokenType::RIGHT_PAREN, "Expected ')' after arguments");
            
            if (!module_name.empty()) {
                expr = std::make_unique<CallExpr>(module_name, func_name, std::move(arguments));
            } else {
                expr = std::make_unique<CallExpr>(func_name, std::move(arguments));
            }
        }
        else if (match(TokenType::LEFT_BRACKET)) {
            // Array indexing
            auto index = expression();
            consume(TokenType::RIGHT_BRACKET, "Expected ']'");
            expr = std::make_unique<IndexExpr>(std::move(expr), std::move(index));
        }
        else if (match(TokenType::COLON_COLON)) {
            // Namespace access: namespace::identifier
            Token ns_name = previous();  // This was the left side of ::
            Token name = consume(TokenType::IDENTIFIER, "Expected identifier after '::'");

            // Create a field access expression for namespace access
            auto ns_expr = std::make_unique<IdentifierExpr>(ns_name.lexeme);
            expr = std::make_unique<FieldAccessExpr>(std::move(ns_expr), name.lexeme);
        }
        else if (match(TokenType::DOT)) {
            // Field access or dereference
            if (match(TokenType::STAR)) {
                expr = std::make_unique<DerefExpr>(std::move(expr));
            } else {
                Token field = consume(TokenType::IDENTIFIER, "Expected field name");
                expr = std::make_unique<FieldAccessExpr>(std::move(expr), field.lexeme);
            }
        }
        else if (match(TokenType::QUESTION)) {
            // Error propagation operator: expr?
            // Wrap the expression in an error propagation expression
            expr = std::make_unique<ErrorPropagationExpr>(std::move(expr));
        }
        else {
            break;
        }
    }

    return expr;
}

std::unique_ptr<ExprNode> Parser::primary() {
    if (match(TokenType::NUMBER)) {
        Token prev = previous();
        if (prev.lexeme.find('.') != std::string::npos) {
            return std::make_unique<NumberExpr>(prev.fvalue);
        } else {
            return std::make_unique<NumberExpr>(prev.value);
        }
    }
    if (match(TokenType::STRING)) {
        return std::make_unique<StringExpr>(previous().lexeme);
    }
    if (match(TokenType::TICK)) {
        return std::make_unique<TickExpr>();
    }
    if (match(TokenType::LEN)) {
        consume(TokenType::LEFT_PAREN, "Expected '(' after 'len'");
        auto array = expression();
        consume(TokenType::RIGHT_PAREN, "Expected ')'");
        return std::make_unique<LengthExpr>(std::move(array));
    }
    // Identifiers + builtins are treated uniformly as callable names in expressions.
    if (check(TokenType::IDENTIFIER) ||
        check(TokenType::ALLOC) || check(TokenType::FREE) || check(TokenType::COPY) ||
        check(TokenType::OPEN) || check(TokenType::CLOSE) || check(TokenType::READ) || check(TokenType::WRITE) ||
        check(TokenType::NOW) || check(TokenType::SLEEP) ||
        check(TokenType::SOCKET) || check(TokenType::CONNECT) || check(TokenType::LISTEN) || check(TokenType::ACCEPT) ||
        check(TokenType::CREATE) || check(TokenType::DELETE) || check(TokenType::RENAME) ||
        check(TokenType::MKDIR) || check(TokenType::RMDIR) || check(TokenType::READ_DIR) ||
        check(TokenType::GET_SIZE) || check(TokenType::GET_MTIME) || check(TokenType::SET_PERMS)) {
        current++;
        return std::make_unique<IdentifierExpr>(previous().lexeme);
    }
    if (match(TokenType::TRUE)) {
        return std::make_unique<NumberExpr>(1);
    }
    if (match(TokenType::FALSE)) {
        return std::make_unique<NumberExpr>(0);
    }
    // `null` is tokenized as NULL_TYPE by the lexer, and is also a valid literal.
    if (match(TokenType::NULL_TYPE)) {
        return std::make_unique<NumberExpr>(0);
    }
    if (match(TokenType::LEFT_PAREN)) {
        auto expr = expression();
        consume(TokenType::RIGHT_PAREN, "Expected ')' after expression");
        return expr;
    }
    if (match(TokenType::LEFT_BRACKET)) {
        return array_literal();
    }
    // Struct literal: `{ field: expr, ... }`
    if (match(TokenType::LEFT_BRACE)) {
        std::vector<std::pair<std::string, std::unique_ptr<ExprNode>>> fields;
        if (!check(TokenType::RIGHT_BRACE)) {
            do {
                Token name = consume(TokenType::IDENTIFIER, "Expected field name in struct literal");
                consume(TokenType::COLON, "Expected ':' after field name");
                auto val = expression();
                fields.emplace_back(name.lexeme, std::move(val));
            } while (match(TokenType::COMMA));
        }
        consume(TokenType::RIGHT_BRACE, "Expected '}' after struct literal");
        return std::make_unique<StructLiteralExpr>(std::move(fields));
    }
    
    errors.push_back({"Expected expression", peek()});
    return nullptr;
}

std::unique_ptr<ExprNode> Parser::array_literal() {
    // Already consumed '['
    std::vector<std::unique_ptr<ExprNode>> elements;
    
    if (!check(TokenType::RIGHT_BRACKET)) {
        do {
            elements.push_back(expression());
        } while (match(TokenType::COMMA));
    }
    
    consume(TokenType::RIGHT_BRACKET, "Expected ']'");
    return std::make_unique<ArrayLiteralExpr>(std::move(elements));
}

std::unique_ptr<ExprNode> Parser::postfix() {
    throw std::runtime_error("Postfix not used in this parser design");
}

std::unique_ptr<ExprNode> Parser::tick_expression() {
    throw std::runtime_error("Tick handled in primary()");
}

std::unique_ptr<ExprNode> Parser::length_expression() {
    throw std::runtime_error("Length handled in primary()");
}

std::unique_ptr<ExprNode> Parser::parse_expression(Precedence prec) {
    (void)prec; // Parameter unused in this parser design
    throw std::runtime_error("Not using Pratt parser");
}

std::unique_ptr<ExprNode> Parser::error_union() {
    throw std::runtime_error("Error union handled in type parsing");
}

std::unique_ptr<StmtNode> Parser::statement() {
    // Colon-default shorthand declarations (": x = ...") are disallowed.
    if (match(TokenType::COLON)) {
        errors.push_back({"shorthand declarations using ':' are not allowed; use an explicit type (e.g. 'int64: x = ...;')", previous()});
        return nullptr;
    }
    
    // Type declarations
    if (check(TokenType::CONST)) {
        return var_declaration();
    }
    
    if (check(TokenType::INT8) || check(TokenType::INT16) || check(TokenType::INT32) || check(TokenType::INT64) || check(TokenType::INT128) ||
        check(TokenType::DEC32) || check(TokenType::DEC64) || check(TokenType::DEC128) || check(TokenType::U8) || check(TokenType::BOOL) || 
        check(TokenType::NULL_TYPE) || check(TokenType::AUTO) || check(TokenType::BANG)) {
        return var_declaration();
    }

    // User-defined type declarations inside function bodies: `TypeName: var ...;`
    // Lookahead to disambiguate from using an identifier in an expression.
    if (check(TokenType::IDENTIFIER)) {
        if (current + 1 < tokens.size() && tokens[current + 1].type == TokenType::COLON) {
            return var_declaration();
        }
    }
    
    if (match(TokenType::IF)) {
        return if_statement();
    }
    if (match(TokenType::WHILE)) {
        return while_statement();
    }
    if (match(TokenType::FOR)) {
        return for_statement();
    }
    if (match(TokenType::LOOP)) {
        // Infinite loop: loop { ... }
        consume(TokenType::LEFT_BRACE, "Expected '{' after 'loop'");
        std::vector<std::unique_ptr<StmtNode>> body;
        while (!check(TokenType::RIGHT_BRACE) && !is_at_end()) {
            body.push_back(statement());
        }
        consume(TokenType::RIGHT_BRACE, "Expected '}'");
        return std::make_unique<WhileStmt>(std::make_unique<NumberExpr>(1), std::move(body));
    }
    if (match(TokenType::MATCH)) {
        return match_statement();
    }
    if (match(TokenType::DEFER)) {
        return defer_statement();
    }
    if (match(TokenType::RETURN)) {
        return return_statement();
    }
    if (match(TokenType::ASM)) {
        std::string asm_code = previous().lexeme;
        // Also add to assembly sections collection to ensure it gets included in final output
        add_assembly_section(asm_code);
        return std::make_unique<AsmStmt>(asm_code);
    }
    if (match(TokenType::LEFT_BRACE)) {
        return block_statement();
    }
    
    return assignment_or_expression();
}

std::unique_ptr<VarDeclStmt> Parser::var_declaration() {
    // Support `const <type>: name = ...;` for compile-time constants
    // `auto` is a storage/cleanup modifier (automatic cleanup at scope exit).
    bool is_auto_modifier = false;
    bool is_const = false;
    
    if (match(TokenType::CONST)) {
        is_const = true;
    } else if (match(TokenType::AUTO)) {
        is_auto_modifier = true;
    }

    std::shared_ptr<Type> type = parse_type();
    consume(TokenType::COLON, "Expected ':' after type");
    std::string name = consume(TokenType::IDENTIFIER, "Expected variable name").lexeme;
    
    // Variable declarations have '=' or ';' after the name
    // Function declarations have '(' after the name
    // If we see '(', this was actually a function declaration, not a variable
    if (check(TokenType::LEFT_PAREN)) {
        errors.push_back({"Variable declaration expected, but found '(' (this is a function declaration)", peek()});
        return nullptr;
    }
    
    std::unique_ptr<ExprNode> initializer;
    if (is_const) {
        // const declarations MUST have an initializer
        if (!match(TokenType::EQUAL)) {
            errors.push_back({"const declarations must have an initializer", peek()});
            return nullptr;
        }
        initializer = expression();
    } else {
        // For colon-default shorthand `: x = expr;` require initializer and attempt to infer type
        if (match(TokenType::EQUAL)) {
            initializer = expression();
        } else {
            errors.push_back({"shorthand declarations require an initializer", peek()});
            return nullptr;
        }
    }
    
    consume(TokenType::SEMICOLON, "Expected ';' after variable declaration");
    
    auto decl = std::make_unique<VarDeclStmt>(type, name, std::move(initializer));
    if (is_const) decl->is_const = true;
    if (is_auto_modifier || type->base == BaseType::AUTO) decl->is_auto = true;

    // If this was a shorthand declaration (colon-default) and the type is AUTO, attempt type inference
    if (decl->type->base == BaseType::AUTO && decl->initializer) {
        // Simple inference rules: number -> int64/dec64, string -> u8[], true/false -> bool
        if (auto* num = dynamic_cast<NumberExpr*>(decl->initializer.get())) {
            if (num->is_float) decl->type = std::make_shared<Type>(BaseType::DEC64);
            else decl->type = std::make_shared<Type>(BaseType::INT64);
        } else if (dynamic_cast<StringExpr*>(decl->initializer.get())) {
            auto t = std::make_shared<Type>(BaseType::U8);
            t->element_type = std::make_shared<Type>(BaseType::U8);
            decl->type = std::make_shared<Type>(BaseType::ARRAY, t->element_type);
        } else if (dynamic_cast<IdentifierExpr*>(decl->initializer.get())) {
            // Leave as AUTO for now; codegen will resolve by symbol lookup
        }
    }
    return decl;
}

std::unique_ptr<StmtNode> Parser::for_statement() {
    // for (init; condition; increment) body
    consume(TokenType::LEFT_PAREN, "Expected '(' after 'for'");

    std::unique_ptr<StmtNode> init_stmt;
    if (!check(TokenType::SEMICOLON)) {
        // Decide if this is a variable declaration
        if (check(TokenType::CONST) || check(TokenType::AUTO) ||
            check(TokenType::INT8) || check(TokenType::INT16) || check(TokenType::INT32) || check(TokenType::INT64) || check(TokenType::INT128) ||
            check(TokenType::DEC32) || check(TokenType::DEC64) || check(TokenType::DEC128) || check(TokenType::U8) || check(TokenType::BOOL) || check(TokenType::NULL_TYPE) ||
            (check(TokenType::IDENTIFIER) && current + 1 < tokens.size() && tokens[current + 1].type == TokenType::COLON)) {
            init_stmt = var_declaration();
        } else {
            init_stmt = assignment_or_expression();
        }
    } else {
        // consume the ';' if no init
        consume(TokenType::SEMICOLON, "Expected ';' after for init");
    }

    std::unique_ptr<ExprNode> cond_expr;
    if (!check(TokenType::SEMICOLON)) {
        cond_expr = expression();
    } else {
        // default true
        cond_expr = std::make_unique<NumberExpr>(1);
    }
    consume(TokenType::SEMICOLON, "Expected ';' after for condition");

    std::unique_ptr<StmtNode> incr_stmt;
    if (!check(TokenType::RIGHT_PAREN)) {
        // Parse potential assignment or simple expression for increment
        auto potential = expression();
        if (match(TokenType::EQUAL)) {
            auto rhs = expression();
            incr_stmt = std::make_unique<AssignStmt>(std::move(potential), std::move(rhs));
        } else {
            incr_stmt = std::make_unique<ExprStmt>(std::move(potential));
        }
    }
    consume(TokenType::RIGHT_PAREN, "Expected ')' after for clauses");

    // Body
    auto body_stmt = statement();

    // Normalize body into a statement vector
    std::vector<std::unique_ptr<StmtNode>> stmts;
    if (auto* block = dynamic_cast<BlockStmt*>(body_stmt.get())) {
        stmts = std::move(block->statements);
    } else {
        stmts.push_back(std::move(body_stmt));
    }

    if (incr_stmt) {
        stmts.push_back(std::move(incr_stmt));
    }

    // Create while loop from condition and stmts
    auto while_stmt = std::make_unique<WhileStmt>(std::move(cond_expr), std::move(stmts));

    // If there was an init statement, return a block with init followed by while
    if (init_stmt) {
        std::vector<std::unique_ptr<StmtNode>> block_stmts;
        block_stmts.push_back(std::move(init_stmt));
        block_stmts.push_back(std::move(while_stmt));
        return std::make_unique<BlockStmt>(std::move(block_stmts));
    }

    return while_stmt;
}

std::unique_ptr<StmtNode> Parser::assignment_or_expression() {
    auto expr = expression();
    
    if (match(TokenType::EQUAL)) {
        // Simple assignment: x = value
        auto value = expression();
        consume(TokenType::SEMICOLON, "Expected ';'");
        return std::make_unique<AssignStmt>(std::move(expr), std::move(value));
    }
    else if (check(TokenType::PLUS_EQUAL) || check(TokenType::MINUS_EQUAL) ||
             check(TokenType::STAR_EQUAL) || check(TokenType::SLASH_EQUAL) ||
             check(TokenType::MODULO_EQUAL)) {
        // Compound assignment: convert to binary operation
        // x += y becomes x = x + y
        TokenType op_token = peek().type;
        current++;  // consume the compound operator
        
        auto value = expression();
        
        // Convert compound operator to binary operator
        TokenType binary_op;
        if (op_token == TokenType::PLUS_EQUAL) binary_op = TokenType::PLUS;
        else if (op_token == TokenType::MINUS_EQUAL) binary_op = TokenType::MINUS;
        else if (op_token == TokenType::STAR_EQUAL) binary_op = TokenType::STAR;
        else if (op_token == TokenType::SLASH_EQUAL) binary_op = TokenType::SLASH;
        else binary_op = TokenType::MODULO;  // MODULO_EQUAL
        
        // Create a clone of expr for the binary operation
        // Since we can't clone AST nodes, we reconstruct them
        std::unique_ptr<ExprNode> binary;
        if (auto* id = dynamic_cast<IdentifierExpr*>(expr.get())) {
            auto left = std::make_unique<IdentifierExpr>(id->name);
            binary = std::make_unique<BinaryExpr>(binary_op, std::move(left), std::move(value));
        } else if (dynamic_cast<IndexExpr*>(expr.get())) {
            // For array indexing, we need to reconstruct carefully
            // For now, just use the value as-is (the original expr can be used)
            throw std::runtime_error("Compound assignment to array elements not yet supported");
        } else {
            throw std::runtime_error("Compound assignment only works with simple variables");
        }
        
        consume(TokenType::SEMICOLON, "Expected ';'");
        return std::make_unique<AssignStmt>(std::move(expr), std::move(binary));
    }
    
    // Just an expression statement - discard result
    consume(TokenType::SEMICOLON, "Expected ';'");
    return std::make_unique<ExprStmt>(std::move(expr));
}

std::unique_ptr<StmtNode> Parser::expression_statement() {
    // Legacy stub (kept for compatibility)
    auto expr = expression();
    consume(TokenType::SEMICOLON, "Expected ';'");
    return std::make_unique<ExprStmt>(std::move(expr));
}

std::unique_ptr<IfStmt> Parser::if_statement() {
    consume(TokenType::LEFT_PAREN, "Expected '(' after 'if'");
    auto condition = expression();
    consume(TokenType::RIGHT_PAREN, "Expected ')'");
    
    std::vector<std::unique_ptr<StmtNode>> then_block;
    if (match(TokenType::LEFT_BRACE)) {
        while (!check(TokenType::RIGHT_BRACE) && !is_at_end()) {
            then_block.push_back(statement());
        }
        consume(TokenType::RIGHT_BRACE, "Expected '}'");
    } else {
        then_block.push_back(statement());
    }
    
    std::vector<std::unique_ptr<StmtNode>> else_block;
    if (match(TokenType::ELSE)) {
        if (match(TokenType::LEFT_BRACE)) {
            while (!check(TokenType::RIGHT_BRACE) && !is_at_end()) {
                else_block.push_back(statement());
            }
            consume(TokenType::RIGHT_BRACE, "Expected '}'");
        } else {
            else_block.push_back(statement());
        }
    }
    
    return std::make_unique<IfStmt>(std::move(condition), std::move(then_block), std::move(else_block));
}

std::unique_ptr<WhileStmt> Parser::while_statement() {
    consume(TokenType::LEFT_PAREN, "Expected '(' after 'while'");
    auto condition = expression();
    consume(TokenType::RIGHT_PAREN, "Expected ')'");
    
    std::vector<std::unique_ptr<StmtNode>> body;
    if (match(TokenType::LEFT_BRACE)) {
        while (!check(TokenType::RIGHT_BRACE) && !is_at_end()) {
            body.push_back(statement());
        }
        consume(TokenType::RIGHT_BRACE, "Expected '}'");
    } else {
        body.push_back(statement());
    }
    
    return std::make_unique<WhileStmt>(std::move(condition), std::move(body));
}

std::unique_ptr<MatchStmt> Parser::match_statement() {
    consume(TokenType::LEFT_PAREN, "Expected '(' after 'match'");
    auto value = expression();
    consume(TokenType::RIGHT_PAREN, "Expected ')'");
    consume(TokenType::LEFT_BRACE, "Expected '{'");
    
    std::vector<MatchCase> cases;
    std::vector<std::unique_ptr<StmtNode>> default_case;
    
    while (!check(TokenType::RIGHT_BRACE) && !is_at_end()) {
        if (match(TokenType::DEFAULT)) {
            consume(TokenType::ARROW, "Expected '=>' after 'default'");
            default_case.push_back(statement());
            match(TokenType::COMMA);
            continue;
        }
        
        auto pattern = expression();
        consume(TokenType::ARROW, "Expected '=>' after pattern");
        
        std::vector<std::unique_ptr<StmtNode>> case_body;
        case_body.push_back(statement());
        
        cases.push_back(MatchCase(std::move(pattern), std::move(case_body)));
        match(TokenType::COMMA);
    }
    
    consume(TokenType::RIGHT_BRACE, "Expected '}'");
    return std::make_unique<MatchStmt>(std::move(value), std::move(cases), std::move(default_case));
}

std::unique_ptr<DeferStmt> Parser::defer_statement() {
    auto stmt = statement();
    return std::make_unique<DeferStmt>(std::move(stmt));
}

std::unique_ptr<ReturnStmt> Parser::return_statement() {
    std::unique_ptr<ExprNode> value;
    if (!check(TokenType::SEMICOLON)) {
        value = expression();
    }
    consume(TokenType::SEMICOLON, "Expected ';'");
    return std::make_unique<ReturnStmt>(std::move(value));
}

std::unique_ptr<BlockStmt> Parser::block_statement() {
    std::vector<std::unique_ptr<StmtNode>> statements;
    while (!check(TokenType::RIGHT_BRACE) && !is_at_end()) {
        statements.push_back(statement());
    }
    consume(TokenType::RIGHT_BRACE, "Expected '}'");
    return std::make_unique<BlockStmt>(std::move(statements));
}

std::shared_ptr<Type> Parser::parse_type() {
    if (match(TokenType::BANG)) {
        auto wrapped = parse_type();
        return std::make_shared<Type>(BaseType::ERROR_UNION, wrapped);
    }
    
    if (match(TokenType::INT32)) {
        if (match(TokenType::LEFT_BRACKET)) {
            consume(TokenType::RIGHT_BRACKET, "Expected ']'");
            return std::make_shared<Type>(BaseType::ARRAY, std::make_shared<Type>(BaseType::INT32));
        }
        return std::make_shared<Type>(BaseType::INT32);
    }
    if (match(TokenType::INT64)) {
        if (match(TokenType::LEFT_BRACKET)) {
            consume(TokenType::RIGHT_BRACKET, "Expected ']'");
            return std::make_shared<Type>(BaseType::ARRAY, std::make_shared<Type>(BaseType::INT64));
        }
        return std::make_shared<Type>(BaseType::INT64);
    }
    if (match(TokenType::DEC32)) {
        if (match(TokenType::LEFT_BRACKET)) {
            consume(TokenType::RIGHT_BRACKET, "Expected ']'");
            return std::make_shared<Type>(BaseType::ARRAY, std::make_shared<Type>(BaseType::DEC32));
        }
        return std::make_shared<Type>(BaseType::DEC32);
    }
    if (match(TokenType::DEC64)) {
        if (match(TokenType::LEFT_BRACKET)) {
            consume(TokenType::RIGHT_BRACKET, "Expected ']'");
            return std::make_shared<Type>(BaseType::ARRAY, std::make_shared<Type>(BaseType::DEC64));
        }
        return std::make_shared<Type>(BaseType::DEC64);
    }
    if (match(TokenType::BOOL)) {
        if (match(TokenType::LEFT_BRACKET)) {
            consume(TokenType::RIGHT_BRACKET, "Expected ']'");
            return std::make_shared<Type>(BaseType::ARRAY, std::make_shared<Type>(BaseType::BOOL));
        }
        return std::make_shared<Type>(BaseType::BOOL);
    }
    if (match(TokenType::NULL_TYPE)) return std::make_shared<Type>(BaseType::NULL_TYPE);
    if (match(TokenType::VAR)) return std::make_shared<Type>(BaseType::AUTO);
    
    if (match(TokenType::U8)) {
        if (match(TokenType::LEFT_BRACKET)) {
            consume(TokenType::RIGHT_BRACKET, "Expected ']'");
            return std::make_shared<Type>(BaseType::ARRAY, std::make_shared<Type>(BaseType::U8));
        }
        return std::make_shared<Type>(BaseType::U8);
    }
    
    if (match(TokenType::STRUCT)) {
        std::string name = consume(TokenType::IDENTIFIER, "Expected struct name").lexeme;
        auto type = std::make_shared<Type>(BaseType::STRUCT);
        type->struct_name = name;
        if (match(TokenType::LEFT_BRACKET)) {
            consume(TokenType::RIGHT_BRACKET, "Expected ']'");
            return std::make_shared<Type>(BaseType::ARRAY, type);
        }
        return type;
    }

    // User-defined types: `Name` (treated as a struct type), optionally `Name[]`.
    if (match(TokenType::IDENTIFIER)) {
        std::string name = previous().lexeme;
        auto base = std::make_shared<Type>(BaseType::STRUCT);
        base->struct_name = name;
        if (match(TokenType::LEFT_BRACKET)) {
            consume(TokenType::RIGHT_BRACKET, "Expected ']'");
            return std::make_shared<Type>(BaseType::ARRAY, base);
        }
        return base;
    }
    
    errors.push_back({"Expected type", peek()});
    return nullptr;
}

std::shared_ptr<Type> Parser::parse_error_type() {
    return parse_type();
}

std::unique_ptr<StructDecl> Parser::struct_declaration() {
    // Struct declarations use the documented syntax: struct: Name { ... }
    // (Allowing the colon keeps it consistent with other type-name forms.)
    match(TokenType::COLON);
    std::string name = consume(TokenType::IDENTIFIER, "Expected struct name").lexeme;
    consume(TokenType::LEFT_BRACE, "Expected '{'");
    
    std::vector<std::unique_ptr<VarDeclStmt>> fields;
    while (!check(TokenType::RIGHT_BRACE) && !is_at_end()) {
        fields.push_back(var_declaration());
    }
    consume(TokenType::RIGHT_BRACE, "Expected '}'");
    
    auto struct_type = std::make_shared<Type>(BaseType::STRUCT);
    struct_type->struct_name = name;
    
    return std::make_unique<StructDecl>(name, struct_type, std::move(fields));
}

std::unique_ptr<FunctionDecl> Parser::function_declaration() {
    bool is_method = false;
    std::string struct_name;
    
    if (check(TokenType::STRUCT)) {
        size_t save = current;
        match(TokenType::STRUCT);
        if (match(TokenType::COLON)) {
            struct_name = consume(TokenType::IDENTIFIER, "Expected struct name").lexeme;
            is_method = true;
        } else {
            current = save;
        }
    }
    
    std::shared_ptr<Type> return_type = parse_type();
    consume(TokenType::COLON, "Expected ':' before function name");
    std::string name = consume(TokenType::IDENTIFIER, "Expected function name").lexeme;
    
    if (name == "start") {
        start_found = true;
    }
    
    // Function declarations MUST have '(' after the name
    // If we see '=' or ';' instead, this was actually a variable declaration
    // This should never happen at top level, but check anyway
    if (!check(TokenType::LEFT_PAREN)) {
        // This is actually a variable declaration, not a function
        // This shouldn't happen at top level - variable declarations should be inside functions
        errors.push_back({"Top-level variable declaration not allowed", peek()});
        return nullptr;
    }
    
    consume(TokenType::LEFT_PAREN, "Expected '(' after function name");
    
    std::vector<std::pair<std::shared_ptr<Type>, std::string>> params;
    if (!check(TokenType::RIGHT_PAREN)) {
        do {
            auto param_type = parse_type();
            consume(TokenType::COLON, "Expected ':' before parameter name");
            std::string param_name = consume(TokenType::IDENTIFIER, "Expected parameter name").lexeme;
            params.push_back({param_type, param_name});
        } while (match(TokenType::COMMA));
    }
    consume(TokenType::RIGHT_PAREN, "Expected ')'");
    
    consume(TokenType::LEFT_BRACE, "Expected '{' before function body");
    std::vector<std::unique_ptr<StmtNode>> body;
    while (!check(TokenType::RIGHT_BRACE) && !is_at_end()) {
        body.push_back(statement());
    }
    consume(TokenType::RIGHT_BRACE, "Expected '}'");
    
    return std::make_unique<FunctionDecl>(false, is_method, struct_name, return_type, name, std::move(params), std::move(body));
}

std::vector<std::unique_ptr<FunctionDecl>> Parser::parse() {
    std::vector<std::unique_ptr<FunctionDecl>> functions;
    
    while (!is_at_end()) {
        if (match(TokenType::MODULE)) {
            // module Name;
            module_name = consume(TokenType::IDENTIFIER, "Expected module name").lexeme;
            if (match(TokenType::SEMICOLON)) {
                continue;
            }
        }

        if (match(TokenType::DERIVE)) {
            parse_derive();
            continue;
        }

        if (match(TokenType::IMPORT)) {
            parse_import();
            continue;
        }

        if (match(TokenType::NAMESPACE)) {
            parse_namespace();
            continue;
        }

        if (match(TokenType::TEST)) {
            functions.push_back(test_declaration());
            continue;
        }

        // Handle directives like #say_ass_nasm, #say_ld_gcc, #say_dbg
        if (match(TokenType::SAY_ASS_NASM)) {
            // Set assembler to nasm
            toolchain_config.use_nasm = true;
            continue;
        }
        if (match(TokenType::SAY_LD_GCC)) {
            // Set linker to gcc
            toolchain_config.use_gcc_linker = true;
            continue;
        }
        if (match(TokenType::SAY_DBG)) {
            // Enable debugging
            toolchain_config.debug_enabled = true;
            continue;
        }

        if (match(TokenType::EXTERN)) {
            functions.push_back(extern_declaration());
            continue;
        }
        
        // Top-level struct declarations: struct: Name { ... }
        // (Also note: `struct: Name` may prefix a method declaration, so we only
        // treat it as a struct declaration when the next token is a '{'.)
        if (check(TokenType::STRUCT)) {
            size_t save = current;
            match(TokenType::STRUCT);
            if (match(TokenType::COLON) && check(TokenType::IDENTIFIER)) {
                current++; // consume identifier for lookahead
                bool is_struct_decl = check(TokenType::LEFT_BRACE);
                current = save;
                if (is_struct_decl) {
                    match(TokenType::STRUCT);
                    structs.push_back(struct_declaration());
                    continue;
                }
            } else {
                current = save;
            }
            current = save;
        }
        
        if (check(TokenType::CONST)) {
            // Top-level const declaration
            auto cdecl = var_declaration();
            constants.push_back(std::move(cdecl));
            continue;
        }
        
        functions.push_back(function_declaration());
    }

    return functions;
}

std::unique_ptr<FunctionDecl> Parser::extern_declaration() {
    auto return_type = parse_type();
    consume(TokenType::COLON, "Expected ':' before extern function name");
    std::string name = consume(TokenType::IDENTIFIER, "Expected extern function name").lexeme;

    consume(TokenType::LEFT_PAREN, "Expected '(' after extern function name");
    std::vector<std::pair<std::shared_ptr<Type>, std::string>> params;
    if (!check(TokenType::RIGHT_PAREN)) {
        do {
            auto param_type = parse_type();
            consume(TokenType::COLON, "Expected ':' before parameter name");
            std::string param_name = consume(TokenType::IDENTIFIER, "Expected parameter name").lexeme;
            params.push_back({param_type, param_name});
        } while (match(TokenType::COMMA));
    }
    consume(TokenType::RIGHT_PAREN, "Expected ')'");

    // Extern declarations end with ';'
    consume(TokenType::SEMICOLON, "Expected ';' after extern declaration");
    std::vector<std::unique_ptr<StmtNode>> empty_body;
    return std::make_unique<FunctionDecl>(true, false, "", return_type, name, std::move(params), std::move(empty_body));
}

void Parser::parse_derive() {
    // Accept syntaxes: derive <name>  OR derive name
    if (match(TokenType::LESS)) {
        if (check(TokenType::IDENTIFIER) || check(TokenType::STRING)) {
            derive_libs.push_back(consume(peek().type, "Expected library name").lexeme);
        }
        // Consume optional closing '>'
        if (check(TokenType::GREATER)) consume(TokenType::GREATER, "Expected '>' after derive target");
    } else if (check(TokenType::IDENTIFIER)) {
        derive_libs.push_back(consume(TokenType::IDENTIFIER, "Expected library name").lexeme);
    }
}

void Parser::parse_import() {
    // Syntax: import "file.cup";  OR import module_name;
    if (check(TokenType::STRING)) {
        std::string file = consume(TokenType::STRING, "Expected import path").lexeme;
        imports.push_back(file);
    } else if (check(TokenType::IDENTIFIER)) {
        std::string name = consume(TokenType::IDENTIFIER, "Expected module name").lexeme;
        imports.push_back(name + ".cup");
    } else {
        errors.push_back({"Expected string or identifier after 'import'", peek()});
        return;
    }
    // Optional trailing semicolon
    match(TokenType::SEMICOLON);
}

void Parser::parse_namespace() {
    // Syntax: namespace Name { ... }  OR  namespace Name;
    std::string name = consume(TokenType::IDENTIFIER, "Expected namespace name").lexeme;

    if (match(TokenType::LEFT_BRACE)) {
        // Namespace block - process contents within the namespace scope
        // For now, we'll just parse the contents but not implement full scoping
        // In a full implementation, we would create a NamespaceDecl and handle scoping properly
        while (!check(TokenType::RIGHT_BRACE) && !is_at_end()) {
            // Parse statements/functions within namespace
            // This is a simplified implementation - in a full implementation
            // we would track the current namespace context
            if (check(TokenType::STRUCT)) {
                size_t save = current;
                match(TokenType::STRUCT);
                if (match(TokenType::COLON) && check(TokenType::IDENTIFIER)) {
                    current++; // consume identifier for lookahead
                    bool is_struct_decl = check(TokenType::LEFT_BRACE);
                    current = save;
                    if (is_struct_decl) {
                        match(TokenType::STRUCT);
                        // For now, just parse and skip - don't add to main lists
                        struct_declaration();
                        continue;
                    }
                } else {
                    current = save;
                }
                current = save;
            } else if (check(TokenType::CONST)) {
                // Top-level const declaration
                auto cdecl = var_declaration();
                // For now, just parse and skip - don't add to main lists
                (void)cdecl; // Suppress unused warning
            } else {
                // Assume it's a function declaration
                // For now, just parse and skip - don't add to main lists
                function_declaration();
            }
        }
        consume(TokenType::RIGHT_BRACE, "Expected '}' after namespace block");
    } else {
        // Namespace declaration without block - just register the namespace
        consume(TokenType::SEMICOLON, "Expected ';' after namespace declaration");
    }
}

std::unique_ptr<FunctionDecl> Parser::test_declaration() {
    // Test function syntax: test: name() { ... }
    // Test functions return bool (pass/fail) or void
    std::string name = consume(TokenType::IDENTIFIER, "Expected test name").lexeme;

    // Test functions have no parameters for now
    consume(TokenType::LEFT_PAREN, "Expected '(' after test name");
    consume(TokenType::RIGHT_PAREN, "Expected ')'");

    consume(TokenType::LEFT_BRACE, "Expected '{' before test body");
    std::vector<std::unique_ptr<StmtNode>> body;
    while (!check(TokenType::RIGHT_BRACE) && !is_at_end()) {
        body.push_back(statement());
    }
    consume(TokenType::RIGHT_BRACE, "Expected '}'");

    // Create a function declaration for the test
    // Test functions return bool (true=pass, false=fail)
    auto bool_type = std::make_shared<Type>(BaseType::BOOL);
    std::vector<std::pair<std::shared_ptr<Type>, std::string>> params;
    return std::make_unique<FunctionDecl>(false, false, "", bool_type, name, std::move(params), std::move(body));
}

void Parser::process_statement_for_asm(const StmtNode* stmt) {
    if (!stmt) return;

    if (const auto* asm_stmt = dynamic_cast<const AsmStmt*>(stmt)) {
        // This AsmStmt was likely created in a different context, so add it to our collection
        assembly_sections.push_back(asm_stmt->code);
    }
    else if (const auto* block_stmt = dynamic_cast<const BlockStmt*>(stmt)) {
        // Recursively process statements in the block
        for (const auto& inner_stmt : block_stmt->statements) {
            process_statement_for_asm(inner_stmt.get());
        }
    }
    else if (const auto* if_stmt = dynamic_cast<const IfStmt*>(stmt)) {
        // Process statements in if/then/else branches
        for (const auto& then_stmt : if_stmt->then_block) {
            process_statement_for_asm(then_stmt.get());
        }
        for (const auto& else_stmt : if_stmt->else_block) {
            process_statement_for_asm(else_stmt.get());
        }
    }
    else if (const auto* while_stmt = dynamic_cast<const WhileStmt*>(stmt)) {
        // Process statements in while loop body
        for (const auto& body_stmt : while_stmt->body) {
            process_statement_for_asm(body_stmt.get());
        }
    }
    else if (const auto* match_stmt = dynamic_cast<const MatchStmt*>(stmt)) {
        // Process statements in match cases
        for (const auto& case_stmt : match_stmt->cases) {
            for (const auto& stmt_in_case : case_stmt.body) {
                process_statement_for_asm(stmt_in_case.get());
            }
        }
        for (const auto& default_stmt : match_stmt->default_case) {
            process_statement_for_asm(default_stmt.get());
        }
    }
    // Other statement types don't contain assembly, so no need to handle them
}

// Recursively collect all inline assembly from the AST after parsing
void Parser::collect_assembly_sections_from_ast() {
    // Process all top-level constants (in case they contain asm in initializers)
    for (const auto& c : constants) {
        if (c) process_statement_for_asm(c.get());
    }

    // Process all functions
    for (const auto& f : functions) {
        if (!f) continue;
        // Process the body of the function
        for (const auto& stmt : f->body) {
            process_statement_for_asm(stmt.get());
        }
    }

    // Process all structs (in case they have methods with asm)
    for (const auto& s : structs) {
        if (!s) continue;
        for (const auto& field : s->fields) {
            if (field) process_statement_for_asm(field.get());
        }
    }
}