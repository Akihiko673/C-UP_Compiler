#include "codegen.h"
#include <stdexcept>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <sstream>

// Fix for floating-point printf arguments - ensure xmm0 is used for first float arg

#ifdef _WIN32
#include <windows.h>
#endif

std::string CodeGenerator::generate_label(const std::string& prefix) {
    return prefix + "_" + std::to_string(label_counter++);
}

bool CodeGenerator::is_auto_alloc_call(const ExprNode* expr) {
    if (!expr) return false;
    const auto* call = dynamic_cast<const CallExpr*>(expr);
    if (!call) return false;
    // Auto-defer only for module-free alloc() calls
    return call->module.empty() && call->function == "alloc";
}

bool CodeGenerator::is_decimal_expression(const ExprNode* expr) {
    if (!expr) return false;
    
    // Number literals
    if (const auto* num = dynamic_cast<const NumberExpr*>(expr)) {
        return num->is_float;
    }
    
    // Identifiers (variables)
    if (const auto* id = dynamic_cast<const IdentifierExpr*>(expr)) {
        auto* sym = symbol_table.resolve(id->name);
        if (sym && sym->type) {
            return sym->type->base == BaseType::DEC64 || sym->type->base == BaseType::DEC32;
        }
    }
    
    // Binary operations: if either operand is decimal, result is decimal
    if (const auto* binary = dynamic_cast<const BinaryExpr*>(expr)) {
        return is_decimal_expression(binary->left.get()) || is_decimal_expression(binary->right.get());
    }
    
    // Unary operations: preserve decimal type
    if (const auto* unary = dynamic_cast<const UnaryExpr*>(expr)) {
        return is_decimal_expression(unary->operand.get());
    }
    
    // Field access: check field type
    if (const auto* field = dynamic_cast<const FieldAccessExpr*>(expr)) {
        if (const auto* obj = dynamic_cast<const IdentifierExpr*>(field->object.get())) {
            auto* sym = symbol_table.resolve(obj->name);
            if (sym && sym->type) {
                // Find the field type
                for (const auto& f : sym->type->fields) {
                    if (f.name == field->field_name) {
                        return f.type->base == BaseType::DEC64 || f.type->base == BaseType::DEC32;
                    }
                }
            }
        }
    }
    
    return false;
}

void CodeGenerator::add_assembly_section(const std::string& section) {
    // Add the assembly section to our collection
    // Only add if it's not already present to avoid duplicates
    if (assembly_sections.tellp() == 0) {
        assembly_sections << "\n; Runtime assembly sections\n";
    }
    assembly_sections << section << "\n";
}

void CodeGenerator::add_symbol_definition(const std::string& symbol) {
    collected_symbols.insert(symbol);
}

bool CodeGenerator::is_symbol_defined(const std::string& symbol) const {
    return collected_symbols.count(symbol) > 0;
}

void CodeGenerator::emit(const std::string& instruction) {
    output << "    " << instruction << "\n";
}

void CodeGenerator::emit_comment(const std::string& comment) {
    output << ";; " << comment << "\n";
}

void CodeGenerator::emit_syscall(int number) {
    // Linux syscall instruction
    emit("mov rax, " + std::to_string(number));
    emit("syscall");
}

void CodeGenerator::emit_win32_call(const std::string& function) {
    // Windows uses Microsoft x64 calling convention
    // RCX, RDX, R8, R9 for first 4 args, then stack
    // Caller must reserve shadow space (32 bytes)
    emit("sub rsp, 32");  // Shadow space
    emit("call " + function);
    emit("add rsp, 32");  // Restore stack
}

bool CodeGenerator::has_derive(const std::string& lib) const {
    if (!derives) return false;
    return std::find(derives->begin(), derives->end(), lib) != derives->end();
}

void CodeGenerator::require_derive(const std::string& lib, const std::string& func) const {
    if (!has_derive(lib)) {
        throw std::runtime_error("Function '" + func + "' requires derive <" + lib + ">");
    }
}

size_t CodeGenerator::calculate_stack_size(const FunctionDecl* func) {
    size_t current_size = 0;
    for (const auto& stmt : func->body) {
        traverse_statement(stmt.get(), current_size);
    }
    return current_size;
}

void CodeGenerator::traverse_statement(const StmtNode* stmt, size_t& current_size) {
    if (!stmt) return;

    if (auto var_decl = dynamic_cast<const VarDeclStmt*>(stmt)) {
        current_size += var_decl->type->size();
    } else if (auto if_stmt = dynamic_cast<const IfStmt*>(stmt)) {
        for (const auto& s : if_stmt->then_block) {
            traverse_statement(s.get(), current_size);
        }
        for (const auto& s : if_stmt->else_block) {
            traverse_statement(s.get(), current_size);
        }
    } else if (auto while_stmt = dynamic_cast<const WhileStmt*>(stmt)) {
        for (const auto& s : while_stmt->body) {
            traverse_statement(s.get(), current_size);
        }
    } else if (auto block_stmt = dynamic_cast<const BlockStmt*>(stmt)) {
        for (const auto& s : block_stmt->statements) {
            traverse_statement(s.get(), current_size);
        }
    } else if (auto match_stmt = dynamic_cast<const MatchStmt*>(stmt)) {
        for (const auto& c : match_stmt->cases) {
            for (const auto& s : c.body) {
                traverse_statement(s.get(), current_size);
            }
        }
        for (const auto& s : match_stmt->default_case) {
            traverse_statement(s.get(), current_size);
        }
    } else if (auto defer_stmt = dynamic_cast<const DeferStmt*>(stmt)) {
        traverse_statement(defer_stmt->statement.get(), current_size);
    }
    // Other statements don't declare variables that take up stack space in the same way.
}

void CodeGenerator::define_local_variables(const StmtNode* stmt) {
    if (!stmt) return;

    if (auto var_decl = dynamic_cast<const VarDeclStmt*>(stmt)) {
        symbol_table.define(var_decl->name, var_decl->type, var_decl->needs_cleanup);
    } else if (auto if_stmt = dynamic_cast<const IfStmt*>(stmt)) {
        for (const auto& s : if_stmt->then_block) {
            define_local_variables(s.get());
        }
        for (const auto& s : if_stmt->else_block) {
            define_local_variables(s.get());
        }
    } else if (auto while_stmt = dynamic_cast<const WhileStmt*>(stmt)) {
        for (const auto& s : while_stmt->body) {
            define_local_variables(s.get());
        }
    } else if (auto block_stmt = dynamic_cast<const BlockStmt*>(stmt)) {
        for (const auto& s : block_stmt->statements) {
            define_local_variables(s.get());
        }
    } else if (auto match_stmt = dynamic_cast<const MatchStmt*>(stmt)) {
        for (const auto& c : match_stmt->cases) {
            for (const auto& s : c.body) {
                define_local_variables(s.get());
            }
        }
        for (const auto& s : match_stmt->default_case) {
            define_local_variables(s.get());
        }
    } else if (auto defer_stmt = dynamic_cast<const DeferStmt*>(stmt)) {
        define_local_variables(defer_stmt->statement.get());
    }
}




void CodeGenerator::generate_expression(const ExprNode* expr) {
    if (const auto* num = dynamic_cast<const NumberExpr*>(expr)) {
        if (num->is_float) {
            // For floating point literals, emit into data section and load with movsd
            std::string label = generate_label("dbl");
            union { double d; uint64_t u; } bits;
            bits.d = num->fvalue;
            char hex_buffer[32];
            snprintf(hex_buffer, sizeof(hex_buffer), "0x%016llx", (unsigned long long)bits.u);
            data_section << label << ": dq " << hex_buffer << "\n";
            emit("movsd xmm0, [rel " + label + "]");
        } else {
            // integer literal: support extended widths
            if (num->value == 0) {
                emit("xor rax, rax");
            } else if (num->value >= INT32_MIN && num->value <= INT32_MAX) {
                emit("mov eax, " + std::to_string(static_cast<int32_t>(num->value)));
            } else {
                emit("mov rax, " + std::to_string(num->value));
            }
        }
    }
    else if (const auto* str = dynamic_cast<const StringExpr*>(expr)) {
        std::string label = generate_label("str");
        data_section << label << ": db ";
        
        // Properly escape string for NASM assembly
        // Build escaped string representation
        std::string escaped;
        size_t i = 0;
        while (i < str->value.length()) {
            unsigned char c = static_cast<unsigned char>(str->value[i]);
            
            if (c < 128) {
                // Single-byte ASCII
                switch (c) {
                    case '\n': escaped += "10, "; break;
                    case '\t': escaped += "9, "; break;
                    case '\r': escaped += "13, "; break;
                    case '\0': escaped += "0, "; break;
                    case '\f': escaped += "12, "; break;
                    case '\b': escaped += "8, "; break;
                    case '\v': escaped += "11, "; break;
                    case '"':  escaped += "34, "; break;
                    case '\\': escaped += "92, "; break;
                    default:
                        if (c >= 32 && c < 127 && c != '\'') {
                            escaped += "'";
                            escaped += static_cast<char>(c);
                            escaped += "', ";
                        } else {
                            escaped += std::to_string(c);
                            escaped += ", ";
                        }
                        break;
                }
                i++;
            } else if ((c & 0xE0) == 0xC0 && i + 1 < str->value.length()) {
                // 2-byte UTF-8 sequence
                escaped += std::to_string(c);
                escaped += ", ";
                i++;
                escaped += std::to_string(static_cast<unsigned char>(str->value[i]));
                escaped += ", ";
                i++;
            } else if ((c & 0xF0) == 0xE0 && i + 2 < str->value.length()) {
                // 3-byte UTF-8 sequence
                escaped += std::to_string(c);
                escaped += ", ";
                i++;
                escaped += std::to_string(static_cast<unsigned char>(str->value[i]));
                escaped += ", ";
                i++;
                escaped += std::to_string(static_cast<unsigned char>(str->value[i]));
                escaped += ", ";
                i++;
            } else if ((c & 0xF8) == 0xF0 && i + 3 < str->value.length()) {
                // 4-byte UTF-8 sequence
                escaped += std::to_string(c);
                escaped += ", ";
                i++;
                escaped += std::to_string(static_cast<unsigned char>(str->value[i]));
                escaped += ", ";
                i++;
                escaped += std::to_string(static_cast<unsigned char>(str->value[i]));
                escaped += ", ";
                i++;
                escaped += std::to_string(static_cast<unsigned char>(str->value[i]));
                escaped += ", ";
                i++;
            } else {
                // Invalid UTF-8, skip byte
                escaped += std::to_string(c);
                escaped += ", ";
                i++;
            }
        }
        // Remove trailing ", " and add null terminator
        if (!escaped.empty()) {
            escaped = escaped.substr(0, escaped.length() - 2);
            data_section << escaped << ", 0\n";  // Null terminator
        } else {
            data_section << "0\n";  // Just null terminator for empty string
        }

        // Represent string literals as (ptr,len) in (rax,rdx) for consistency with fat pointers.
        // For C interop (e.g. printf), the pointer in rax is what matters; the data is null-terminated.
        emit("lea rax, [rel " + label + "]");
        emit("mov rdx, " + std::to_string(str->value.length()));
    }
    else if (const auto* id = dynamic_cast<const IdentifierExpr*>(expr)) {
        auto* symbol = symbol_table.resolve(id->name);
        if (!symbol) throw std::runtime_error("Undefined variable: " + id->name);
        
        // Constant substitution: if this is a top-level constant, inline its initializer
        ExprNode* const_init = symbol_table.get_constant_init(id->name);
        if (const_init) {
            generate_expression(const_init);
            return;
        }

        // For error union types, load value and error flag
        if (symbol->type && symbol->type->is_error_union()) {
            emit("mov rax, [rbp - " + std::to_string(symbol->stack_offset) + "]");     // value
            emit("mov rdx, [rbp - " + std::to_string(symbol->stack_offset + 8) + "]");  // error flag
        }
        // For struct types (fat pointers), load pointer and size
        else if (symbol->type && symbol->type->is_struct()) {
            // rax = pointer to struct data (address on stack)
            emit("mov rax, rbp");
            emit("sub rax, " + std::to_string(symbol->stack_offset));
            // rdx = size of struct data
            emit("mov rdx, " + std::to_string(symbol->type->actual_struct_size()));
        }
        // For dec64 types, load into xmm0
        else if (symbol->type && symbol->type->base == BaseType::DEC64) {
            emit("movsd xmm0, [rbp - " + std::to_string(symbol->stack_offset) + "]");
        }
        else {
            emit("mov rax, [rbp - " + std::to_string(symbol->stack_offset) + "]");
        }
    }
    else if (dynamic_cast<const TickExpr*>(expr)) {
        emit("rdtsc");
        emit("shl rdx, 32");
        emit("or rax, rdx");
    }
    else if (const auto* len = dynamic_cast<const LengthExpr*>(expr)) {
        if (const auto* arr_id = dynamic_cast<const IdentifierExpr*>(len->array.get())) {
            auto* sym = symbol_table.resolve(arr_id->name);
            if (!sym) throw std::runtime_error("Undefined array: " + arr_id->name);
            emit("mov rax, [rbp - " + std::to_string(sym->stack_offset + 8) + "]");
        }
    }
    else if (const auto* idx = dynamic_cast<const IndexExpr*>(expr)) {
        generate_expression(idx->index.get());
        emit("push rax");
        
        if (const auto* arr = dynamic_cast<const IdentifierExpr*>(idx->array.get())) {
            auto* sym = symbol_table.resolve(arr->name);
            emit("pop rbx");
            emit("mov rcx, [rbp - " + std::to_string(sym->stack_offset + 8) + "]");
            emit("cmp rbx, rcx");
            emit("jae _panic_bounds_error");
            emit("mov rax, [rbp - " + std::to_string(sym->stack_offset) + "]");
            
            // Calculate element size from array element type
            size_t elem_size = 8; // default
            if (sym->type && sym->type->element_type) {
                elem_size = sym->type->element_type->size();
            }
            
            // Use correct load instruction based on element size
            if (elem_size == 1) {
                emit("movzx rax, byte [rax + rbx]");  // Zero-extend byte to rax
            } else if (elem_size == 4) {
                emit("mov eax, dword [rax + rbx*4]"); // 32-bit (clears upper 32 bits)
            } else {
                emit("mov rax, [rax + rbx*" + std::to_string(elem_size) + "]");
            }
        }
    }
    else if (const auto* field = dynamic_cast<const FieldAccessExpr*>(expr)) {
        if (const auto* obj = dynamic_cast<const IdentifierExpr*>(field->object.get())) {
            // I'll Check if this is namespace access (ns::func) or struct field access (obj.field)
            // Damn, we'll assume if the namespace exists, it's namespace access
            if (symbol_table.namespace_exists(obj->name)) {
                // This is namespace access - typically used for function calls
                // We'll handle this in the call expression, not here
                // For now, just throw an error since standalone namespace access doesn't make sense
                throw std::runtime_error("Standalone namespace access not supported: " + obj->name + "::" + field->field_name);
            } else {
                // This is struct field access
                auto* sym = symbol_table.resolve(obj->name);
                if (!sym) throw std::runtime_error("Undefined variable: " + obj->name);

                size_t field_offset = symbol_table.get_field_offset(sym->type->struct_name, field->field_name);
                emit("lea rax, [rbp - " + std::to_string(sym->stack_offset) + "]");
                emit("mov rax, [rax + " + std::to_string(field_offset) + "]");
            }
        }
    }
    else if (const auto* binary = dynamic_cast<const BinaryExpr*>(expr)) {
        bool left_is_decimal = is_decimal_expression(binary->left.get());
        bool right_is_decimal = is_decimal_expression(binary->right.get());
        bool is_decimal_op = left_is_decimal || right_is_decimal;
        
        if (is_decimal_op) {
            // Decimal operations use xmm registers
            generate_expression(binary->left.get());
            // If left is not decimal, convert from integer to float
            if (!left_is_decimal) {
                emit("cvtsi2sd xmm0, rax");  // Convert integer in rax to double in xmm0
            }
            emit("movsd xmm1, xmm0");  // Save left operand in xmm1
            
            generate_expression(binary->right.get());
            // If right is not decimal, convert from integer to float
            if (!right_is_decimal) {
                emit("cvtsi2sd xmm0, rax");  // Convert integer in rax to double in xmm0
            }
            // Now xmm0 has right operand, xmm1 has left operand
            
            switch (binary->op) {
                case TokenType::PLUS:
                    emit("addsd xmm1, xmm0");  // xmm1 = xmm1 + xmm0
                    emit("movsd xmm0, xmm1");  // Result in xmm0
                    break;
                case TokenType::MINUS:
                    emit("subsd xmm1, xmm0");  // xmm1 = xmm1 - xmm0
                    emit("movsd xmm0, xmm1");  // Result in xmm0
                    break;
                case TokenType::STAR:
                    emit("mulsd xmm1, xmm0");  // xmm1 = xmm1 * xmm0
                    emit("movsd xmm0, xmm1");  // Result in xmm0
                    break;
                case TokenType::SLASH:
                    emit("divsd xmm1, xmm0");  // xmm1 = xmm1 / xmm0
                    emit("movsd xmm0, xmm1");  // Result in xmm0
                    break;
                case TokenType::MODULO: {
                    // Damn, floating point modulo: call fmod(left, right)
                    // We must place left into xmm0 and right into xmm1 according to ABI.
                    // Current state: after generate_expression(left) we moved left into xmm1,
                    // then generated right so xmm0 holds right. We'll reconstruct:
                    // Evaluate left then move to xmm2, evaluate right in xmm0, then move left to xmm0 and right to xmm1.
                    // To simplify, re-evaluate left here by regenerating operands in correct order.
                    // Regenerate left into xmm0
                    generate_expression(binary->left.get());
                    if (!left_is_decimal) emit("cvtsi2sd xmm0, rax");
                    emit("movsd xmm2, xmm0"); // save left
                    // Regenerate right into xmm0
                    generate_expression(binary->right.get());
                    if (!right_is_decimal) emit("cvtsi2sd xmm0, rax");
                    // Arrange args: left -> xmm0, right -> xmm1
                    emit("movsd xmm1, xmm0"); // xmm1 = right
                    emit("movsd xmm0, xmm2"); // xmm0 = left
                    // Call fmod
                    // Ensure stack aligned; caller preserves alignment in prologue
                    if (target_platform == TargetPlatform::WINDOWS) {
                        emit("sub rsp, 32");
                        emit("call fmod");
                        emit("add rsp, 32");
                    } else {
                        emit("call fmod");
                    }
                    // result in xmm0
                    break; }
                case TokenType::EQUAL_EQUAL:
                    emit("ucomisd xmm1, xmm0");  // Compare xmm1 and xmm0
                    emit("sete al");
                    emit("movzx rax, al");
                    break;
                case TokenType::BANG_EQUAL:
                    emit("ucomisd xmm1, xmm0");
                    emit("setne al");
                    emit("movzx rax, al");
                    break;
                case TokenType::LESS:
                    emit("ucomisd xmm0, xmm1");  // Compare xmm0 < xmm1
                    emit("seta al");  // Set if xmm0 > xmm1 (this makes xmm1 < xmm0)
                    emit("movzx rax, al");
                    break;
                case TokenType::GREATER:
                    emit("ucomisd xmm1, xmm0");  // Compare xmm1 > xmm0
                    emit("seta al");  // Set if xmm1 > xmm0 (above)
                    emit("movzx rax, al");
                    break;
                case TokenType::LESS_EQUAL:
                    emit("ucomisd xmm0, xmm1");  // Compare xmm0 <= xmm1
                    emit("setae al");  // Set if xmm0 >= xmm1 (this makes xmm1 <= xmm0)
                    emit("movzx rax, al");
                    break;
                case TokenType::GREATER_EQUAL:
                    emit("ucomisd xmm1, xmm0");  // Compare xmm1 >= xmm0
                    emit("setae al");  // Set if xmm1 >= xmm0 (above or equal)
                    emit("movzx rax, al");
                    break;
                default:
                    throw std::runtime_error("Unsupported binary operator for decimals");
            }
        } else {
            // Integer operations use rax/rbx
            generate_expression(binary->left.get());
            emit("push rax");
            generate_expression(binary->right.get());
            emit("mov rbx, rax");
            emit("pop rax");
            
            switch (binary->op) {
                case TokenType::PLUS:
                    emit("add rax, rbx");
                    break;
                case TokenType::MINUS:
                    emit("sub rax, rbx");
                    break;
                case TokenType::STAR:
                    emit("imul rax, rbx");
                    break;
                case TokenType::SLASH:
                    emit("cqo");
                    emit("idiv rbx");
                    break;
                case TokenType::MODULO:
                    emit("cqo");
                    emit("idiv rbx");
                    emit("mov rax, rdx");  // remainder is in rdx
                    break;
                case TokenType::EQUAL_EQUAL:
                    emit("cmp rax, rbx");
                    emit("sete al");
                    emit("movzx rax, al");
                    break;
                case TokenType::BANG_EQUAL:
                    emit("cmp rax, rbx");
                    emit("setne al");
                    emit("movzx rax, al");
                    break;
                case TokenType::LESS:
                    emit("cmp rax, rbx");
                    emit("setl al");
                    emit("movzx rax, al");
                    break;
                case TokenType::GREATER:
                    emit("cmp rax, rbx");
                    emit("setg al");
                    emit("movzx rax, al");
                    break;
                case TokenType::LESS_EQUAL:
                    emit("cmp rax, rbx");
                    emit("setle al");
                    emit("movzx rax, al");
                    break;
                case TokenType::GREATER_EQUAL:
                    emit("cmp rax, rbx");
                    emit("setge al");
                    emit("movzx rax, al");
                    break;
                case TokenType::AMP:
                    emit("and rax, rbx");
                    break;
                case TokenType::CARET:
                    emit("xor rax, rbx");
                    break;
                case TokenType::PIPE:
                    emit("or rax, rbx");
                    break;
                case TokenType::AMP_AMP: {
                    std::string end_label = generate_label("sc_and_end");
                    emit("test rax, rax");
                    emit("jz " + end_label);
                    emit("mov rax, rbx");
                    emit("test rax, rax");
                    emit(end_label + ":");
                    break;
                }
                case TokenType::PIPE_PIPE: {
                    std::string end_label = generate_label("sc_or_end");
                    emit("test rax, rax");
                    emit("jnz " + end_label);
                    emit("mov rax, rbx");
                    emit(end_label + ":");
                    break;
                }
                default:
                    throw std::runtime_error("Unsupported binary operator");
            }
        }
    }
    else if (const auto* unary = dynamic_cast<const UnaryExpr*>(expr)) {
        bool is_decimal = is_decimal_expression(unary->operand.get());
        generate_expression(unary->operand.get());
        
        if (is_decimal) {
            // Decimal unary operations use xmm0
            switch (unary->op) {
                case TokenType::BANG:
                    // For decimals, !x means x == 0.0
                    emit("xorpd xmm1, xmm1");  // xmm1 = 0.0
                    emit("comisd xmm0, xmm1");  // Compare xmm0 with 0.0
                    emit("sete al");
                    emit("movzx rax, al");
                    break;
                case TokenType::MINUS:
                    emit("xorpd xmm1, xmm1");  // xmm1 = 0.0
                    emit("subsd xmm1, xmm0");  // xmm1 = 0.0 - xmm0
                    emit("movsd xmm0, xmm1");  // Result in xmm0
                    break;
                default:
                    throw std::runtime_error("Unsupported unary operator for decimals");
            }
        } else {
            // Integer unary operations use rax
            switch (unary->op) {
                case TokenType::BANG:
                    emit("test rax, rax");
                    emit("setz al");
                    emit("movzx rax, al");
                    break;
                case TokenType::MINUS:
                    emit("neg rax");
                    break;
                default:
                    throw std::runtime_error("Unsupported unary operator");
            }
        }
    }
    else if (const auto* inc = dynamic_cast<const IncrementExpr*>(expr)) {
        // ++x or --x: load variable, modify, store back, and return new value
        if (const auto* id = dynamic_cast<const IdentifierExpr*>(inc->operand.get())) {
            auto* sym = symbol_table.resolve(id->name);
            if (!sym) throw std::runtime_error("Undefined variable: " + id->name);
            
            // Load current value
            emit("mov rax, [rbp - " + std::to_string(sym->stack_offset) + "]");
            
            // Modify
            if (inc->op == TokenType::INCREMENT) {
                emit("add rax, 1");
            } else {
                emit("sub rax, 1");
            }
            
            // Store back
            emit("mov [rbp - " + std::to_string(sym->stack_offset) + "], rax");
            // Result stays in rax (new value)
        }
        else if (const auto* idx = dynamic_cast<const IndexExpr*>(inc->operand.get())) {
            // ++arr[i] or --arr[i]
            generate_expression(idx->index.get());
            emit("push rax");
            
            if (const auto* arr_id = dynamic_cast<const IdentifierExpr*>(idx->array.get())) {
                auto* sym = symbol_table.resolve(arr_id->name);
                emit("pop rbx");
                emit("mov rcx, [rbp - " + std::to_string(sym->stack_offset + 8) + "]");
                emit("cmp rbx, rcx");
                emit("jae _panic_bounds_error");
                
                emit("mov rax, [rbp - " + std::to_string(sym->stack_offset) + "]");
                
                size_t elem_size = 8;
                if (sym->type && sym->type->element_type) {
                    elem_size = sym->type->element_type->size();
                }
                
                // Load element
                if (elem_size == 1) {
                    emit("movzx rax, byte [rax + rbx]");
                } else if (elem_size == 4) {
                    emit("mov eax, dword [rax + rbx*4]");
                } else {
                    emit("mov rax, [rax + rbx*" + std::to_string(elem_size) + "]");
                }
                
                // Modify and store back
                if (inc->op == TokenType::INCREMENT) {
                    emit("add rax, 1");
                } else {
                    emit("sub rax, 1");
                }
                
                emit("mov rcx, [rbp - " + std::to_string(sym->stack_offset) + "]");
                if (elem_size == 1) {
                    emit("mov byte [rcx + rbx], al");
                } else if (elem_size == 4) {
                    emit("mov dword [rcx + rbx*4], eax");
                } else {
                    emit("mov [rcx + rbx*" + std::to_string(elem_size) + "], rax");
                }
            }
        }
        else {
            throw std::runtime_error("Increment/decrement can only be applied to lvalues (variables or array elements)");
        }
    }
    else if (const auto* error_prop = dynamic_cast<const ErrorPropagationExpr*>(expr)) {
        // Error propagation operator: expr?
        // This unwraps an error union and propagates the error if present
        generate_expression(error_prop->operand.get());

        // For error unions: rax = value, rdx = error flag
        // If error flag (rdx) is non-zero, propagate the error by jumping to error handler
        emit("test rdx, rdx");  // Check error flag
        std::string error_label = generate_label("early_return");
        emit("jnz " + error_label);  // Jump to error handler if error flag is set

        // If no error, return the value (rax) and clear error flag (set rdx to 0)
        emit("xor rdx, rdx");  // Clear error flag
        emit(error_label + ":");
    }
    else if (const auto* call = dynamic_cast<const CallExpr*>(expr)) {
        // Builtins first
        bool is_builtin =
            call->function == "say" || call->function == "alloc" || call->function == "free" ||
            call->function == "copy" || call->function == "open" || call->function == "close" ||
            call->function == "read" || call->function == "write" || call->function == "create" ||
            call->function == "delete" || call->function == "rename" || call->function == "mkdir" ||
            call->function == "rmdir" || call->function == "read_dir" || call->function == "get_size" ||
            call->function == "get_mtime" || call->function == "set_perms" ||
            call->function == "socket" || call->function == "connect" ||
            call->function == "listen" || call->function == "accept" ||
            call->function == "chr" || call->function == "ord" || call->function == "abs" ||
            call->function == "min" || call->function == "max" || call->function == "array_create" ||
            call->function == "array_append" || call->function == "panic" || call->function == "assert" ||
            call->function == "shl" || call->function == "shr" || call->function == "rotl" ||
            call->function == "rotr" || call->function == "float_to_int" || call->function == "int_to_float" ||
            call->function == "error" || call->function == "test_assert" || call->function == "test_eq" ||
            call->function == "test_ne" || call->function == "test_gt" || call->function == "test_lt";

        if (is_builtin) {
            // Gate builtins behind derive declarations
            if (call->function == "alloc" || call->function == "free" || call->function == "copy") {
                require_derive("memory", call->function);
            } else if (call->function == "open" || call->function == "close" || call->function == "read" ||
                       call->function == "write" || call->function == "create" || call->function == "delete" ||
                       call->function == "rename" || call->function == "mkdir" || call->function == "rmdir" ||
                       call->function == "read_dir" || call->function == "get_size" ||
                       call->function == "get_mtime" || call->function == "set_perms") {
                require_derive("file", call->function);
            } else if (call->function == "socket" || call->function == "connect" ||
                       call->function == "listen" || call->function == "accept") {
                require_derive("net", call->function);
            } else if (call->function == "test_assert" || call->function == "test_eq" ||
                       call->function == "test_ne" || call->function == "test_gt" ||
                       call->function == "test_lt") {
                require_derive("testing", call->function);
            }
            generate_builtin_call(call);
            return;
        }

        // General function call (user-defined or extern)
        // Handle namespace-qualified function calls (module.function)
        std::string full_function_name = call->function;
        if (!call->module.empty()) {
            full_function_name = call->module + "_" + call->function;  // Use underscore as namespace separator
        }

        if (target_platform == TargetPlatform::LINUX) {
            // System V ABI: rdi, rsi, rdx, rcx, r8, r9
            static const char* arg_regs[] = {"rdi", "rsi", "rdx", "rcx", "r8", "r9"};

            // Check if this is a user-defined function with known signature
            const FunctionDecl* called_func = nullptr;
            auto it = function_map.find(full_function_name);
            if (it != function_map.end()) {
                called_func = it->second;
            }
            
            // Evaluate args in reverse, push to stack, then pop into registers to preserve order.
            for (int i = static_cast<int>(call->arguments.size()) - 1; i >= 0; --i) {
                // Check parameter type for struct handling
                bool is_struct_param = false;
                size_t struct_size = 0;
                
                if (called_func && i < static_cast<int>(called_func->params.size())) {
                    auto param_type = called_func->params[i].first;
                    if (param_type && param_type->base == BaseType::STRUCT) {
                        is_struct_param = true;
                        // Look up actual struct definition to get correct size
                        auto resolved_struct = symbol_table.resolve_struct(param_type->struct_name);
                        if (resolved_struct) {
                            struct_size = resolved_struct->size();
                        } else {
                            struct_size = param_type->size();
                        }
                    }
                }
                
                // Large structs passed by reference (address only)
                if (is_struct_param && struct_size > 8) {
                    if (const auto* id = dynamic_cast<const IdentifierExpr*>(call->arguments[i].get())) {
                        auto* sym = symbol_table.resolve(id->name);
                        if (sym) {
                            emit("mov rax, rbp");
                            emit("sub rax, " + std::to_string(sym->stack_offset));
                            emit("push rax");
                        } else {
                            throw std::runtime_error("Undefined variable: " + id->name);
                        }
                    } else {
                        throw std::runtime_error("Cannot pass struct expressions as arguments");
                    }
                } else {
                    generate_expression(call->arguments[i].get());
                    emit("push rax");
                }
            }
            size_t arg_count = call->arguments.size();
            size_t reg_count = std::min<size_t>(arg_count, 6);
            for (size_t i = 0; i < reg_count; ++i) {
                emit(std::string("pop ") + arg_regs[i]);
            }
            if (arg_count > 6) {
                // Extra args remain on the stack for now (simple fallback)
            }
            emit("call " + full_function_name);
            // Caller cleans up stack args (System V)
            if (arg_count > 6) {
                size_t stack_args = arg_count - 6;
                emit("add rsp, " + std::to_string(stack_args * 8));
            }
        } else {
            // Microsoft x64 ABI: rcx, rdx, r8, r9, then stack (with shadow space)
            static const char* arg_regs[] = {"rcx", "rdx", "r8", "r9"};
            size_t arg_count = call->arguments.size();

            // Check if this is a user-defined function with known signature
            const FunctionDecl* called_func = nullptr;
            auto it = function_map.find(full_function_name);
            if (it != function_map.end()) {
                called_func = it->second;
            }
            
            // Reserve shadow space first (always 32 bytes)
            emit("sub rsp, 32");
            
            // Evaluate and push all args in reverse order
            for (int i = static_cast<int>(arg_count) - 1; i >= 0; --i) {
                // Check parameter type BEFORE evaluating the expression
                bool is_array_param = false;
                bool is_struct_param = false;
                size_t struct_size = 0;
                
                if (called_func && i < static_cast<int>(called_func->params.size())) {
                    auto param_type = called_func->params[i].first;
                    if (param_type) {
                        if (param_type->base == BaseType::ARRAY) {
                            is_array_param = true;
                        } else if (param_type->base == BaseType::STRUCT) {
                            is_struct_param = true;
                            // CRITICAL: Look up the actual struct definition from symbol table
                            // to ensure we have all fields, not just the type shell
                            auto resolved_struct = symbol_table.resolve_struct(param_type->struct_name);
                            if (resolved_struct) {
                                struct_size = resolved_struct->size();
                            } else {
                                struct_size = param_type->size();
                            }
                        }
                    }
                }
                
                // Special handling for struct arguments > 8 bytes
                // Pass them by reference (pointer) like arrays
                if (is_struct_param && struct_size > 8) {
                    if (const auto* id = dynamic_cast<const IdentifierExpr*>(call->arguments[i].get())) {
                        auto* sym = symbol_table.resolve(id->name);
                        if (sym) {
                            // Pass address of the struct on stack
                            emit("mov rax, rbp");
                            emit("sub rax, " + std::to_string(sym->stack_offset));
                            emit("push rax");  // Address goes to first register
                        } else {
                            throw std::runtime_error("Undefined variable: " + id->name);
                        }
                    } else {
                        // Complex expression - not supported for large structs
                        throw std::runtime_error("Cannot pass struct expressions as arguments");
                    }
                } else {
                    generate_expression(call->arguments[i].get());
                    
                    if (is_array_param) {
                        // Push rdx (array length) first, then rax (pointer)
                        emit("push rdx");  // Save length
                    } else if (is_struct_param) {
                        // For struct <= 8 bytes, just push the value in rax
                        // (no special handling needed)
                    }
                    
                    emit("push rax");
                }
            }
            
            // Pop first 4 args into registers (in reverse order since we pushed in reverse)
            size_t reg_count = std::min<size_t>(arg_count, 4);
            for (int i = static_cast<int>(reg_count) - 1; i >= 0; --i) {
                emit(std::string("pop ") + arg_regs[i]);
            }
            
            // Remaining args are already on stack in correct order (after registers)
            
            emit("call " + full_function_name);

            // Clean up: shadow space + any stack args
            size_t stack_args = (arg_count > 4) ? (arg_count - 4) : 0;
            emit("add rsp, " + std::to_string(32 + stack_args * 8));
        }
    }
    else {
        throw std::runtime_error("Unknown expression type in codegen");
    }
}

void CodeGenerator::generate_statement(const StmtNode* stmt) {
    if (const auto* var_decl = dynamic_cast<const VarDeclStmt*>(stmt)) {
        // Define variable first so we know its stack offset for struct initializers
        symbol_table.define(var_decl->name, var_decl->type, var_decl->needs_cleanup);
        auto* sym = symbol_table.resolve(var_decl->name);
        if (var_decl->initializer) {
            // Struct literal initializer: write fields into the struct storage
            if (auto struct_lit = dynamic_cast<const StructLiteralExpr*>(var_decl->initializer.get())) {
                if (!var_decl->type || !var_decl->type->is_struct()) {
                    throw std::runtime_error("Struct literal used to initialize non-struct variable");
                }
                auto stype = symbol_table.resolve_struct(var_decl->type->struct_name);
                if (!stype) throw std::runtime_error("Unknown struct type: " + var_decl->type->struct_name);

                // For each field initializer, evaluate expression and store at field offset
                for (const auto& f : struct_lit->fields) {
                    const std::string& fname = f.first;
                    const ExprNode* val = f.second.get();
                    size_t field_offset = symbol_table.get_field_offset(var_decl->type->struct_name, fname);
                    if (field_offset == 0) throw std::runtime_error("Unknown field '" + fname + "' for struct " + var_decl->type->struct_name);

                    // Generate value into rax/xmm0
                    generate_expression(val);

                    // Find the field type to know how to store
                    std::shared_ptr<Type> ftype = nullptr;
                    for (const auto& ff : stype->fields) {
                        if (ff.name == fname) { ftype = ff.type; break; }
                    }
                    if (!ftype) throw std::runtime_error("Internal error: field type not found");

                    // Compute destination address in rbx = rbp - sym->stack_offset + field_offset
                    emit("lea rbx, [rbp - " + std::to_string(sym->stack_offset) + "]");
                    if (field_offset > 0) emit("add rbx, " + std::to_string(field_offset));

                    if (ftype->base == BaseType::DEC64) {
                        emit("movsd [rbx], xmm0");
                    } else if (ftype->is_error_union()) {
                        // Expect value in rax and error flag in rdx
                        emit("mov [rbx], rax");
                        emit("mov [rbx + 8], rdx");
                    } else if (ftype->is_fat_pointer()) {
                        // Fat pointer initialized by providing pointer in rax and len in rdx
                        emit("mov [rbx], rax");
                        emit("mov [rbx + 8], rdx");
                    } else {
                        emit("mov [rbx], rax");
                    }
                }
            }
            else {
                // Non-struct initializer: evaluate and store normally
                generate_expression(var_decl->initializer.get());
                if (var_decl->type->is_error_union()) {
                    emit("mov [rbp - " + std::to_string(sym->stack_offset) + "], rax");     // value
                    emit("mov [rbp - " + std::to_string(sym->stack_offset + 8) + "], rdx");  // error flag
                }
                else if (var_decl->type->is_fat_pointer()) {
                    emit("mov [rbp - " + std::to_string(sym->stack_offset) + "], rax");
                    emit("mov [rbp - " + std::to_string(sym->stack_offset + 8) + "], rdx");
                }
                else if (var_decl->type && var_decl->type->base == BaseType::DEC64) {
                    emit("movsd [rbp - " + std::to_string(sym->stack_offset) + "], xmm0");
                }
                else {
                    emit("mov [rbp - " + std::to_string(sym->stack_offset) + "], rax");
                }

                // Auto cleanup: remember fat pointers for implicit free at scope exit
                if (var_decl->is_auto && var_decl->type->is_fat_pointer()) {
                    auto_free_stack.push_back(var_decl->name);
                }
            }
        } else {
            // No initializer
        }
        return;
    }
    else if (const auto* assign = dynamic_cast<const AssignStmt*>(stmt)) {
        generate_expression(assign->right.get());
        
        if (const auto* id = dynamic_cast<const IdentifierExpr*>(assign->left.get())) {
            auto* sym = symbol_table.resolve(id->name);
            if (!sym) throw std::runtime_error("Undefined variable: " + id->name);
            
            // For error union variables, store both value and error flag
            if (sym->type && sym->type->is_error_union()) {
                emit("mov [rbp - " + std::to_string(sym->stack_offset) + "], rax");     // value
                emit("mov [rbp - " + std::to_string(sym->stack_offset + 8) + "], rdx");  // error flag
            }
            // For dec64 variables, use movsd
            else if (sym->type && sym->type->base == BaseType::DEC64) {
                emit("movsd [rbp - " + std::to_string(sym->stack_offset) + "], xmm0");
            } else {
                emit("mov [rbp - " + std::to_string(sym->stack_offset) + "], rax");
            }
        }
        else if (const auto* idx = dynamic_cast<const IndexExpr*>(assign->left.get())) {
            emit("push rax");
            generate_expression(idx->index.get());
            emit("mov rbx, rax");
            
            if (const auto* arr_id = dynamic_cast<const IdentifierExpr*>(idx->array.get())) {
                auto* sym = symbol_table.resolve(arr_id->name);
                emit("mov rcx, [rbp - " + std::to_string(sym->stack_offset + 8) + "]");
                emit("cmp rbx, rcx");
                emit("jae _panic_bounds_error");
                
                emit("mov rax, [rbp - " + std::to_string(sym->stack_offset) + "]");
                emit("pop rdx");
                
                // Calculate element size from array element type
                size_t elem_size = 8; // default
                if (sym->type && sym->type->element_type) {
                    elem_size = sym->type->element_type->size();
                }
                emit("mov [rax + rbx*" + std::to_string(elem_size) + "], rdx");
            }
        }
        else if (const auto* field = dynamic_cast<const FieldAccessExpr*>(assign->left.get())) {
            // Handle struct field assignment: obj.field = value
            emit("push rax");  // Save the value to assign
            
            if (const auto* obj = dynamic_cast<const IdentifierExpr*>(field->object.get())) {
                auto* sym = symbol_table.resolve(obj->name);
                if (!sym) throw std::runtime_error("Undefined variable: " + obj->name);
                
                size_t field_offset = symbol_table.get_field_offset(sym->type->struct_name, field->field_name);
                emit("lea rbx, [rbp - " + std::to_string(sym->stack_offset) + "]");
                emit("pop rax");  // Get the value back
                emit("mov [rbx + " + std::to_string(field_offset) + "], rax");
            }
        }
    }
    else if (const auto* if_stmt = dynamic_cast<const IfStmt*>(stmt)) {
        std::string else_label = generate_label("else");
        std::string end_label = generate_label("endif");
        
        generate_expression(if_stmt->condition.get());
        emit("test rax, rax");
        emit("jz " + else_label);
        
        for (const auto& s : if_stmt->then_block) {
            generate_statement(s.get());
        }
        emit("jmp " + end_label);
        
        emit(else_label + ":");
        for (const auto& s : if_stmt->else_block) {
            generate_statement(s.get());
        }
        
        emit(end_label + ":");
    }
    else if (const auto* while_stmt = dynamic_cast<const WhileStmt*>(stmt)) {
        std::string start = generate_label("while_start");
        std::string end = generate_label("while_end");
        
        emit(start + ":");
        generate_expression(while_stmt->condition.get());
        emit("test rax, rax");
        emit("jz " + end);
        
        for (const auto& s : while_stmt->body) {
            generate_statement(s.get());
        }
        
        emit("jmp " + start);
        emit(end + ":");
    }
    else if (const auto* match_stmt = dynamic_cast<const MatchStmt*>(stmt)) {
        generate_expression(match_stmt->value.get());
        emit("push rax");
        
        std::string end_label = generate_label("match_end");
        
        for (const auto& c : match_stmt->cases) {
            std::string next_case = generate_label("match_case");
            
            emit("pop rax");
            emit("push rax");
            generate_expression(c.pattern.get());
            emit("mov rbx, rax");
            emit("pop rax");
            emit("push rax");
            emit("cmp rax, rbx");
            emit("jne " + next_case);
            
            for (const auto& s : c.body) {
                generate_statement(s.get());
            }
            emit("jmp " + end_label);
            emit(next_case + ":");
        }
        
        for (const auto& s : match_stmt->default_case) {
            generate_statement(s.get());
        }
        
        emit("pop rax");
        emit(end_label + ":");
    }
    else if (const auto* asm_stmt = dynamic_cast<const AsmStmt*>(stmt)) {
        std::istringstream iss(asm_stmt->code);
        std::string line;
        while (std::getline(iss, line)) {
            if (line.empty()) continue;
            emit(line);
        }
    }
    else if (const auto* ret = dynamic_cast<const ReturnStmt*>(stmt)) {
        if (ret->value) {
            generate_expression(ret->value.get());
        } else {
            emit("xor rax, rax");
        }
        generate_defer_instrumentation();
        emit("mov rsp, rbp");
        emit("pop rbp");
        emit("ret");
    }
    else if (const auto* defer_stmt = dynamic_cast<const DeferStmt*>(stmt)) {
        // Store pointer to statement for later execution
        if (defer_stmt->statement) {
            defer_stack.push_back(defer_stmt->statement.get());
        }
    }
    else if (const auto* block = dynamic_cast<const BlockStmt*>(stmt)) {
        symbol_table.push_scope();
        // Collect defers declared directly inside this block so they execute
        // only if the block is actually entered. Defer statements found here
        // are emitted at the end of the block in LIFO order.
        std::vector<const DeferStmt*> local_defers;
        for (const auto& s : block->statements) {
            if (auto ds = dynamic_cast<const DeferStmt*>(s.get())) {
                local_defers.push_back(ds);
            } else {
                generate_statement(s.get());
            }
        }

        // Emit local defers in reverse order (LIFO) at block exit
        for (auto it = local_defers.rbegin(); it != local_defers.rend(); ++it) {
            if (*it && (*it)->statement) {
                generate_statement((*it)->statement.get());
            }
        }

        symbol_table.pop_scope();
    }
    else if (const auto* expr_stmt = dynamic_cast<const ExprStmt*>(stmt)) {
        // Evaluate expression and discard result.
        generate_expression(expr_stmt->expr.get());
    }
}

void CodeGenerator::generate_defer_instrumentation() {
    // Preserve return value (rax) across cleanup code which might clobber it (e.g. free/VirtualFree)
    bool has_cleanup = !defer_stack.empty() || !auto_free_stack.empty();
    if (has_cleanup) emit("push rax");

    if (!defer_stack.empty()) {
        emit_comment("Defer cleanup (LIFO)");
        for (auto it = defer_stack.rbegin(); it != defer_stack.rend(); ++it) {
            generate_statement(*it);
        }
    }

    if (!auto_free_stack.empty()) {
        emit_comment("Auto cleanup for fat pointers (LIFO)");
        for (auto it = auto_free_stack.rbegin(); it != auto_free_stack.rend(); ++it) {
            emit_auto_free(*it);
        }
    }

    if (has_cleanup) emit("pop rax");
}

void CodeGenerator::emit_auto_free(const std::string& name) {
    auto* sym = symbol_table.resolve(name);
    if (!sym) return;
    
    if (target_platform == TargetPlatform::LINUX) {
        // Linux: munmap(ptr, len)
        emit("mov rdi, [rbp - " + std::to_string(sym->stack_offset) + "]");
        emit("mov rsi, [rbp - " + std::to_string(sym->stack_offset + 8) + "]");
        emit("mov rax, 11"); // munmap
        emit("syscall");
    } else {
        // Windows: VirtualFree(ptr, 0, MEM_RELEASE)
        emit("mov rcx, [rbp - " + std::to_string(sym->stack_offset) + "]");
        emit("xor rdx, rdx");  // dwSize = 0
        emit("mov r8, 0x8000");  // MEM_RELEASE
        emit("sub rsp, 32");  // Shadow space
        emit("call VirtualFree");
        emit("add rsp, 32");
    }
}

void CodeGenerator::generate_builtin_call(const CallExpr* call) {
    if (call->function == "say") {
            require_derive("io", "say");
            // First argument should be format string
            if (call->arguments.empty()) {
                return;  // Invalid say call
            }
            
            // Extract format string to count floating point specifiers
            const auto* fmt_str = dynamic_cast<const StringExpr*>(call->arguments[0].get());
            std::string format = fmt_str ? fmt_str->value : "";
        // Count %f and %e and %g specifiers
        int float_indices[4] = {-1, -1, -1, -1};
        int float_count_needed = 0;
        size_t arg_index = 1;
        
        for (size_t i = 0; i < format.length() && arg_index <= 4; i++) {
            if (format[i] == '%' && i + 1 < format.length()) {
                char spec = format[i + 1];
                if (spec == 'f' || spec == 'e' || spec == 'g' || spec == 'E' || spec == 'G') {
                    float_indices[arg_index - 1] = arg_index - 1;
                    float_count_needed++;
                } else if (spec != '%') {
                    // Skip %%
                }
                arg_index++;
                i++;
            }
        }
        
        if (target_platform == TargetPlatform::LINUX) {
            // Linux: Use printf (System V ABI)
            // rdi, rsi, rdx, rcx, r8, r9 for integer args
            // xmm0-xmm7 for float args
            int xmm_idx = 0;
            
            // Generate format string first
            generate_expression(call->arguments[0].get());
            emit("mov rdi, rax");
            
            // Handle remaining arguments
            for (size_t i = 1; i < call->arguments.size() && i < 4; i++) {
                bool is_float_arg = (float_indices[i - 1] >= 0);
                bool arg_is_decimal = is_decimal_expression(call->arguments[i].get());
                
                // Generate expression first - it will put result in xmm0 if decimal, rax if integer
                generate_expression(call->arguments[i].get());
                
                // If format says float OR argument is decimal, treat as float
                if (is_float_arg || arg_is_decimal) {
                    // If argument is not decimal but format says float, convert from integer
                    if (!arg_is_decimal && is_float_arg) {
                        emit("cvtsi2sd xmm0, rax");  // Convert integer to double
                    }
                    // Value in xmm0, move to xmm{xmm_idx}
                    if (xmm_idx > 0) {
                        emit("movsd xmm" + std::to_string(xmm_idx) + ", xmm0");
                    }
                    xmm_idx++;
                } else {
                    // Value in rax, move to appropriate register
                    if (i == 1) emit("mov rsi, rax");
                    else if (i == 2) emit("mov rdx, rax");
                    else if (i == 3) emit("mov rcx, rax");
                }
            }
            
            emit("mov rax, " + std::to_string(float_count_needed));
            emit("call say_impl");
        } else {
            // Windows: Use printf (Microsoft x64 ABI)
            // rcx, rdx, r8, r9 for integer args
            // xmm0-xmm3 for float args
            
            // Generate format string first and preserve it
            generate_expression(call->arguments[0].get());
            // rax has format string pointer, rdx has length (fat pointer)
            // We only need rax for printf, save it in r10 temporarily
            emit("mov r10, rax");  // Save format string pointer in r10
            
            // Handle remaining arguments
            // (no xmm_idx needed on Windows; floats are passed into specific xmm registers)

            // Windows x64 ABI: rcx=format, rdx, r8, r9 for ints; xmm1, xmm2, xmm3 for floats (first float arg is xmm1)
            for (size_t i = 1; i < call->arguments.size() && i < 4; i++) {
                bool is_float_arg = (float_indices[i - 1] >= 0);
                bool arg_is_decimal = is_decimal_expression(call->arguments[i].get());
                
                // Generate expression first - it will put result in xmm0 if decimal, rax if integer
                generate_expression(call->arguments[i].get());
                
                // If format says float OR argument is decimal, treat as float
                if (is_float_arg || arg_is_decimal) {
                    // If argument is not decimal but format says float, convert from integer
                    if (!arg_is_decimal && is_float_arg) {
                        emit("cvtsi2sd xmm0, rax");  // Convert integer to double
                    }
                    // On Windows x64, floats must be passed BOTH in XMM registers AND integer registers
                    // Move the XMM value to the corresponding integer register (following GCC pattern)
                    if (i == 1) {
                        emit("movq rdx, xmm0");  // rdx gets the float bits as integer
                        emit("movapd xmm1, xmm0");  // xmm1 gets the float
                    } else if (i == 2) {
                        emit("movq r8, xmm0");   // r8 gets the float bits
                        emit("movapd xmm2, xmm0");  // xmm2 gets the float
                    } else if (i == 3) {
                        emit("movq r9, xmm0");   // r9 gets the float bits
                        emit("movapd xmm3, xmm0");  // xmm3 gets the float
                    }
                } else {
                    // Value is in rax, move to appropriate register
                    if (i == 1) {
                        emit("mov rdx, rax");
                    } else if (i == 2) {
                        emit("mov r8, rax");
                    } else if (i == 3) {
                        emit("mov r9, rax");
                    }
                }
            }
            
            // Restore format string pointer to rcx
            emit("mov rcx, r10");  // rcx = format string pointer (from r10)
            
            // On Windows x64 with MinGW, printf does NOT use AL for XMM count
            // The values are passed in both XMM registers and integer registers
            emit("sub rsp, 32");  // Shadow space
            emit("call printf");
            emit("add rsp, 32");
        }
    }
    else if (call->function == "alloc") {
        // Use runtime helper cup_alloc(size) -> returns pointer in rax
        generate_expression(call->arguments[0].get());
        emit("mov r11, rax"); // save size
        if (target_platform == TargetPlatform::LINUX) {
            emit("mov rdi, r11");
            emit("call cup_alloc");
        } else {
            emit("mov rcx, r11");
            emit("sub rsp, 32");
            emit("call cup_alloc");
            emit("add rsp, 32");
        }
        emit("mov rdx, r11");
    }
    else if (call->function == "free") {
        // Use runtime helper cup_free(ptr, size)
        generate_expression(call->arguments[0].get());
        // Expect pointer in rax, length in rdx
        if (target_platform == TargetPlatform::LINUX) {
            emit("mov rdi, rax");
            emit("mov rsi, rdx");
            emit("call cup_free");
        } else {
            emit("mov rcx, rax");
            emit("mov rdx, rdx");
            emit("sub rsp, 32");
            emit("call cup_free");
            emit("add rsp, 32");
        }
    }
    else if (call->function == "copy") {
        // Use runtime helper cup_copy(src_ptr, size) -> returns new ptr in rax
        generate_expression(call->arguments[0].get());
        emit("mov r11, rdx"); // save size
        if (target_platform == TargetPlatform::LINUX) {
            emit("mov rdi, rax");
            emit("mov rsi, r11");
            emit("call cup_copy");
        } else {
            emit("mov rcx, rax");
            emit("mov rdx, r11");
            emit("sub rsp, 32");
            emit("call cup_copy");
            emit("add rsp, 32");
        }
        emit("mov rdx, r11");
    }
    else if (call->function == "chr") {
        // chr(i64) -> u8[] - convert int to single character string
        generate_expression(call->arguments[0].get());
        // rax has the character code
        std::string label = generate_label("chr_str");
        data_section << label << ": db 0, 0\n";  // Will be modified at runtime (char, null terminator)
        
        emit("lea r11, [rel " + label + "]");  // r11 = pointer to chr_str
        emit("mov [r11], al");  // Store character byte
        emit("mov rax, r11");   // rax = pointer
        emit("mov rdx, 1");     // rdx = length (1 character)
    }
    else if (call->function == "ord") {
        // ord(u8[]) -> i64 - convert first character to int code
        generate_expression(call->arguments[0].get());
        // rax = pointer, rdx = length
        emit("cmp rdx, 0");     // Check if empty
        emit("je _panic_empty_string");
        emit("movzx rax, byte [rax]");  // Load first byte and zero-extend to rax
    }
    else if (call->function == "abs") {
        // abs(i64) -> i64
        generate_expression(call->arguments[0].get());
        emit("test rax, rax");
        emit("jns _abs_skip");  // Jump if not negative
        emit("neg rax");
        emit("_abs_skip:");
    }
    else if (call->function == "min") {
        // min(i64, i64) -> i64
        generate_expression(call->arguments[0].get());
        emit("push rax");
        generate_expression(call->arguments[1].get());
        emit("mov rbx, rax");
        emit("pop rax");
        emit("cmp rax, rbx");
        emit("jle _min_skip");  // Jump if first <= second
        emit("mov rax, rbx");
        emit("_min_skip:");
    }
    else if (call->function == "max") {
        // max(i64, i64) -> i64
        generate_expression(call->arguments[0].get());
        emit("push rax");
        generate_expression(call->arguments[1].get());
        emit("mov rbx, rax");
        emit("pop rax");
        emit("cmp rax, rbx");
        emit("jge _max_skip");  // Jump if first >= second
        emit("mov rax, rbx");
        emit("_max_skip:");
    }
    else if (call->function == "array_create") {
        // array_create(size: i64) -> u8[] - creates zero-filled array
        generate_expression(call->arguments[0].get());
        // rax = size
        emit("mov r11, rax");  // Save size in r11
        
        if (target_platform == TargetPlatform::LINUX) {
            emit("mov rax, 9");   // mmap syscall
            emit("xor rdi, rdi"); // addr = NULL
            emit("mov rsi, r11"); // length = size
            emit("mov rdx, 0x3"); // PROT_READ|PROT_WRITE
            emit("mov r10, 0x22"); // MAP_PRIVATE|MAP_ANONYMOUS
            emit("mov r8, -1");   // fd = -1
            emit("xor r9, r9");   // offset = 0
            emit("syscall");
        } else {
            emit("mov rcx, 0");      // lpAddress = NULL
            emit("mov rdx, r11");    // dwSize = size
            emit("mov r8, 0x3000");  // MEM_COMMIT|MEM_RESERVE
            emit("mov r9, 0x4");     // PAGE_READWRITE
            emit("sub rsp, 32");     // Shadow space
            emit("call VirtualAlloc");
            emit("add rsp, 32");
        }
        emit("mov rdx, r11");   // rdx = length
        // rax already has pointer
    }
    else if (call->function == "array_append") {
        // array_append(arr: u8[], val: u8) -> u8[] - not fully implementable without Vec struct
        // For now, just return the array as-is (would need Vec integration)
        generate_expression(call->arguments[0].get());
        // This would ideally use the collections Vec, but we'll keep it simple
    }
    else if (call->function == "panic") {
        // panic(msg: u8[]) - print message and exit
        generate_expression(call->arguments[0].get());
        // rax = message pointer, rdx = length
        
        if (target_platform == TargetPlatform::LINUX) {
            // write(2, msg, len) then exit(1)
            emit("mov rdi, 2");     // fd = stderr
            emit("mov rsi, rax");   // buf = message pointer
            emit("mov rdx, rdx");   // count = length
            emit("mov rax, 1");     // write syscall
            emit("syscall");
            
            emit("mov rax, 60");    // exit syscall
            emit("mov rdi, 1");     // code = 1
            emit("syscall");
        } else {
            // Windows: call ExitProcess after printing to console
            emit("mov rcx, rax");   // lpString = message pointer
            emit("sub rsp, 32");    // Shadow space
            emit("call printf");
            emit("add rsp, 32");
            
            emit("mov rcx, 1");     // uExitCode = 1
            emit("sub rsp, 32");    // Shadow space
            emit("call ExitProcess");
            emit("add rsp, 32");
        }
    }
    else if (call->function == "assert") {
        // assert(cond: bool, msg: u8[])
        generate_expression(call->arguments[0].get());
        emit("test rax, rax");
        emit("jnz _assert_pass");   // Jump if condition is true
        
        // Condition is false, call panic with message
        generate_expression(call->arguments[1].get());
        // rax = message pointer, rdx = length
        
        if (target_platform == TargetPlatform::LINUX) {
            emit("mov rdi, 2");     // fd = stderr
            emit("mov rsi, rax");   // buf = message pointer
            emit("mov rdx, rdx");   // count = length (note: already in rdx from expression)
            emit("mov rax, 1");     // write syscall
            emit("syscall");
            
            emit("mov rax, 60");    // exit syscall
            emit("mov rdi, 1");     // code = 1
            emit("syscall");
        } else {
            emit("mov rcx, rax");   // lpString = message pointer
            emit("sub rsp, 32");    // Shadow space
            emit("call printf");
            emit("add rsp, 32");
            
            emit("mov rcx, 1");     // uExitCode = 1
            emit("sub rsp, 32");    // Shadow space
            emit("call ExitProcess");
            emit("add rsp, 32");
        }
        
        emit("_assert_pass:");
    }
    else if (call->function == "shl") {
        // shl(value: i64, shift: i64) -> i64 - shift left
        generate_expression(call->arguments[0].get());
        emit("push rax");
        generate_expression(call->arguments[1].get());
        emit("mov rcx, rax");   // rcx = shift amount (must be in cl or immediate)
        emit("pop rax");
        emit("shl rax, cl");
    }
    else if (call->function == "shr") {
        // shr(value: i64, shift: i64) -> i64 - shift right (logical)
        generate_expression(call->arguments[0].get());
        emit("push rax");
        generate_expression(call->arguments[1].get());
        emit("mov rcx, rax");   // rcx = shift amount
        emit("pop rax");
        emit("shr rax, cl");
    }
    else if (call->function == "rotl") {
        // rotl(value: i64, shift: i64) -> i64 - rotate left
        generate_expression(call->arguments[0].get());
        emit("push rax");
        generate_expression(call->arguments[1].get());
        emit("mov rcx, rax");   // rcx = shift amount
        emit("pop rax");
        emit("rol rax, cl");
    }
    else if (call->function == "rotr") {
        // rotr(value: i64, shift: i64) -> i64 - rotate right
        generate_expression(call->arguments[0].get());
        emit("push rax");
        generate_expression(call->arguments[1].get());
        emit("mov rcx, rax");   // rcx = shift amount
        emit("pop rax");
        emit("ror rax, cl");
    }
    else if (call->function == "float_to_int") {
        // float_to_int(f64) -> i64
        generate_expression(call->arguments[0].get());
        // xmm0 contains float
        emit("cvttsd2si rax, xmm0");  // Convert truncated scalar double to signed int
    }
    else if (call->function == "int_to_float") {
        // int_to_float(i64) -> f64
        generate_expression(call->arguments[0].get());
        // rax contains integer
        emit("cvtsi2sd xmm0, rax");  // Convert signed int to scalar double
    }
    else if (call->function == "open") {
        // open(path: u8[], flags: i64) -> !i64 - just return fake fd for now
        generate_expression(call->arguments[0].get());
        emit("mov rax, 3");     // Fake file descriptor
        emit("mov rdx, 0");     // Success
    }
    else if (call->function == "close") {
        // close(fd: i64) -> !null
        generate_expression(call->arguments[0].get());
        emit("xor rax, rax");   // return null
        emit("mov rdx, 0");     // Success
    }
    else if (call->function == "read") {
        // read(fd: i64, buffer: u8[]) -> !i64
        generate_expression(call->arguments[0].get());
        emit("mov rax, 0");     // Return 0 bytes read
        emit("mov rdx, 0");     // Success
    }
    else if (call->function == "write") {
        // write(fd: i64, data: u8[]) -> !i64
        generate_expression(call->arguments[0].get());
        emit("push rax");
        generate_expression(call->arguments[1].get());
        emit("pop rcx");
        emit("mov rax, rdx");   // Return bytes written (data length)
        emit("mov rdx, 0");     // Success
    }
    else if (call->function == "get_size" || call->function == "get_mtime" ||
             call->function == "delete" || call->function == "mkdir" ||
             call->function == "rmdir" || call->function == "read_dir" ||
             call->function == "set_perms" || call->function == "create") {
        // Forward these file-related builtins to runtime helpers implemented in lib/cup/runtime/file.cup
        // Evaluate arguments in reverse and push to stack, then pop into registers per ABI and call.
        int arg_count = static_cast<int>(call->arguments.size());
        for (int i = arg_count - 1; i >= 0; --i) {
            generate_expression(call->arguments[i].get());
            emit("push rax");
        }

        if (target_platform == TargetPlatform::LINUX) {
            static const char* regs[] = {"rdi", "rsi", "rdx", "rcx", "r8", "r9"};
            int reg_count = std::min(arg_count, 6);
            for (int i = 0; i < reg_count; ++i) {
                emit(std::string("pop ") + regs[i]);
            }
            // Call runtime helper (name matches the builtin)
            emit("call " + call->function);
            // Caller cleans up any extra stack args (not expected here)
        } else {
            // Windows x64: rcx, rdx, r8, r9
            static const char* regs[] = {"rcx", "rdx", "r8", "r9"};
            int reg_count = std::min(arg_count, 4);
            for (int i = 0; i < reg_count; ++i) {
                emit(std::string("pop ") + regs[i]);
            }
            // If there are more args, they remain on stack (rare)
            emit("sub rsp, 32"); // shadow space
            emit("call " + call->function);
            emit("add rsp, 32");
        }
        // Result registers are left as returned by the runtime helper
    }
    else if (call->function == "error") {
        // error(value: T) -> !T - wraps a value in error union
        // Error unions are 16 bytes: 8 bytes data + 8 bytes error flag
        // If error flag is non-zero, the value is an error; otherwise it's success with data
        generate_expression(call->arguments[0].get());

        // rax = value (for most types), xmm0 = value (for float)
        // Need to set error flag to indicate this is an error value
        // Return: [value in rax][error_flag=1 in rdx]

        emit("mov rdx, 1");  // rdx = error flag (1 = error, 0 = success)
        // rax already has the value
    }
    else if (call->function == "test_assert" || call->function == "test_eq" ||
             call->function == "test_ne" || call->function == "test_gt" ||
             call->function == "test_lt") {
        // Test assertion functions
        uses_test_functions = true;  // Mark that test functions are used
        if (call->function == "test_assert") {
            // test_assert(condition: bool) - panics if condition is false
            generate_expression(call->arguments[0].get());
            emit("test rax, rax");  // Test condition
            emit("jnz _test_assert_pass_" + std::to_string(label_counter));  // Skip panic if true

            // Generate panic for failed assertion
            emit("mov rdi, 2");     // fd = stderr
            emit("lea rsi, [rel test_fail_msg]");
            emit("mov rdx, 19");    // length of "Assertion failed\n"
            emit("mov rax, 1");     // write syscall
            emit("syscall");

            emit("mov rax, 60");    // exit syscall
            emit("mov rdi, 1");     // code = 1
            emit("syscall");

            emit("_test_assert_pass_" + std::to_string(label_counter) + ":");
            label_counter++;
        } else {
            // Comparison assertions: test_eq, test_ne, test_gt, test_lt
            generate_expression(call->arguments[0].get());  // First argument
            emit("push rax");  // Save first value
            generate_expression(call->arguments[1].get());  // Second argument
            emit("mov rbx, rax");  // Second value in rbx
            emit("pop rax");   // First value back in rax

            std::string cmp_op;
            if (call->function == "test_eq") {
                emit("cmp rax, rbx");
                emit("jne _test_cmp_fail_" + std::to_string(label_counter));
            } else if (call->function == "test_ne") {
                emit("cmp rax, rbx");
                emit("je _test_cmp_fail_" + std::to_string(label_counter));
            } else if (call->function == "test_gt") {
                emit("cmp rax, rbx");
                emit("jle _test_cmp_fail_" + std::to_string(label_counter));
            } else if (call->function == "test_lt") {
                emit("cmp rax, rbx");
                emit("jge _test_cmp_fail_" + std::to_string(label_counter));
            }

            emit("_test_cmp_pass_" + std::to_string(label_counter) + ":");
            label_counter++;
        }
    }
    else {
        throw std::runtime_error("Unknown builtin: " + call->function);
    }
}

std::string CodeGenerator::generate_function(const FunctionDecl* func) {
    emit_comment("Function: " + func->name);
    output << "global " << func->name << "\n";
    output << func->name << ":\n";
    emit("push rbp");
    emit("mov rbp, rsp");

    symbol_table.reset_stack();
    defer_stack.clear();
    auto_free_stack.clear();

    symbol_table.push_scope();

    // Load parameters into symbol table so they receive stack offsets
    std::vector<std::string> param_names;
    for (const auto& [type, name] : func->params) {
        param_names.push_back(name);
        symbol_table.define(name, type);
    }

    // Define local variables (this assigns stack offsets for local vars)
    for (const auto& stmt : func->body) {
        define_local_variables(stmt.get());
    }

    // Compute total stack size from the symbol table (subtract RBP reserve)
    size_t stack_size = symbol_table.get_stack_size();
    if (stack_size % 16 != 0) {
        stack_size = (stack_size + 15) & ~15;
    }

    if (stack_size > 0) {
        emit("sub rsp, " + std::to_string(stack_size));
    }
    
    // For each parameter, move it from register/stack to the defined stack location
    if (target_platform == TargetPlatform::WINDOWS) {
        // Microsoft x64 ABI: rcx, rdx, r8, r9
        static const char* arg_regs[] = {"rcx", "rdx", "r8", "r9"};
        for (size_t i = 0; i < param_names.size() && i < 4; ++i) {
            auto* sym = symbol_table.resolve(param_names[i]);
            if (sym) {
                // For struct types larger than 8 bytes, treat them as pointers
                if (sym->type && sym->type->base == BaseType::STRUCT && sym->type->size() > 8) {
                    // rcx contains the address of the struct
                    emit(std::string("mov rax, ") + arg_regs[i]);
                    // Copy the struct from [rax] to [rbp - offset]
                    size_t struct_size = sym->type->size();
                    size_t qwords = (struct_size + 7) / 8;
                    emit("mov rcx, " + std::to_string(qwords));
                    emit("mov rsi, rax");
                    emit("mov rdi, rbp");
                    emit("sub rdi, " + std::to_string(sym->stack_offset));
                    emit("rep movsq");
                } else {
                    emit(std::string("mov rax, ") + arg_regs[i]);
                    emit("mov [rbp - " + std::to_string(sym->stack_offset) + "], rax");
                }
            }
        }
    } else {
        // System V ABI: rdi, rsi, rdx, rcx, r8, r9
        static const char* arg_regs[] = {"rdi", "rsi", "rdx", "rcx", "r8", "r9"};
        for (size_t i = 0; i < param_names.size() && i < 6; ++i) {
            auto* sym = symbol_table.resolve(param_names[i]);
            if (sym) {
                // For struct types larger than 8 bytes, treat them as pointers
                if (sym->type && sym->type->base == BaseType::STRUCT && sym->type->size() > 8) {
                    // Register contains the address of the struct
                    emit(std::string("mov rax, ") + arg_regs[i]);
                    // Copy the struct from [rax] to [rbp - offset]
                    size_t struct_size = sym->type->size();
                    size_t qwords = (struct_size + 7) / 8;
                    emit("mov rcx, " + std::to_string(qwords));
                    emit("mov rsi, rax");
                    emit("mov rdi, rbp");
                    emit("sub rdi, " + std::to_string(sym->stack_offset));
                    emit("rep movsq");
                } else {
                    emit(std::string("mov rax, ") + arg_regs[i]);
                    emit("mov [rbp - " + std::to_string(sym->stack_offset) + "], rax");
                }
            }
        }
    }
    
    for (const auto& stmt : func->body) {
        generate_statement(stmt.get());
    }
    
    symbol_table.pop_scope();
    
    generate_defer_instrumentation();
    
    emit("mov rsp, rbp");
    emit("pop rbp");
    emit("ret");
    output << "\n";
    
    return output.str();
}

std::string CodeGenerator::generate_program(const std::vector<std::unique_ptr<FunctionDecl>>& functions,
                                            const std::vector<std::unique_ptr<StructDecl>>& structs,
                                            const std::vector<std::string>& derives_in) {
    derives = &derives_in;
    
    // Register all structs first
    for (const auto& struct_decl : structs) {
        auto struct_type = std::make_shared<Type>(BaseType::STRUCT);
        struct_type->struct_name = struct_decl->name;
        
        // Add fields to struct type
        for (const auto& field : struct_decl->fields) {
            struct_type->add_field(field->name, field->type);
        }
        
        symbol_table.define_struct(struct_decl->name, struct_type);
    }
    
    set_functions(functions);
    output << "section .text\n";
    if (target_platform == TargetPlatform::WINDOWS) {
        // Prefer RIP-relative addressing on x86-64 (especially important for PE/COFF relocations).
        output << "default rel\n";
    }
    
    if (target_platform == TargetPlatform::LINUX) {
        output << "extern say_impl\n";
        output << "extern printf\n\n";
        output << "extern cup_alloc\n";
        output << "extern cup_free\n";
        output << "extern cup_copy\n";
        output << "extern fmod\n";
    } else {
        output << "extern say_impl\n";
        output << "extern printf\n";
        output << "extern getchar\n";
        output << "extern VirtualAlloc\n";
        output << "extern VirtualFree\n";
        output << "extern GetStdHandle\n";
        output << "extern WriteFile\n";
        output << "extern ExitProcess\n";
        output << "extern Sleep\n";
        // File I/O functions
        output << "extern CreateFileA\n";
        output << "extern CloseHandle\n";
        output << "extern ReadFile\n";
        output << "extern DeleteFileA\n";
        output << "extern CreateDirectoryA\n";
        output << "extern RemoveDirectoryA\n";
        output << "extern GetFileAttributesExA\n";
        output << "extern GetTickCount64\n\n";
    }
    
    for (const auto& func : functions) {
        if (func->is_extern) {
            output << "extern " << func->name << "\n";
        }
    }
    output << "\n";
    
    emit_comment("Entry point wrapper");
    if (target_platform == TargetPlatform::LINUX) {
        output << "global _start\n";
        output << "_start:\n";
        emit("push rbp");
        emit("mov rbp, rsp");
        emit("and rsp, -16");
        emit("call start");
        emit("mov rdi, rax");
        emit("mov rax, 60");  // exit syscall
        emit("syscall");
    } else {
        // IMPORTANT:
        // Use a normal `main` entrypoint so MinGW/GCC's CRT startup objects
        // (crt2.o) can provide `mainCRTStartup` without symbol conflicts.
        output << "global main\n";
        output << "main:\n";
        // Windows x64 ABI requires 32 bytes of shadow space for calls.
        // Also keep stack 16-byte aligned for the callee.
        // We must preserve RBX (callee-saved) if we use it.
        emit("push rbx");     // Align stack (8 bytes return + 8 bytes push = 16 aligned)
        emit("sub rsp, 32");  // Shadow space (stack remains aligned)

        emit("call start");
        // Preserve start() return in rbx (callee-saved) across the Sleep/pause call
        emit("mov rbx, rax");
        emit("add rsp, 32");  // Clean up shadow space
        
        // Handle pause behavior before exit
        if (pause_on_enter) {
            // Wait for user to press Enter by reading stdin
            emit("lea rcx, [rel pause_msg]");  // Print message
            emit("sub rsp, 32");
            emit("call printf");
            emit("add rsp, 32");
            emit("sub rsp, 32");
            emit("call getchar");  // Wait for Enter key
            emit("add rsp, 32");
        } else {
            // Auto-pause with 3 second sleep so console window doesn't close immediately
            emit("mov ecx, 3000");  // 3000 milliseconds
            emit("sub rsp, 32");    // Shadow space for Sleep call
            emit("call Sleep");
            emit("add rsp, 32");
        }
        
        emit("mov rax, rbx"); // Restore return value into rax so the CRT sees the start() return as process exit code
        emit("pop rbx");      // Restore caller's RBX
        emit("ret");          // return value in rax (mapped to eax for exit)
    }
    output << "\n";
    
    emit_comment("Panic handlers");
    output << "_panic_bounds_error:\n";
    if (target_platform == TargetPlatform::LINUX) {
        emit("mov rax, 1");  // write syscall
        emit("mov rdi, 2");  // stderr
        emit("lea rsi, [rel panic_msg]");
        emit("mov rdx, 23");
        emit("syscall");
        emit("mov rax, 60");  // exit syscall
        emit("mov rdi, 1");  // exit code
        emit("syscall");
    } else {
        // Windows: WriteFile(GetStdHandle(STD_ERROR_HANDLE), ...)
        emit("mov rcx, -11");  // STD_ERROR_HANDLE
        emit("sub rsp, 32");
        emit("call GetStdHandle");
        emit("add rsp, 32");
        emit("mov rcx, rax");  // hFile
        emit("lea rdx, [rel panic_msg]");  // lpBuffer
        emit("mov r8, 23");  // nNumberOfBytesToWrite
        emit("lea r9, [rsp - 8]");  // lpNumberOfBytesWritten (stack temp)
        emit("push 0");  // lpOverlapped = NULL
        emit("sub rsp, 32");
        emit("call WriteFile");
        emit("add rsp, 40");
        emit("mov ecx, 1");  // Exit code
        emit("call ExitProcess");
    }
    output << "\n";
    
    output << "section .data\n";
    output << "panic_msg: db 'Bounds check failed', 10, 0\n";
    if (target_platform == TargetPlatform::WINDOWS && pause_on_enter) {
        output << "pause_msg: db 'Press Enter to exit...', 0\n";
    }
    output << "section .text\n\n";
    
    for (const auto& func : functions) {
        if (func->is_extern) continue;
        std::stringstream func_output;
        std::swap(output, func_output);
        generate_function(func.get());
        std::swap(output, func_output);
        output << func_output.str();
    }
    
    // Output accumulated data section at the end if any data was accumulated
    if (data_section.tellp() > 0) {
        output << "\nsection .data\n";
        output << data_section.str();
    }

    // Output collected assembly sections from imported runtime files
    if (assembly_sections.tellp() > 0) {
        output << "\n; Runtime assembly sections\n";
        output << assembly_sections.str();
    }

    // Add test-related data if any test functions were used
    if (uses_test_functions) {
        output << "\ntest_fail_msg: db 'Assertion failed', 10, 0\n";
    }
    
    return output.str();
}