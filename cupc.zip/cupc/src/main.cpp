#include "lexer.h"
#include "parser.h"
#include "codegen.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <algorithm>
#include <filesystem>

#include "process.h"
#include "log.h"
#ifdef _WIN32
#include <windows.h>
#endif


namespace fs = std::filesystem;

#ifdef _WIN32
    #define IS_WINDOWS true
#else
    #define IS_WINDOWS false
#endif

// Check if tool exists and is executable
bool tool_exists(const std::string& tool_name) {
    std::string cmd;
    #ifdef _WIN32
        // Use SearchPath to avoid shelling out
        char path[MAX_PATH];
        return SearchPathA(NULL, tool_name.c_str(), ".exe", MAX_PATH, path, NULL) != 0;
    #else
        int rc = run_process({"which", tool_name});
        return rc == 0;
    #endif
}

void run_command(const std::vector<std::string>& args) {
    int rc = run_process(args);
    if (rc != 0) {
        log_error() << "Command failed: ";
        for (size_t i = 0; i < args.size(); ++i) {
            if (i) log_error() << " ";
            log_error() << args[i];
        }
        log_error() << '\n';
        std::exit(1);
    }
}

void compile(const std::string& source_file,
             const std::string& output_exe,
             bool optimise = false,
             bool pause_on_enter = false)
{
    // Get absolute path of source file to find project root
    fs::path source_path = fs::absolute(source_file);
    fs::path project_root = source_path.parent_path();
    
    // Try to find project root by looking for lib/cup directory
    while (!fs::exists(project_root / "lib" / "cup") && project_root.has_parent_path()) {
        project_root = project_root.parent_path();
    }
    
    std::ifstream input(source_file);
    if (!input) throw std::runtime_error("Cannot open " + source_file);
    std::string source{ std::istreambuf_iterator<char>(input),
                        std::istreambuf_iterator<char>() };

    SymbolTable sym;
    std::vector<std::unique_ptr<FunctionDecl>> all_funcs;
    std::vector<std::unique_ptr<StructDecl>> all_structs;
    std::vector<std::string> all_derives;
    
    // Helper lambda to merge derives without duplicates
    auto merge_derives = [&](const std::vector<std::string>& ds) {
        for (const auto& d : ds) {
            if (std::find(all_derives.begin(), all_derives.end(), d) == all_derives.end()) {
                all_derives.push_back(d);
            }
        }
    };

    // Compile the root module
    Lexer lexer(source);
    auto tokens = lexer.tokenize();

    // (debug token printing removed)

    Parser parser(tokens, sym);
    auto funcs = parser.parse();

    if (!parser.get_errors().empty()) {
        for (const auto& err : parser.get_errors()) {
            log_error() << "Parse error at line " << err.token.line << ": " << err.message << " (at '" << err.token.lexeme << "')\n";
        }
        std::exit(1);
    }

    if (!parser.has_start()) throw std::runtime_error("No int64: start()");

    // Move root structs/functions
    auto& root_structs = parser.get_structs();
    for (auto& s : root_structs) {
        all_structs.push_back(std::move(s));
    }
    for (auto& f : funcs) {
        all_funcs.push_back(std::move(f));
    }
    merge_derives(parser.get_derives());

    // Register top-level constants from root module
    for (auto& c : parser.get_constants()) {
        log_info() << "Registering constant: " << c->name << "\n";
        sym.define_constant(c->name, c->type, std::move(c->initializer));
    }
    

    // Detect target platform (default to host platform, can be made configurable)
    TargetPlatform target_platform = IS_WINDOWS ? TargetPlatform::WINDOWS : TargetPlatform::LINUX;

    CodeGenerator gen(sym, target_platform);
    gen.set_pause_on_enter(pause_on_enter);

    // Auto-import runtime libraries for derives
    // Process all derives iteratively until no new ones are added, with safety counter
    bool new_derives_added = true;
    int derive_iteration_count = 0;
    const int MAX_DERIVE_ITERATIONS = 10;  // Prevent infinite loops

    while (new_derives_added && derive_iteration_count < MAX_DERIVE_ITERATIONS) {
        new_derives_added = false;
        std::vector<std::string> current_derives = all_derives;  // Take snapshot to avoid concurrent modification

        for (const auto& derive_name : current_derives) {
            // Check if we've already processed this derive in this iteration
            fs::path runtime_path = project_root / "lib" / "cup" / "runtime" / (derive_name + ".cup");
            std::ifstream runtime_check(runtime_path);
            if (runtime_check) {
                // Runtime file exists, add it as an import
                runtime_check.close();
                std::ifstream in(runtime_path);
                if (in) {
                    std::string src{ std::istreambuf_iterator<char>(in),
                                   std::istreambuf_iterator<char>() };
                    Lexer lx(src);
                    auto toks = lx.tokenize();
                    Parser p2(toks, sym);
                    auto f2 = p2.parse();
                    auto& s2 = p2.get_structs();
                    for (auto& s : s2) {
                        all_structs.push_back(std::move(s));
                    }
                    for (auto& f : f2) {
                        all_funcs.push_back(std::move(f));
                    }

                    // Collect all inline assembly from AST, then add sections
                    p2.collect_assembly_sections_from_ast();
                    for (const auto& asm_section : p2.get_assembly_sections()) {
                        gen.add_assembly_section(asm_section);
                    }

                    size_t old_size = all_derives.size();
                    merge_derives(p2.get_derives());
                    if (all_derives.size() > old_size) {
                        new_derives_added = true;  // New derives were added, continue iteration
                    }
                }
            }
        }
        derive_iteration_count++;
    }

    // Special handling for common runtime dependencies
    // If io or memory is used, bridges.cup likely contains needed assembly implementations
    bool has_io = std::find(all_derives.begin(), all_derives.end(), "io") != all_derives.end();
    bool has_memory = std::find(all_derives.begin(), all_derives.end(), "memory") != all_derives.end();
    bool has_file = std::find(all_derives.begin(), all_derives.end(), "file") != all_derives.end();
    bool has_sys = std::find(all_derives.begin(), all_derives.end(), "sys") != all_derives.end();

    if (has_io || has_memory || has_file || has_sys) {
        // Import bridges.cup which contains common assembly implementations
        fs::path bridges_path = project_root / "lib" / "cup" / "runtime" / "bridges.cup";
        std::ifstream bridges_check(bridges_path);
        if (bridges_check) {
            bridges_check.close();
            std::ifstream bridges_in(bridges_path);
            if (bridges_in) {
                std::string src{ std::istreambuf_iterator<char>(bridges_in),
                               std::istreambuf_iterator<char>() };
                Lexer lx(src);
                auto toks = lx.tokenize();
                Parser p2(toks, sym);
                auto f2 = p2.parse();
                auto& s2 = p2.get_structs();
                for (auto& s : s2) {
                    all_structs.push_back(std::move(s));
                }
                for (auto& f : f2) {
                    all_funcs.push_back(std::move(f));
                }

                // Collect all inline assembly from AST, then add sections
                p2.collect_assembly_sections_from_ast();
                for (const auto& asm_section : p2.get_assembly_sections()) {
                    gen.add_assembly_section(asm_section);
                }
            }
        }
    }

    // Load imports (shallow for now)
    for (const auto& imp : parser.get_imports()) {
        std::ifstream in(imp);
        if (!in) throw std::runtime_error("Cannot open import " + imp);
        std::string src{ std::istreambuf_iterator<char>(in),
                         std::istreambuf_iterator<char>() };
        Lexer lx(src);
        auto toks = lx.tokenize();
        Parser p2(toks, sym);
        auto f2 = p2.parse();
        auto& s2 = p2.get_structs();
        for (auto& s : s2) {
            all_structs.push_back(std::move(s));
        }
        for (auto& f : f2) {
            all_funcs.push_back(std::move(f));
        }
        // Register top-level constants from this file
        for (auto& c : p2.get_constants()) {
            sym.define_constant(c->name, c->type, std::move(c->initializer));
        }


        // Collect all inline assembly from AST, then add sections
        p2.collect_assembly_sections_from_ast();
        for (const auto& asm_section : p2.get_assembly_sections()) {
            gen.add_assembly_section(asm_section);
        }


        merge_derives(p2.get_derives());
    }

    std::string asm_text = gen.generate_program(all_funcs, all_structs, all_derives);

    std::string asm_file = output_exe + ".asm";
    std::ofstream(asm_file) << asm_text;

    // Check for required tools
    std::string nasm_tool = "nasm";
    std::string gcc_tool = "gcc";
    
    #ifdef _WIN32
        nasm_tool = "nasm.exe";
        gcc_tool = "gcc.exe";
    #endif
    
    if (!tool_exists(nasm_tool)) {
        log_error() << "Error: " << nasm_tool << " not found in PATH\n";
        log_error() << "Make sure NASM and GCC are installed correctly.\n";
        std::exit(1);
    }
    
    if (!tool_exists(gcc_tool)) {
        log_error() << "Error: " << gcc_tool << " not found in PATH\n";
        log_error() << "Make sure NASM and GCC are installed correctly.\n";
        std::exit(1);
    }

    // Determine assembler to use based on directives or default
    std::string assembler_tool = nasm_tool;  // Default to nasm
    std::vector<std::string> assembler_args;

    // Check if parser detected any toolchain directives
    const auto& config = parser.get_toolchain_config();
    if (config.use_nasm) {
        assembler_tool = nasm_tool;
    } else if (!config.use_default_chain) {
        // If not using default chain and not nasm, could add other assemblers here
        assembler_tool = nasm_tool;  // Default fallback
    }

    // Choose assembler format based on target platform
    std::string asm_format = (target_platform == TargetPlatform::WINDOWS) ? "win64" : "elf64";
    assembler_args = {assembler_tool, "-f", asm_format, asm_file, "-o", output_exe + ".o"};

    // Define target platform symbol for inline-asm conditionals
    if (target_platform == TargetPlatform::WINDOWS) {
        assembler_args.push_back("-DWINDOWS");
    } else {
        assembler_args.push_back("-DLINUX");
    }
    if (optimise) assembler_args.push_back("-Ox");

    run_command(assembler_args);

    // Compile any C runtime helpers located in lib/cup/runtime/ and link them in.
    std::vector<std::string> helper_objs;
    std::string runtime_dir = (project_root / "lib" / "cup" / "runtime").string();
    try {
        for (const auto &entry : std::filesystem::directory_iterator(runtime_dir)) {
            if (!entry.is_regular_file()) continue;
            auto path = entry.path();
            if (path.extension() == ".c") {
                std::string src = path.string();
                std::string obj = output_exe + "." + path.stem().string() + ".o";
                std::vector<std::string> compile_helper_args = {gcc_tool, "-c", src, "-o", obj};
                if (optimise) compile_helper_args.push_back("-O3");
                run_command(compile_helper_args);
                helper_objs.push_back(obj);
            }
        }
    } catch (...) {
        // ignore if runtime dir missing
    }

    // Determine linker to use based on directives or default
    std::string linker_tool = gcc_tool;  // Default to gcc
    std::vector<std::string> link_args;

    // Check if parser detected any linker directives
    const auto& link_config = parser.get_toolchain_config();
    if (link_config.use_gcc_linker) {
        linker_tool = gcc_tool;
    } else if (!link_config.use_default_chain) {
        // If not using default chain and not gcc, use custom cupld if available
        // Check if cupld executable exists
        if (tool_exists("bin/cupld.exe") || tool_exists("bin/cupld")) {
            // Use custom cupld linker
            link_args = {"bin/cupld", output_exe + ".o"};
            for (const auto &h : helper_objs) link_args.push_back(h);
            link_args.push_back("-o");
            link_args.push_back(output_exe + (target_platform == TargetPlatform::WINDOWS ? ".exe" : ""));
            if (target_platform == TargetPlatform::WINDOWS) {
                link_args.push_back("--platform");
                link_args.push_back("windows");
            } else {
                link_args.push_back("--platform");
                link_args.push_back("linux");
            }
            if (link_config.debug_enabled) {
                link_args.push_back("--verbose");
            }
            run_command(link_args);
            return; // Early return since we used custom linker
        }
    }

    // Use standard GCC linking
    if (target_platform == TargetPlatform::WINDOWS) {
        // Windows: let GCC/MinGW select the correct CRT and default system libs.
        std::string exe_name = output_exe;
        if (exe_name.length() < 4 || exe_name.substr(exe_name.length() - 4) != ".exe") {
            exe_name += ".exe";
        }
        link_args = {linker_tool, output_exe + ".o"};
        for (const auto &h : helper_objs) link_args.push_back(h);
        link_args.push_back("-o");
        link_args.push_back(exe_name);
        if (optimise) link_args.push_back("-O3");
    } else {
        // Linux: standard linking
        link_args = {linker_tool, output_exe + ".o"};
        for (const auto &h : helper_objs) link_args.push_back(h);
        link_args.push_back("-o");
        link_args.push_back(output_exe);
        link_args.push_back("-lc");
        link_args.push_back("-no-pie");
        if (optimise) link_args.push_back("-O3");
        // Auto-link math lib when runtime 'math' derive is used (for fmod, sqrt, etc.)
        if (std::find(all_derives.begin(), all_derives.end(), "math") != all_derives.end()) {
            link_args.push_back("-lm");
        }
    }
    run_command(link_args);

    // Keep .asm file for debugging (comment out to delete)
    // std::remove((output_exe + ".asm").c_str());
    std::remove((output_exe + ".o").c_str());

    std::cout << "[OK] Built: " << output_exe << (target_platform == TargetPlatform::WINDOWS ? ".exe" : "") << '\n';
}

void show_version() {
    std::cout << "cupc version 1.0.0\n";
    std::cout << "C-UP Compiler\n";
    std::cout << "Copyright (C) 2026 Only Up\n";
}

void show_dir(const std::string& path) {
    try {
        for (auto& p : fs::directory_iterator(path)) {
            std::cout << p.path().filename().string() << "\n";
        }
    } catch (const std::exception& e) {
        log_error() << "Error listing directory: " << e.what() << '\n';
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        log_error() << "Usage: cupc <source.cup> <output> [-O] [--pause-on-enter]\n";
        log_error() << "       cupc --version\n";
        log_error() << "       cupc --dir <path>\n";
        return 1;
    }
    
    std::string first_arg = argv[1];
    
    if (first_arg == "--version" || first_arg == "-v") {
        show_version();
        return 0;
    }
    
    if (first_arg == "--dir" || first_arg == "-d") {
        if (argc < 3) {
            log_error() << "Usage: cupc --dir <path>\n";
            return 1;
        }
        show_dir(argv[2]);
        return 0;
    }
    
    if (argc < 3) {
        log_error() << "Usage: cupc <source.cup> <output> [-O] [--pause-on-enter]\n";
        return 1;
    }
    
    bool opt = false;
    bool pause_on_enter = false;
    
    for (int i = 3; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "-O") opt = true;
        if (arg == "--pause-on-enter") pause_on_enter = true;
    }
    
    try {
        compile(argv[1], argv[2], opt, pause_on_enter);
    } catch (const std::exception& e) {
        log_error() << "Compilation error: " << e.what() << '\n';
        return 1;
    }
    return 0;
}