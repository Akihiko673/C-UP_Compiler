$testDir = Join-Path $PSScriptRoot '..\test'
if (-not (Test-Path $testDir)) { Write-Host "Test directory not found: $testDir"; exit 1 }
Get-ChildItem -Path $testDir -File | Where-Object { $_.Name -ne 'comprehensive_test.cup' } | ForEach-Object {
    Write-Host "Deleting: $($_.FullName)"
    Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
}
Write-Host "Cleanup complete." 
