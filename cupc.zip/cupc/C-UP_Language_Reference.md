# C-UP Programming Language Comprehensive Guide

## Table of Contents
1. [Introduction](#introduction)
2. [Getting Started](#getting-started)
3. [Lexical Structure](#lexical-structure)
4. [Data Types](#data-types)
5. [Variables and Constants](#variables-and-constants)
6. [Operators](#operators)
7. [Expressions](#expressions)
8. [Statements](#statements)
9. [Functions](#functions)
10. [Control Flow](#control-flow)
11. [Structs](#structs)
12. [Memory Management](#memory-management)
13. [Namespaces](#namespaces)
14. [Error Handling](#error-handling)
15. [Standard Libraries](#standard-libraries)
16. [Build System](#build-system)
17. [Advanced Features](#advanced-features)
18. [Platform Support](#platform-support)
19. [Best Practices](#best-practices)
20. [Troubleshooting](#troubleshooting)

## Introduction

C-UP is a systems programming language designed for predictability, performance, and low-level control. It combines the simplicity of C with modern language features while maintaining direct control over hardware resources.

### Philosophy
- **Predictability**: Every line of C-UP code maps directly to a predictable sequence of assembly instructions
- **Performance**: Zero-cost abstractions with no hidden allocations or overhead
- **Control**: Direct access to system resources and memory management
- **Safety**: Runtime checks for bounds and error conditions while allowing unsafe operations when needed

### Key Features
- Statically typed with type inference
- Manual memory management with automatic cleanup (`auto` keyword)
- Structs with field access
- Fat pointers for arrays and strings
- Error unions for explicit error handling
- Namespaces for code organization
- Inline assembly support
- Cross-platform compilation (Windows/Linux)
- Self-contained toolchain

## Getting Started

### Installation
The C-UP toolchain includes:
- `cupc.exe` - The C-UP compiler
- `cupld.exe` - The C-UP linker
- `cupasm.exe` - The C-UP assembler
- `cup.exe` - The build manager

### Hello World
```cup
#derive <io>

int64: start() {
    say("Hello, World!\n");
    return 0;
}
```

### Compilation
```bash
cupc program.cup program.exe
# Or using the build manager
cup build program.cup program
```

## Lexical Structure

### Comments
```cup
// Single-line comment
/* Multi-line
   comment */
```

### Identifiers
- Start with letter or underscore
- Followed by letters, digits, or underscores
- Case-sensitive

### Literals

#### Integer Literals
```cup
int64: x = 42;        // Decimal
int64: y = 0xFF;      // Hexadecimal
int64: z = 0b1010;    // Binary (if supported)
```

#### Decimal Literals
```cup
dec64: pi = 3.14159;
dec64: e = 2.71828;
```

#### String Literals
```cup
u8[]: greeting = "Hello, C-UP!";
```

#### Boolean Literals
```cup
bool: is_true = true;
bool: is_false = false;
```

#### Null Literal
```cup
u8[]: ptr = null;
```

### Keywords
- `if`, `else`, `while`, `for`, `loop`, `match`, `return`, `defer`
- `struct`, `module`, `import`, `derive`, `extern`, `const`, `auto`, `var`
- `asm`, `get`, `len`, `tick`, `catch`

## Data Types

### Primitive Types

| Type ---| Size    | Description               |
|---------|---------|---------------------------|
| `int64` | 8 bytes | Signed 64-bit integer     |
| `int32` | 4 bytes | Signed 32-bit integer     |
| `dec64` | 8 bytes | IEEE-754 double precision |
| `dec32` | 4 bytes | IEEE-754 single precision |
| `u8`    | 1 byte  | Unsigned 8-bit byte       |
| `bool`  | 1 byte  | Boolean (0 or 1)          |
| `null`  | 0 bytes | Null pointer type         |

### Composite Types

#### Arrays (Fat Pointers)
```cup
u8[]: string = "Hello";     // String as byte array
int64[]: numbers = alloc(10); // Allocated array
```

Arrays in C-UP are "fat pointers" consisting of:
- 8-byte pointer to data
- 8-byte length (total 16 bytes)

#### Structs
```cup
struct: Point {
    int64: x;
    int64: y;
}

struct: Rectangle {
    Point: top_left;
    Point: bottom_right;
}
```

#### Error Unions
```cup
!int64: result = potentially_failing_function();
```

Error unions are 16 bytes: 8 bytes for value, 8 bytes for error flag.

### Type Inference
```cup
var: x = 42;        // Infers int64
var: y = 3.14;      // Infers dec64
var: z = "hello";   // Infers u8[]
```

## Variables and Constants

### Variable Declarations
```cup
int64: x = 10;              // Explicit type
var: y = 20;                // Type inference
auto u8[]: buffer = alloc(100); // Auto cleanup
const int64: PI = 3.14159;   // Compile-time constant
```

### Storage Modifiers
- `auto`: Automatic cleanup at scope exit
- `const`: Compile-time constant
- `extern`: External linkage

## Operators

### Arithmetic Operators
| Operator | Description    |
|----------|----------------|
| `+`      | Addition       |
| `-`      | Subtraction    |
| `*`      | Multiplication |
| `/`      | Division       |
| `%`      | Modulo         |

### Comparison Operators
| Operator | Description           |
|----------|-----------------------|
| `==`     | Equal                 |
| `!=`     | Not equal             |
| `<`      | Less than             |
| `>`      | Greater than          |
| `<=`     | Less than or equal    |
| `>=`     | Greater than or equal |

### Logical Operators
| Operator | Description |
|----------|-------------|
| `&&`     | Logical AND |
| `||`     | Logical OR  |
| `!`      | Logical NOT |

### Bitwise Operators
| Operator | Description |
|----------|-------------|
| `&`      | Bitwise AND |
| `|`      | Bitwise OR  |
| `^`      | Bitwise XOR |
| `<<`     | Left shift  |
| `>>`     | Right shift |

### Assignment Operators
| Operator | Description         |
|----------|---------------------|
| `=`      | Assignment          |
| `+=`     | Add and assign      |
| `-=`     | Subtract and assign |
| `*=`     | Multiply and assign |
| `/=`     | Divide and assign   |
| `%=`     | Modulo and assign   |

## Expressions

### Primary Expressions
- Literals: `42`, `3.14`, `"hello"`, `true`, `false`, `null`
- Identifiers: `variable_name`
- Parenthesized expressions: `(expression)`

### Postfix Expressions
- Function calls: `function(arg1, arg2)`
- Array indexing: `array[index]`
- Field access: `object.field`

### Unary Expressions
- Negation: `-x`, `!x`
- Address-of: `&x` (when implemented)
- Dereference: `*x` (when implemented)

### Binary Expressions
- Arithmetic: `a + b`, `a - b`, etc.
- Comparison: `a == b`, `a < b`, etc.
- Logical: `a && b`, `a || b`
- Bitwise: `a & b`, `a | b`, etc.

## Statements

### Expression Statement
```cup
x + y;  // Expression with side effects
function_call();
```

### Declaration Statement
```cup
int64: x = 10;
auto u8[]: buffer = alloc(100);
```

### Assignment Statement
```cup
x = 42;
array[0] = value;
object.field = value;
```

### Control Flow Statements

#### If Statement
```cup
if (condition) {
    // then block
} else {
    // else block
}
```

#### While Loop
```cup
while (condition) {
    // loop body
}
```

#### For Loop (Simulated)
```cup
int64: i = 0;
while (i < 10) {
    // loop body
    i = i + 1;
}
```

#### Match Statement
```cup
match (value) {
    0 => { stmt1; },
    1 => { stmt2; },
    default => { default_stmt; }
}
```

#### Return Statement
```cup
return expression;
return;  // For void functions
```

#### Defer Statement
```cup
defer cleanup_function();
// cleanup_function() executes when scope exits
```

### Block Statement
```cup
{
    int64: x = 10;
    int64: y = 20;
    return x + y;
}
```

### Inline Assembly
```cup
asm {
    mov rax, 1
    mov rdi, 1
    mov rsi, msg
    mov rdx, msg_len
    syscall
}
```

## Functions

### Function Declaration
```cup
return_type: function_name(param_type: param_name, ...) {
    // function body
    return value;
}
```

### Example
```cup
int64: add(int64: a, int64: b) {
    return a + b;
}

int64: start() {
    int64: result = add(10, 20);
    return result;
}
```

### Function Parameters
- Passed by value for primitive types
- Fat pointers passed as (pointer, length) pair
- Structs passed by value if ≤8 bytes, by reference if larger

### Calling Convention
- Linux: System V AMD64 ABI (RDI, RSI, RDX, RCX, R8, R9)
- Windows: Microsoft x64 ABI (RCX, RDX, R8, R9 + shadow space)

## Control Flow

### Conditional Execution
```cup
if (x > 0) {
    say("Positive\n");
} else if (x < 0) {
    say("Negative\n");
} else {
    say("Zero\n");
}
```

### Loops
```cup
// While loop
int64: i = 0;
while (i < 10) {
    say("Iteration: %d\n", i);
    i = i + 1;
}

// Infinite loop
loop {
    // body executes forever
    if (condition) break;
}
```

### Match Statement
```cup
match (x) {
    0 => { say("Zero\n"); },
    1 => { say("One\n"); },
    default => { say("Other\n"); }
}
```

### Defer Statement
```cup
int64: example() {
    auto u8[]: buffer = alloc(100);
    defer {
        free(buffer);
        say("Buffer freed\n");
    }
    
    // Use buffer
    // Buffer will be freed when function exits
    return 0;
}
```

## Structs

### Declaration
```cup
struct: Point {
    int64: x;
    int64: y;
}

struct: Rectangle {
    Point: top_left;
    Point: bottom_right;
}
```

### Instantiation
```cup
Point: p = { x: 10, y: 20 };
Rectangle: rect = { top_left: { x: 0, y: 0 }, bottom_right: { x: 100, y: 50 } };
```

### Field Access
```cup
int64: x_coord = p.x;
rect.top_left.x = 5;
```

## Memory Management

### Manual Allocation
```cup
auto u8[]: buffer = alloc(1024);  // Allocate 1KB
// Use buffer...
// Automatically freed when buffer goes out of scope
```

### Explicit Deallocation
```cup
u8[]: ptr = alloc(100);
free(ptr);  // Explicitly free memory
```

### Fat Pointers
Arrays and strings in C-UP are "fat pointers" containing:
- Pointer to data (8 bytes)
- Length (8 bytes)
- Total: 16 bytes

### Bounds Checking
Array accesses include runtime bounds checking:
```cup
u8[]: arr = alloc(10);
arr[15] = 42;  // Causes runtime panic
```

## Namespaces

### Declaration
```cup
namespace: math {
    int64: add(int64: a, int64: b) {
        return a + b;
    }
    
    int64: multiply(int64: a, int64: b) {
        return a * b;
    }
}
```

### Usage
```cup
int64: result = math::add(5, 3);
```

## Error Handling

### Error Unions
```cup
!int64: divide(int64: a, int64: b) {
    if (b == 0) {
        return error(-1);  // Return error
    }
    return a / b;  // Return success value
}
```

### Error Handling
```cup
!int64: result = divide(10, 2) catch {
    say("Division failed\n");
    return -1;
};
```

## Standard Libraries

### Available Libraries

#### `#derive <io>`
Input/output operations:
- `say(format, ...)`: Formatted output
- `print(str)`: Print string
- `println(str)`: Print string with newline

#### `#derive <memory>`
Memory management:
- `alloc(size)`: Allocate memory
- `free(ptr)`: Free memory
- `copy(src)`: Copy memory

#### `#derive <file>`
File operations:
- `read_file(path)`: Read file contents
- `write_file(path, data)`: Write data to file
- `file_exists(path)`: Check if file exists

#### `#derive <math>`
Mathematical functions:
- `sqrt(x)`: Square root
- `sin(x)`, `cos(x)`, `tan(x)`: Trigonometric functions
- `pow(base, exp)`: Power function
- `abs(x)`: Absolute value

#### `#derive <sys>`
System operations:
- `sleep(ms)`: Sleep for milliseconds
- `exit(code)`: Exit program
- `get_time()`: Get current time

### Using Standard Libraries
```cup
#derive <io>
#derive <memory>

int64: start() {
    auto u8[]: buffer = alloc(100);
    say("Allocated buffer\n");
    return 0;
}
```

## Build System

### Directives
- `#derive <library>`: Include standard library
- `#derive <io>`, `#derive <memory>`, etc.

### Build Commands
```bash
cupc source.cup output.exe    # Compile directly
cup build source.cup output   # Use build manager
```

### Custom Toolchain Directives
- `#say_ass_nasm`: Use NASM assembler
- `#say_ld_gcc`: Use GCC linker
- `#say_dbg`: Enable debugging

## Advanced Features

### Inline Assembly
```cup
int64: get_tick_count() {
    int64: result;
    asm {
        rdtsc
        shl rdx, 32
        or rax, rdx
        mov [rbp - 8], rax  // Store in local variable
    }
    return result;
}
```

### Struct Literals
```cup
Point: p = { x: 10, y: 20 };
Rectangle: rect = { top_left: { x: 0, y: 0 }, bottom_right: { x: 100, y: 50 } };
```

### Fat Pointer Operations
```cup
u8[]: str = "Hello, World!";
int64: length = len(str);  // Get length of fat pointer
u8: first_char = str[0];  // Access element
```

## Platform Support

### Windows
- Uses Microsoft x64 calling convention
- Generates PE/COFF object files
- Links with Windows C runtime

### Linux
- Uses System V AMD64 ABI
- Generates ELF64 object files
- Links with glibc

### Cross-Compilation
The same C-UP source can be compiled for both platforms with appropriate toolchain configuration.

## Best Practices

### Memory Management
- Use `auto` for automatic cleanup of allocated memory
- Always check bounds when accessing arrays
- Free memory in the same scope where it was allocated when possible

### Error Handling
- Use error unions for functions that can fail
- Handle errors explicitly rather than ignoring them
- Use defer for cleanup operations

### Performance
- Minimize allocations in performance-critical code
- Use stack allocation for small, temporary data
- Profile code to identify bottlenecks

### Code Organization
- Use namespaces to organize related functionality
- Keep functions focused on a single responsibility
- Document public APIs clearly

## Troubleshooting

### Common Issues

#### Compilation Errors
- "Undefined variable": Check spelling and scope
- "Type mismatch": Verify types match expected parameters
- "Cannot derive library": Ensure runtime files exist

#### Runtime Errors
- "Bounds check failed": Array access out of bounds
- "Division by zero": Check divisor before division
- "Invalid pointer": Use after free or null pointer access

### Debugging Tips
- Use `say()` for simple debugging output
- Check generated assembly with `.asm` files
- Use bounds checking to catch array errors early

## Appendices

### Appendix A: Reserved Keywords
`if`, `else`, `while`, `for`, `loop`, `match`, `return`, `defer`, `struct`, `module`, `import`, `derive`, `extern`, `const`, `auto`, `var`, `asm`, `get`, `len`, `tick`, `catch`, `default`, `namespace`, `test`, `say_ass_nasm`, `say_ld_gcc`, `say_dbg`

### Appendix B: Built-in Functions
- `len()`: Get length of fat pointer
- `say()`: Formatted output
- `alloc()`: Allocate memory
- `free()`: Free memory
- `tick()`: Get CPU cycle count

### Appendix C: Assembly Directives
- `#say_ass_nasm`: Use NASM assembler
- `#say_ld_gcc`: Use GCC linker
- `#say_dbg`: Enable debugging

### Appendix D: Type Sizes
- `int64`, `dec64`: 8 bytes
- `int32`, `dec32`: 4 bytes
- `u8`: 1 byte
- `bool`: 1 byte
- Fat pointers: 16 bytes (8-byte ptr + 8-byte len)
- Error unions: 16 bytes (8-byte value + 8-byte error flag)