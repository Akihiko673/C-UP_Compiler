#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H

#include "type.h"
#include "ast.h"
#include <vector>
#include <unordered_map>
#include <string>

struct Symbol {
    std::shared_ptr<Type> type;
    size_t stack_offset;
    bool is_array_length = false; // hidden _len
    bool needs_cleanup   = false; // for auto
    bool is_builtin      = false; // library function
    bool is_const        = false; // top-level constant flag

    Symbol() : type(nullptr), stack_offset(0), needs_cleanup(false) {}  // Default constructor
    Symbol(std::shared_ptr<Type> t, size_t off, bool cleanup = false)
        : type(std::move(t)), stack_offset(off), needs_cleanup(cleanup) {}
};

struct ScopeInfo {
    std::unordered_map<std::string, Symbol> symbols;
    size_t stack_offset_at_entry;  // Stack offset when this scope was entered
};

class SymbolTable {
private:
    std::vector<ScopeInfo> scopes;
    std::unordered_map<std::string, std::shared_ptr<Type>> struct_types;
    std::unordered_map<std::string, std::unordered_map<std::string, Symbol>> namespaces;  // namespace -> {name -> Symbol}
    size_t current_stack_offset = 16; // after RBP

    // Top-level compile-time constants: name -> initializer expression
    std::unordered_map<std::string, std::unique_ptr<ExprNode>> constants;

public:
    SymbolTable() { push_scope(); }

    void push_scope() {
        scopes.push_back({{}, current_stack_offset});
    }

    void pop_scope() {
        if (!scopes.empty()) {
            // Restore the stack offset to what it was when this scope was entered
            current_stack_offset = scopes.back().stack_offset_at_entry;
            scopes.pop_back();
        }
    }

    void define(const std::string& name, std::shared_ptr<Type> type, bool cleanup = false) {
        size_t size = type->size();
        size_t align = type->alignment;

        // Align stack offset to type's alignment requirement
        if (align > 1) {
            current_stack_offset = (current_stack_offset + align - 1) & ~(align - 1);
        }

        Symbol sym{std::move(type), current_stack_offset, cleanup};
        scopes.back().symbols.insert_or_assign(name, sym);

        // For fat pointer types (arrays, strings), store length as hidden variable
        // but NOT for structs - struct data is stored inline
        if ((sym.type->is_array() || (sym.type->base == BaseType::U8 && sym.type->element_type))
            && !sym.type->is_struct()) {
            std::string len_name = name + "_len";
            Symbol len_sym{std::make_shared<Type>(BaseType::INT64), current_stack_offset + 8, false};
            len_sym.is_array_length = true;
            scopes.back().symbols.insert_or_assign(len_name, len_sym);
        }
        current_stack_offset += size;
    }

    Symbol* resolve(const std::string& name) {
        for (auto it = scopes.rbegin(); it != scopes.rend(); ++it) {
            auto found = it->symbols.find(name);
            if (found != it->symbols.end()) return &found->second;
        }
        return nullptr;
    }

    void define_struct(const std::string& name, std::shared_ptr<Type> struct_type) {
        struct_types[name] = struct_type;
    }

    std::shared_ptr<Type> resolve_struct(const std::string& name) {
        auto it = struct_types.find(name);
        return (it != struct_types.end()) ? it->second : nullptr;
    }

    size_t get_field_offset(const std::string& struct_name, const std::string& field_name) {
        auto st = resolve_struct(struct_name);
        if (!st || !st->is_struct()) return 0;
        for (const auto& f : st->fields)
            if (f.name == field_name) return f.offset;
        return 0;
    }

    size_t get_stack_size() const { return current_stack_offset - 16; }
    void reset_stack() { current_stack_offset = 16; }

    // Define a top-level constant (inserts into global scope and records initializer)
    void define_constant(const std::string& name, std::shared_ptr<Type> type, std::unique_ptr<ExprNode> init) {
        Symbol sym{std::move(type), 0, false};
        sym.is_const = true;
        if (scopes.empty()) push_scope();
        scopes.front().symbols.insert_or_assign(name, sym);
        constants[name] = std::move(init);
    }

    // Return initializer pointer if constant exists, otherwise nullptr
    ExprNode* get_constant_init(const std::string& name) {
        auto it = constants.find(name);
        return (it != constants.end()) ? it->second.get() : nullptr;
    }

    bool is_constant(const std::string& name) {
        return constants.find(name) != constants.end();
    }

    // Namespace operations
    void define_in_namespace(const std::string& ns, const std::string& name, std::shared_ptr<Type> type, size_t offset, bool cleanup = false) {
        namespaces[ns][name] = Symbol{std::move(type), offset, cleanup};
    }

    Symbol* resolve_from_namespace(const std::string& ns, const std::string& name) {
        auto ns_it = namespaces.find(ns);
        if (ns_it != namespaces.end()) {
            auto sym_it = ns_it->second.find(name);
            if (sym_it != ns_it->second.end()) {
                return &(sym_it->second);
            }
        }
        return nullptr;
    }

    bool namespace_exists(const std::string& ns) const {
        return namespaces.count(ns) > 0;
    }
};

#endif