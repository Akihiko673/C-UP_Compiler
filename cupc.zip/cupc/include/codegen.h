#ifndef CODEGEN_H
#define CODEGEN_H

#include "ast.h"
#include "symbol_table.h"
#include <string>
#include <sstream>
#include <vector>
#include <map>
#include <set>

enum class TargetPlatform {
    WINDOWS,
    LINUX
};

class CodeGenerator {
private:
    SymbolTable& symbol_table;
    std::stringstream output;
    std::stringstream data_section;  // Accumulate .data section declarations
    std::stringstream assembly_sections;  // Collect inline assembly sections from runtime files
    std::set<std::string> collected_symbols;  // Track collected symbols to avoid duplicates
    size_t label_counter = 0;
    std::vector<const StmtNode*> defer_stack;
    std::vector<std::string> auto_free_stack;
    const std::vector<std::string>* derives = nullptr;
    TargetPlatform target_platform;
    std::map<std::string, const FunctionDecl*> function_map;
    bool pause_on_enter = false;  // Flag to pause on Enter instead of auto-pause
    bool uses_test_functions = false;  // Flag to track if test functions are used

    std::string generate_label(const std::string& prefix);
    void emit(const std::string& instruction);
    void emit_comment(const std::string& comment);
    void emit_syscall(int number);  // Linux only
    void emit_win32_call(const std::string& function);  // Windows only

    void generate_expression(const ExprNode* expr);
    void generate_statement(const StmtNode* stmt);
    void generate_defer_instrumentation();
    void emit_auto_free(const std::string& name);
    bool has_derive(const std::string& lib) const;
    void require_derive(const std::string& lib, const std::string& func) const;

    size_t calculate_stack_size(const FunctionDecl* func);
    void traverse_statement(const StmtNode* stmt, size_t& current_size);
    void define_local_variables(const StmtNode* stmt);

    void generate_builtin_call(const CallExpr* call);
    bool is_auto_alloc_call(const ExprNode* expr);  // Check if expr is alloc() without module
    bool is_decimal_expression(const ExprNode* expr);  // Check if expression evaluates to decimal type

public:
    CodeGenerator(SymbolTable& st, TargetPlatform platform = TargetPlatform::LINUX)
        : symbol_table(st), target_platform(platform) {}

    void set_pause_on_enter(bool value) { pause_on_enter = value; }

    void set_functions(const std::vector<std::unique_ptr<FunctionDecl>>& functions) {
        for (const auto& func : functions) {
            function_map[func->name] = func.get();
        }
    }

    // New methods to handle assembly section collection
    void add_assembly_section(const std::string& section);
    void add_symbol_definition(const std::string& symbol);
    bool is_symbol_defined(const std::string& symbol) const;
    
    std::string generate_program(const std::vector<std::unique_ptr<FunctionDecl>>& functions,
                                 const std::vector<std::unique_ptr<StructDecl>>& structs,
                                 const std::vector<std::string>& derives_in);
    std::string generate_function(const FunctionDecl* func);

    TargetPlatform get_platform() const { return target_platform; }
};

#endif