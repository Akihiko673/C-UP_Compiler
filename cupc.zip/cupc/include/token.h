#ifndef TOKEN_H
#define TOKEN_H

#include <cstdint>
#include <string>

enum class TokenType {
    // Literals
    NUMBER, STRING, IDENTIFIER,
    TRUE, FALSE,
    
    // Types
    INT8, INT16, INT32, INT64, INT128, DEC32, DEC64, DEC128, U8, BOOL, NULL_TYPE, STRUCT, AUTO,
    VAR,
    
    // Operators (binding powers 1-9)
    DOT, LEFT_BRACKET, DOT_STAR, BANG,
    STAR, SLASH, MODULO, PLUS, MINUS, INCREMENT, DECREMENT,
    EQUAL_EQUAL, BANG_EQUAL, LESS, GREATER, LESS_EQUAL, GREATER_EQUAL,
    AMP, CARET, PIPE, AMP_AMP, PIPE_PIPE, EQUAL,
    PLUS_EQUAL, MINUS_EQUAL, STAR_EQUAL, SLASH_EQUAL, MODULO_EQUAL,
    COLON_COLON, QUESTION,
    
    // Delimiters
    COLON, SEMICOLON, COMMA, AT,
    LEFT_PAREN, RIGHT_PAREN, RIGHT_BRACKET,
    LEFT_BRACE, RIGHT_BRACE,
    
    // Keywords
    IF, ELSE, WHILE, FOR, LOOP, MATCH, DEFER, RETURN,
    DERIVE, GET, ASM, TICK, LEN, CATCH, EXTERN, MODULE, IMPORT, CONST,
    NAMESPACE, TEST,

    // Directives
    SAY_ASS_NASM, SAY_LD_GCC, SAY_DBG,

    // Special
    EXCLAMATION, ARROW, DEFAULT,
    
    // Built-in functions (loaded from .cuh)
    ALLOC, FREE, COPY,
    OPEN, CLOSE, READ, WRITE,
    NOW, SLEEP,
    SOCKET, CONNECT, LISTEN, ACCEPT,
    CREATE, DELETE, RENAME,
    MKDIR, RMDIR,
    READ_DIR, GET_SIZE, GET_MTIME, SET_PERMS,
    
    // Constants
    CUP_INT64_MAX, CUP_INT32_MAX,
    
    END_OF_FILE, INVALID
};

enum class Precedence {
    NONE,
    ASSIGNMENT,  // =
    OR,          // ||
    AND,         // &&
    EQUALITY,    // == !=
    COMPARISON,  // < > <= >=
    TERM,        // + -
    FACTOR,      // * /
    UNARY,       // ! - get
    CALL,        // . () [] @
    PRIMARY
};

struct Token {
    TokenType type;
    std::string lexeme;
    int64_t value = 0;      // For NUMBER tokens (integer part)
    double fvalue = 0.0;    // For NUMBER tokens (float/decimal part)
    size_t line;
    size_t column;
    size_t start_pos;
    
    Token(TokenType t, std::string l, size_t ln, size_t col, size_t pos)
        : type(t), lexeme(std::move(l)), line(ln), column(col), start_pos(pos) {
        // Parse numeric value if NUMBER token
        if (type == TokenType::NUMBER) {
            try {
                // Check if it contains a decimal point
                if (lexeme.find('.') != std::string::npos) {
                    fvalue = std::stod(lexeme);
                    value = static_cast<int64_t>(fvalue);
                } else {
                    value = std::stoll(lexeme);
                    fvalue = static_cast<double>(value);
                }
            } catch (...) {
                value = 0;
                fvalue = 0.0;
            }
        }
    }
};

#endif