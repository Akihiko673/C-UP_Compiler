#ifndef PARSER_H
#define PARSER_H

#include "token.h"
#include "ast.h"
#include "symbol_table.h"
#include <vector>
#include <memory>
#include <unordered_map>

#include "error.h"

class Parser {
private:
    const std::vector<Token>& tokens;
    size_t current = 0;
    SymbolTable& symbol_table;
    std::vector<Error> errors;
    std::vector<std::string> derive_libs;
    std::vector<std::string> imports;
    std::string module_name;

    // Toolchain configuration
    struct ToolchainConfig {
        bool use_nasm = false;           // Use NASM assembler
        bool use_gcc_linker = false;     // Use GCC linker
        bool debug_enabled = false;      // Enable debugging
        bool use_default_chain = true;   // Use default cup toolchain
    };
    ToolchainConfig toolchain_config;

    using ParseFn = std::unique_ptr<ExprNode>(Parser::*)();
    struct ParseRule {
        ParseFn prefix;
        ParseFn infix;
        Precedence precedence;
    };

    std::unordered_map<TokenType, ParseRule> rules;

private:
    
    const Token& peek();
    const Token& previous();
    bool is_at_end();
    bool check(TokenType type);
    bool match(TokenType type);
    Token consume(TokenType type, const std::string& message);
    void synchronize();
    
    std::unique_ptr<ExprNode> parse_expression(Precedence prec);
    std::unique_ptr<ExprNode> expression();
    std::unique_ptr<ExprNode> logical_or();
    std::unique_ptr<ExprNode> logical_and();
    std::unique_ptr<ExprNode> bitwise_or();
    std::unique_ptr<ExprNode> bitwise_xor();
    std::unique_ptr<ExprNode> bitwise_and();
    std::unique_ptr<ExprNode> equality();
    std::unique_ptr<ExprNode> comparison();
    std::unique_ptr<ExprNode> term();
    std::unique_ptr<ExprNode> factor();
    std::unique_ptr<ExprNode> unary();
    std::unique_ptr<ExprNode> call();
    std::unique_ptr<ExprNode> primary();
    std::unique_ptr<ExprNode> postfix();
    std::unique_ptr<ExprNode> array_literal();
    std::unique_ptr<ExprNode> length_expression();
    std::unique_ptr<ExprNode> tick_expression();
    std::unique_ptr<ExprNode> error_union();
    
    std::unique_ptr<StmtNode> statement();
    std::unique_ptr<StmtNode> for_statement();
    std::unique_ptr<VarDeclStmt> var_declaration();
    std::unique_ptr<FunctionDecl> extern_declaration();
    void parse_import();
    void parse_derive();
    std::unique_ptr<StmtNode> assignment_or_expression();
    std::unique_ptr<IfStmt> if_statement();
    std::unique_ptr<WhileStmt> while_statement();
    std::unique_ptr<MatchStmt> match_statement();
    std::unique_ptr<DeferStmt> defer_statement();
    std::unique_ptr<ReturnStmt> return_statement();
    std::unique_ptr<BlockStmt> block_statement();
    std::unique_ptr<StmtNode> expression_statement();

    std::shared_ptr<Type> parse_type();
    std::shared_ptr<Type> parse_error_type();

    std::unique_ptr<StructDecl> struct_declaration();
    std::unique_ptr<FunctionDecl> function_declaration();
    std::unique_ptr<FunctionDecl> test_declaration();
    void parse_namespace();

    // Helper method to process statements and collect assembly sections
    void process_statement_for_asm(const StmtNode* stmt);

public:
    Parser(const std::vector<Token>& t, SymbolTable& st);
    std::vector<std::unique_ptr<FunctionDecl>> parse();
    std::vector<std::unique_ptr<StructDecl>>& get_structs() { return structs; }
    const std::vector<std::string>& get_derives() const { return derive_libs; }
    const std::vector<std::string>& get_imports() const { return imports; }
    const std::string& get_module_name() const { return module_name; }
    bool has_start() const { return start_found; }
    const std::vector<Error>& get_errors() const { return errors; }

    // Top-level constants (const declarations)
    const std::vector<std::unique_ptr<VarDeclStmt>>& get_constants() const { return constants; }

    // Public accessors for toolchain configuration
    const ToolchainConfig& get_toolchain_config() const { return toolchain_config; }

    // Assembly sections from imported runtime files
    void add_assembly_section(const std::string& section) { assembly_sections.push_back(section); }
    const std::vector<std::string>& get_assembly_sections() const { return assembly_sections; }
    void collect_assembly_sections_from_ast();

private:
    bool start_found = false;
    std::vector<std::unique_ptr<StructDecl>> structs;
    std::vector<std::unique_ptr<VarDeclStmt>> constants;
    std::vector<std::unique_ptr<FunctionDecl>> functions; // Added to fix missing member
    std::vector<std::string> assembly_sections;  // Track assembly sections from imported files
};

#endif