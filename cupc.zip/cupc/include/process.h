#pragma once

#include <string>
#include <vector>

// Run a program with argv-style args. Returns the exit code of the process (or -1 on error).
int run_process(const std::vector<std::string>& args);
