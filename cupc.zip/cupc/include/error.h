#pragma once

#include <string>
#include "token.h"

struct Error {
    std::string message;
    Token token;
};
