#ifndef LEXER_H
#define LEXER_H

#include "token.h"
#include <string>
#include <vector>
#include <unordered_map>

class Lexer {
private:
    const std::string source;
    size_t current = 0;
    size_t line = 1;
    size_t column = 1;
    size_t start = 0;
    
    static const std::unordered_map<std::string, TokenType> keywords;
    
    char advance();
    char peek() const;
    char peek_next() const;
    bool is_at_end() const;
    bool match(char expected);
    
    Token make_token(TokenType type);
    Token error_token(const std::string& message);
    
    Token number();
    Token string();
    Token identifier();
    
    void skip_whitespace();
    void skip_comment();
    bool skip_block_comment();
    bool unterminated_block_comment = false;
    
public:
    explicit Lexer(std::string src) : source(std::move(src)) {}
    std::vector<Token> tokenize();
};

#endif