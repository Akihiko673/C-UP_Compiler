#ifndef TYPE_H
#define TYPE_H

#include <string>
#include <vector>
#include <memory>

enum class BaseType {
    INT8, INT16, INT32, INT64, INT128, DEC32, DEC64, DEC128, U8, BOOL, NULL_TYPE, ARRAY, STRUCT, ERROR_UNION, AUTO
};

struct Field {
    std::string name;
    std::shared_ptr<struct Type> type;
    size_t offset;
    Field(std::string n, std::shared_ptr<struct Type> t, size_t off)
        : name(std::move(n)), type(std::move(t)), offset(off) {}
};

struct Type {
    BaseType base;
    std::shared_ptr<Type> element_type; // for arrays
    std::shared_ptr<Type> wrapped_type; // for !T
    std::string struct_name;
    std::vector<Field> fields;
    size_t alignment = 1;
    size_t total_size = 0;

    Type(BaseType b) : base(b) {
        total_size = size_for_base(b);
        alignment  = align_for_base(b);
    }
    Type(BaseType b, std::shared_ptr<Type> elem)
        : base(b), element_type(std::move(elem)) {
        if (b == BaseType::ARRAY) {
            total_size = 16; // fat pointer
            alignment  = 8;
        } else if (b == BaseType::ERROR_UNION) {
            // Error unions are 16 bytes: [value: 8 bytes][error_flag: 8 bytes]
            total_size = 16;
            alignment  = 8;
        }
    }

    static size_t size_for_base(BaseType b) {
        switch (b) {
            case BaseType::INT8: return 1;
            case BaseType::INT16: return 2;
            case BaseType::INT32: return 4;
            case BaseType::INT64: return 8;
            case BaseType::INT128: return 16;
            case BaseType::DEC32: return 4;
            case BaseType::DEC64: return 8;
            case BaseType::DEC128: return 16;
            case BaseType::U8:    return 1;
            case BaseType::BOOL:  return 1;
            case BaseType::NULL_TYPE: return 8;
            case BaseType::AUTO: return 8;
            default: return 8;
        }
    }
    static size_t align_for_base(BaseType b) {
        switch (b) {
            case BaseType::INT8: return 1;
            case BaseType::INT16: return 2;
            case BaseType::INT32: return 4;
            case BaseType::INT64: return 8;
            case BaseType::INT128: return 16;
            case BaseType::DEC32: return 4;
            case BaseType::DEC64: return 8;
            case BaseType::DEC128: return 16;
            default: return 1;
        }
    }

    void add_field(const std::string& name, std::shared_ptr<Type> field_type) {
        size_t field_align = field_type->alignment;
        if (fields.empty()) alignment = field_align;
        size_t offset = fields.empty() ? 0 : fields.back().offset + fields.back().type->total_size;
        offset = (offset + field_align - 1) & ~(field_align - 1);
        fields.emplace_back(name, field_type, offset);
        total_size = offset + field_type->total_size;
        total_size = (total_size + alignment - 1) & ~(alignment - 1);
    }

    bool is_array() const { return base == BaseType::ARRAY; }
    bool is_struct() const { return base == BaseType::STRUCT; }
    bool is_error_union() const { return base == BaseType::ERROR_UNION; }
    bool is_fat_pointer() const {
        return is_array() || (base == BaseType::U8 && element_type) || is_struct();
    }

    // For stack allocation, structs keep their actual size
    // But for parameter passing, they're treated as fat pointers (16 bytes = ptr + size)
    size_t size() const { return total_size; }
    
    // Get the fat pointer size for stack allocation
    size_t fat_pointer_size() const {
        if (is_fat_pointer()) return 16;
        return total_size;
    }
    
    // Get the actual size of struct data (not the fat pointer)
    size_t actual_struct_size() const {
        return total_size;
    }
    std::string to_string() const {
        switch (base) {
            case BaseType::INT8: return "int8";
            case BaseType::INT16: return "int16";
            case BaseType::INT32: return "int32";
            case BaseType::INT64: return "int64";
            case BaseType::INT128: return "int128";
            case BaseType::DEC32: return "dec32";
            case BaseType::DEC64: return "dec64";
            case BaseType::DEC128: return "dec128";
            case BaseType::U8: return element_type ? "u8[]" : "u8";
            case BaseType::BOOL: return "bool";
            case BaseType::NULL_TYPE: return "null";
            case BaseType::ARRAY: return element_type ? element_type->to_string() + "[]" : "array";
            case BaseType::STRUCT: return "struct " + struct_name;
            case BaseType::ERROR_UNION: return "!" + (wrapped_type ? wrapped_type->to_string() : "type");
            case BaseType::AUTO: return "auto";
            default: return "unknown";
        }
    }
};

#endif