#ifndef AST_H
#define AST_H

#include <cstdint>
#include "token.h"
#include <memory>
#include <vector>
#include <string>

class ASTNode {
public:
    virtual ~ASTNode() = default;
    virtual std::string to_string() const = 0;
};

// Expressions
class ExprNode : public ASTNode {};

class NumberExpr : public ExprNode {
public:
    int64_t value = 0;
    double fvalue = 0.0;
    bool is_float = false;
    
    explicit NumberExpr(int64_t v) : value(v), fvalue(static_cast<double>(v)), is_float(false) {}
    explicit NumberExpr(double v) : value(static_cast<int64_t>(v)), fvalue(v), is_float(true) {}
    
    // Conversion constructor from int to avoid ambiguity
    NumberExpr(int v) : value(static_cast<int64_t>(v)), fvalue(static_cast<double>(v)), is_float(false) {}
    
    std::string to_string() const override {
        if (is_float) {
            return "Number(" + std::to_string(fvalue) + ")";
        }
        return "Number(" + std::to_string(value) + ")";
    }
};

class StringExpr : public ExprNode {
public:
    std::string value;
    explicit StringExpr(std::string v) : value(std::move(v)) {}
    std::string to_string() const override {
        return "String(\"" + value + "\")";
    }
};

class IdentifierExpr : public ExprNode {
public:
    std::string name;
    explicit IdentifierExpr(std::string n) : name(std::move(n)) {}
    std::string to_string() const override { return "Id(" + name + ")"; }
};

class BinaryExpr : public ExprNode {
public:
    TokenType op;
    std::unique_ptr<ExprNode> left, right;
    BinaryExpr(TokenType o,
               std::unique_ptr<ExprNode> l,
               std::unique_ptr<ExprNode> r)
        : op(o), left(std::move(l)), right(std::move(r)) {}
    std::string to_string() const override { return "Binary"; }
};

class UnaryExpr : public ExprNode {
public:
    TokenType op;
    std::unique_ptr<ExprNode> operand;
    UnaryExpr(TokenType o, std::unique_ptr<ExprNode> e)
        : op(o), operand(std::move(e)) {}
    std::string to_string() const override { return "Unary"; }
};

class IncrementExpr : public ExprNode {
public:
    TokenType op;  // INCREMENT or DECREMENT
    std::unique_ptr<ExprNode> operand;  // Must be an lvalue (identifier, index, or field)
    IncrementExpr(TokenType o, std::unique_ptr<ExprNode> e)
        : op(o), operand(std::move(e)) {}
    std::string to_string() const override { return "Increment"; }
};

class IndexExpr : public ExprNode {
public:
    std::unique_ptr<ExprNode> array, index;
    IndexExpr(std::unique_ptr<ExprNode> a,
              std::unique_ptr<ExprNode> i)
        : array(std::move(a)), index(std::move(i)) {}
    std::string to_string() const override { return "Index"; }
};

class GetExpr : public ExprNode {
public:
    std::unique_ptr<ExprNode> target;
    explicit GetExpr(std::unique_ptr<ExprNode> t) : target(std::move(t)) {}
    std::string to_string() const override { return "Get"; }
};

class DerefExpr : public ExprNode {
public:
    std::unique_ptr<ExprNode> pointer;
    explicit DerefExpr(std::unique_ptr<ExprNode> p) : pointer(std::move(p)) {}
    std::string to_string() const override { return "Deref"; }
};

class FieldAccessExpr : public ExprNode {
public:
    std::unique_ptr<ExprNode> object;
    std::string field_name;
    FieldAccessExpr(std::unique_ptr<ExprNode> o, std::string f)
        : object(std::move(o)), field_name(std::move(f)) {}
    std::string to_string() const override { return "FieldAccess"; }
};

class LengthExpr : public ExprNode {
public:
    std::unique_ptr<ExprNode> array;
    explicit LengthExpr(std::unique_ptr<ExprNode> a) : array(std::move(a)) {}
    std::string to_string() const override { return "Length"; }
};

class TickExpr : public ExprNode {
public:
    std::string to_string() const override { return "Tick"; }
};

class ArrayLiteralExpr : public ExprNode {
public:
    std::vector<std::unique_ptr<ExprNode>> elements;
    explicit ArrayLiteralExpr(std::vector<std::unique_ptr<ExprNode>> v)
        : elements(std::move(v)) {}
    std::string to_string() const override { return "ArrayLiteral"; }
};

class StructLiteralExpr : public ExprNode {
public:
    std::vector<std::pair<std::string, std::unique_ptr<ExprNode>>> fields;
    explicit StructLiteralExpr(std::vector<std::pair<std::string, std::unique_ptr<ExprNode>>> f)
        : fields(std::move(f)) {}
    std::string to_string() const override { return "StructLiteral"; }
};

class CallExpr : public ExprNode {
public:
    std::string module;      // For module.function calls (e.g., "sys" in sys.alloc)
    std::string function;
    std::vector<std::unique_ptr<ExprNode>> arguments;
    CallExpr(std::string f, std::vector<std::unique_ptr<ExprNode>> args)
        : module(""), function(std::move(f)), arguments(std::move(args)) {}
    CallExpr(std::string m, std::string f, std::vector<std::unique_ptr<ExprNode>> args)
        : module(std::move(m)), function(std::move(f)), arguments(std::move(args)) {}
    std::string to_string() const override { return "Call"; }
};

class ErrorPropagationExpr : public ExprNode {
public:
    std::unique_ptr<ExprNode> operand;
    explicit ErrorPropagationExpr(std::unique_ptr<ExprNode> op)
        : operand(std::move(op)) {}
    std::string to_string() const override { return "ErrorPropagation"; }
};

// Statements
class StmtNode : public ASTNode {};

class VarDeclStmt : public StmtNode {
public:
    std::shared_ptr<struct Type> type;
    std::string name;
    std::unique_ptr<ExprNode> initializer;
    bool is_auto = false;
    bool is_const = false;
    bool needs_cleanup = false;
    size_t stack_offset = 0;

    VarDeclStmt(std::shared_ptr<struct Type> t,
                std::string n,
                std::unique_ptr<ExprNode> init)
        : type(std::move(t)), name(std::move(n)), initializer(std::move(init)) {}

    std::string to_string() const override { return "VarDecl " + name; }
};

class AssignStmt : public StmtNode {
public:
    std::unique_ptr<ExprNode> left, right;
    AssignStmt(std::unique_ptr<ExprNode> l, std::unique_ptr<ExprNode> r)
        : left(std::move(l)), right(std::move(r)) {}
    std::string to_string() const override { return "Assign"; }
};

class IfStmt : public StmtNode {
public:
    std::unique_ptr<ExprNode> condition;
    std::vector<std::unique_ptr<StmtNode>> then_block, else_block;
    IfStmt(std::unique_ptr<ExprNode> c,
           std::vector<std::unique_ptr<StmtNode>> t,
           std::vector<std::unique_ptr<StmtNode>> e = {})
        : condition(std::move(c)), then_block(std::move(t)), else_block(std::move(e)) {}
    std::string to_string() const override { return "If"; }
};

class WhileStmt : public StmtNode {
public:
    std::unique_ptr<ExprNode> condition;
    std::vector<std::unique_ptr<StmtNode>> body;
    WhileStmt(std::unique_ptr<ExprNode> c, std::vector<std::unique_ptr<StmtNode>> b)
        : condition(std::move(c)), body(std::move(b)) {}
    std::string to_string() const override { return "While"; }
};

class MatchCase {
public:
    std::unique_ptr<ExprNode> pattern;
    std::vector<std::unique_ptr<StmtNode>> body;
    MatchCase(std::unique_ptr<ExprNode> p, std::vector<std::unique_ptr<StmtNode>> b)
        : pattern(std::move(p)), body(std::move(b)) {}
};

class MatchStmt : public StmtNode {
public:
    std::unique_ptr<ExprNode> value;
    std::vector<MatchCase> cases;
    std::vector<std::unique_ptr<StmtNode>> default_case;
    MatchStmt(std::unique_ptr<ExprNode> v,
              std::vector<MatchCase> c,
              std::vector<std::unique_ptr<StmtNode>> d)
        : value(std::move(v)), cases(std::move(c)), default_case(std::move(d)) {}
    std::string to_string() const override { return "Match"; }
};

class DeferStmt : public StmtNode {
public:
    std::unique_ptr<StmtNode> statement;
    explicit DeferStmt(std::unique_ptr<StmtNode> s) : statement(std::move(s)) {}
    std::string to_string() const override { return "Defer"; }
};

class ReturnStmt : public StmtNode {
public:
    std::unique_ptr<ExprNode> value;
    explicit ReturnStmt(std::unique_ptr<ExprNode> v) : value(std::move(v)) {}
    std::string to_string() const override { return "Return"; }
};

class BlockStmt : public StmtNode {
public:
    std::vector<std::unique_ptr<StmtNode>> statements;
    explicit BlockStmt(std::vector<std::unique_ptr<StmtNode>> s)
        : statements(std::move(s)) {}
    std::string to_string() const override { return "Block"; }
};

class AsmStmt : public StmtNode {
public:
    std::string code;
    explicit AsmStmt(std::string c) : code(std::move(c)) {}
    std::string to_string() const override { return "Asm"; }
};

// Standalone expression used as a statement (e.g. function call result discarded).
class ExprStmt : public StmtNode {
public:
    std::unique_ptr<ExprNode> expr;
    explicit ExprStmt(std::unique_ptr<ExprNode> e) : expr(std::move(e)) {}
    std::string to_string() const override { return "ExprStmt"; }
};

// Top-level
class FunctionDecl {
public:
    bool is_extern = false;
    bool is_method = false;
    std::string struct_name;
    std::shared_ptr<struct Type> return_type;
    std::string name;
    std::vector<std::pair<std::shared_ptr<struct Type>, std::string>> params;
    std::vector<std::unique_ptr<StmtNode>> body;
    size_t stack_size = 0;

    FunctionDecl(bool is_ext,
                 bool is_meth,
                 std::string sname,
                 std::shared_ptr<struct Type> ret,
                 std::string n,
                 std::vector<std::pair<std::shared_ptr<struct Type>, std::string>> p,
                 std::vector<std::unique_ptr<StmtNode>> b)
        : is_extern(is_ext), is_method(is_meth), struct_name(std::move(sname)),
          return_type(std::move(ret)), name(std::move(n)),
          params(std::move(p)), body(std::move(b)) {}

    std::string to_string() const { return "Function " + name; }
};

class StructDecl : public ASTNode {
public:
    std::string name;
    std::shared_ptr<struct Type> type;
    std::vector<std::unique_ptr<VarDeclStmt>> fields;

    StructDecl(std::string n,
               std::shared_ptr<struct Type> t,
               std::vector<std::unique_ptr<VarDeclStmt>> f)
        : name(std::move(n)), type(std::move(t)), fields(std::move(f)) {}

    std::string to_string() const override { return "Struct " + name; }
};

class NamespaceDecl : public ASTNode {
public:
    std::string name;
    std::vector<std::unique_ptr<FunctionDecl>> functions;
    std::vector<std::unique_ptr<StructDecl>> structs;
    std::vector<std::unique_ptr<VarDeclStmt>> constants;
    std::vector<std::unique_ptr<NamespaceDecl>> nested_namespaces;

    NamespaceDecl(std::string n,
                  std::vector<std::unique_ptr<FunctionDecl>> funcs,
                  std::vector<std::unique_ptr<StructDecl>> structs,
                  std::vector<std::unique_ptr<VarDeclStmt>> consts,
                  std::vector<std::unique_ptr<NamespaceDecl>> nested)
        : name(std::move(n)), functions(std::move(funcs)), structs(std::move(structs)),
          constants(std::move(consts)), nested_namespaces(std::move(nested)) {}

    std::string to_string() const override { return "Namespace " + name; }
};

#endif