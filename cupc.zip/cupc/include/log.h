// log.h - lightweight logging helpers
#pragma once
#include <iostream>

inline std::ostream& log_error() {
    return std::cerr;
}

inline std::ostream& log_info() {
    return std::cout;
}
