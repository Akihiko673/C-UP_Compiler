// assembler.h - Main assembler header for C-UP
#pragma once

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <cstdint>

// x86-64 instruction operand
struct Operand {
    enum class Type {
        NONE,
        REGISTER,       // rax, rbx, etc.
        IMMEDIATE,      // 0x1234, 1000
        MEMORY,         // [rax], [rbp - 8], [rel label]
        LABEL           // _loop, _end, printf
    } type = Type::NONE;
    
    std::string reg_name;           // For register operand
    int64_t immediate_value = 0;    // For immediate operand
    
    // For memory operand
    std::string base_reg;           // rax, rbp, etc.
    std::string index_reg;          // rbx, rcx, etc. (for scaled addressing)
    int scale = 0;                  // 1, 2, 4, 8
    int64_t displacement = 0;       // offset
    bool rip_relative = false;      // [rel label]
    std::string label;              // For [rel label]
    
    // For label operand
    std::string label_name;
};

// x86-64 instruction
struct Instruction {
    std::string mnemonic;           // mov, add, jmp, etc.
    std::vector<Operand> operands;
    std::string raw_line;           // Original source line
    int line_number = 0;
};

// Symbol in symbol table
struct Symbol {
    std::string name;
    uint64_t offset = 0;            // Offset in section
    uint64_t size = 0;
    bool is_external = false;       // External (undefined) symbol
    bool is_defined = false;        // Symbol has been defined
    int section_index = -1;         // Which section contains this symbol (-1 = external)
    uint8_t storage_class = 0;      // COFF storage class
    uint8_t num_aux_symbols = 0;    // Number of auxiliary symbols
};

// Relocation entry
struct Relocation {
    enum class Type {
        NONE,
        ABS64,          // 64-bit absolute
        REL32,          // 32-bit relative (RIP-relative)
        ABS32           // 32-bit absolute
    } type = Type::NONE;
    
    uint64_t offset = 0;            // Offset in section
    std::string symbol_name;
    int64_t addend = 0;
};

// Section (code, data, etc.)
struct Section {
    std::string name;
    std::vector<uint8_t> data;
    std::vector<Symbol> symbols;
    std::vector<Relocation> relocations;
    uint32_t flags = 0;
};

// Object file
struct ObjectFile {
    std::vector<Section> sections;
    std::map<std::string, Symbol> global_symbols;
    std::map<std::string, Symbol> external_symbols;
    std::string format;             // "elf64" or "coff"
};

// Assembler class
class Assembler {
public:
    Assembler(const std::string& platform = "linux");
    
    // Parse assembly file
    bool parse_file(const std::string& filename);
    
    // Assemble to object file
    ObjectFile assemble();
    
    // Write object file
    bool write_object(const std::string& filename, const ObjectFile& obj);
    
private:
    std::string target_platform;    // "linux" or "windows"
    std::vector<std::string> source_lines;
    std::vector<Instruction> instructions;
    std::map<std::string, Symbol> symbol_table;    // All symbols
    std::vector<Symbol> defined_symbols;           // Symbols in order
    std::vector<Symbol> external_symbols;          // External references
    int current_section = 0;
    uint64_t current_offset = 0;
    
    // Parsing
    bool parse_line(const std::string& line, int line_num);
    bool parse_instruction(const std::string& line, Instruction& instr);
    std::vector<Operand> parse_operands(const std::string& operand_str);
    Operand parse_operand(const std::string& operand_str);
    bool parse_directive(const std::string& line);
    
    // Symbol management
    void define_symbol(const std::string& name, uint64_t offset, int section);
    void reference_external(const std::string& name);
    Symbol* resolve_symbol(const std::string& name);
    
    // Assembly
    std::vector<uint8_t> assemble_instruction(const Instruction& instr, 
                                               uint64_t offset,
                                               std::vector<Relocation>& relocs);
    
    // Object file generation
    ObjectFile generate_elf();
    ObjectFile generate_coff();
    
    // ELF helpers
    void write_elf_file(const std::string& filename, const ObjectFile& obj);
    
    // COFF helpers
    void write_coff_file(const std::string& filename, const ObjectFile& obj);
};

// Forward declaration for encoder access to symbol table
class Assembler;

// Instruction encoder for x86-64
class InstructionEncoder {
public:
    static std::vector<uint8_t> encode(const Instruction& instr,
                                       uint64_t offset,
                                       std::vector<Relocation>& relocs,
                                       Assembler* assembler = nullptr);
    
private:
    static std::vector<uint8_t> encode_mov(const std::vector<Operand>& ops,
                                          uint64_t offset);
    static std::vector<uint8_t> encode_add(const std::vector<Operand>& ops);
    static std::vector<uint8_t> encode_sub(const std::vector<Operand>& ops);
    static std::vector<uint8_t> encode_imul(const std::vector<Operand>& ops);
    static std::vector<uint8_t> encode_jmp(const std::vector<Operand>& ops,
                                          uint64_t offset,
                                          std::vector<Relocation>& relocs,
                                          Assembler* assembler);
    static std::vector<uint8_t> encode_call(const std::vector<Operand>& ops,
                                           uint64_t offset,
                                           std::vector<Relocation>& relocs,
                                           Assembler* assembler);
    // System-level instruction encoders
    static std::vector<uint8_t> encode_lgdt(const std::vector<Operand>& ops);
    static std::vector<uint8_t> encode_sgdt(const std::vector<Operand>& ops);
    static std::vector<uint8_t> encode_lidt(const std::vector<Operand>& ops);
    static std::vector<uint8_t> encode_sidt(const std::vector<Operand>& ops);
    static std::vector<uint8_t> encode_ltr(const std::vector<Operand>& ops);
    static std::vector<uint8_t> encode_str(const std::vector<Operand>& ops);
    static std::vector<uint8_t> encode_invlpg(const std::vector<Operand>& ops);
    static std::vector<uint8_t> encode_invpcid(const std::vector<Operand>& ops);
};
