# C-UP Compiler Assembly Section Collection Issue

## Problem Description
The C-UP compiler has an issue where inline assembly sections from imported runtime files (like bridges.cup) are not being properly collected and included in the final assembly output. When using `#derive <io>`, the compiler imports runtime files that reference symbols like `cup_alloc`, `cup_free`, etc., but the inline assembly that defines these symbols is not included in the final .asm file, causing undefined symbol errors during assembly.

## Affected Files
- src/codegen.cpp - Main code generation logic
- src/parser.cpp - Parsing and import handling
- src/main.cpp - Runtime file importing logic
- lib/cup/runtime/bridges.cup - Contains inline assembly for C runtime bridges
- lib/cup/runtime/io.cup - Uses functions that depend on bridges
- lib/cup/runtime/memory.cup - Uses functions that depend on bridges

## Root Cause
The code generator does not collect and merge inline assembly sections from imported runtime files into the final assembly output. When runtime files are imported via `#derive` directives, their inline assembly sections are not aggregated.

## Required Changes

### 1. CodeGenerator Class Modifications (src/codegen.cpp)
- Add collection for assembly sections from imported files
- Modify generate_program to collect assembly sections from all imported runtime files
- Add method to merge assembly sections into final output
- Track symbol dependencies to collect only needed assembly sections

### 2. Parser Class Modifications (src/parser.cpp)
- Track inline assembly sections during parsing of imported files
- Maintain collection of assembly sections from imported runtime files
- Pass assembly section information to code generator

### 3. Main Build Logic Modifications (src/main.cpp)
- Ensure all imported runtime files are properly processed
- Pass assembly section information to parser and code generator

### 4. Symbol Resolution Enhancements
- Track which symbols are referenced by imported runtime files
- Identify which assembly sections are needed to satisfy dependencies
- Only collect the required assembly sections

## Implementation Plan

### Phase 1: Data Structure Changes
- Add assembly_sections member to CodeGenerator class
- Add methods to collect assembly sections from imported files
- Modify AST to track inline assembly sections

### Phase 2: Parser Integration
- Modify parser to collect inline assembly during import processing
- Track assembly section dependencies

### Phase 3: Code Generation Integration
- Modify generate_program to include collected assembly sections
- Ensure proper placement of assembly sections in final output
- Handle platform-specific assembly differences

### Phase 4: Dependency Tracking
- Implement symbol dependency tracking
- Only collect assembly sections for symbols that are actually used
- Optimize to include only needed assembly sections

## Expected Outcome
After these changes, when using `#derive <io>`, the compiler will:
1. Import io.cup and associated runtime files
2. Identify inline assembly sections needed for symbols like cup_alloc, cup_free
3. Collect only the required assembly sections
4. Include them in the final assembly output
5. Successfully assemble without undefined symbol errors

## Testing Strategy
- Test basic I/O operations with #derive <io>
- Test memory operations with #derive <memory>
- Test file operations with #derive <file>
- Verify that only needed assembly sections are included
- Ensure no symbol definition errors occur during assembly