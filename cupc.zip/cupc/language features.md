# C-UP Language Reference

This document is the authoritative language reference for C-UP, the small systems-oriented language
used by this compiler. It documents currently implemented features, details about semantics and
ABI, examples (including longer, worked examples), and a clear list of unimplemented/planned items.

Goals for this document:
*   `#derive <lib>`: Enables standard library features (gates built-in functions).
- Explain precise semantics used by the compiler and runtime.
- Mark which features are implemented now and which are TODO.

Contents
- Quickstart and minimal examples
- Lexical grammar
- Type system (primitive, composite, error unions)
- Variables, `var` (type inference) and `auto` (automatic cleanup)
- Structs and struct literals
- Memory safety model and resource cleanup
- Functions, calling conventions, and ABIs
- Control flow and defer semantics
- Decimal/floating-point behavior and caveats
- Standard library and runtime bridges
- Unimplemented features and roadmap

Quickstart (one-file program)
-----------------------------

Here is a small complete C-UP program demonstrating basic syntax and features:


```cup
module quickstart;

#derive <io>

struct: Point {
	int64: x;
	int64: y;
}

int64: start() {
	var: p = { x: 10, y: 20 };    // struct literal (type inferred)
	say("Point: (%d, %d)\n", p.x, p.y);

	auto u8[]: buf = alloc(16);   // auto cleans up at scope exit
	// use buf -- runtime `alloc` returns fat pointer in (rax, rdx)
	return 0;
}
```

How to build & run
- Use the `cup` build manager: `cup build myprog.cup myprog` (on Windows add .exe) — the build manager compiles and links runtime helpers.

Lexical structure
-----------------
- Identifiers: `[A-Za-z_][A-Za-z0-9_]*`
- Comments: `// line` and `/* block */` (non-nested)
- Literals:
  - Integer literal: `123`
  - Decimal (floating) literal: `12.34` (parsed as `dec64` by default)
  - String: double-quoted with C-style escapes: `"hello\n"`
  - Boolean: `true`, `false`
  - Null: `null`

Keywords (not exhaustive; see `include/token.h` for canonical list):
`if else while for loop match return defer struct module import #derive extern const auto var asm get len true false null`

Type system
-----------

Primitive types
- `int64` (8 bytes) — default for integer literals
- `int32` (4 bytes)
- `dec64` (8 bytes) — IEEE-754 double precision
- `dec32` (4 bytes) — IEEE-754 single precision
- `u8` (1 byte) — byte/unsigned char
- `bool` (1 byte)
- `null` — null pointer type (represented as pointer-sized zero)

Composite types
- Arrays / Fat pointers: `T[]` — runtime layout is a fat pointer: 8-byte pointer, 8-byte length (total 16 bytes).
  - Example: `u8[]` (string-like), `int64[]`.
- Structs: declared via `struct: Name { ... }` and can be used by name. Struct storage is inline on the stack (size = sum of fields with alignment).
  - Passing rule: structs with size <= 8 bytes are passed in registers by value; larger structs are passed by address (pointer) and copied into stack frame or destination as needed.
- Error unions: `!T` — a value of type `T` plus an error flag. Layout: 16 bytes = [value:8][error_flag:8].

Type inference and `auto` vs `var`
---------------------------------
- `var` is the type-inference keyword (use when you want the compiler to infer the variable's type from its initializer):
  - `var: x = 10;` infers `int64`
- `auto` is a storage/cleanup modifier that indicates automatic cleanup at scope exit. Use it like:
  - `auto u8[]: buf = alloc(1024);`
  - `auto` is not the type placeholder — `var` is.

Memory safety and resource cleanup
---------------------------------

C-UP aims to provide predictable resource cleanup while remaining systems-focused. The current model implemented in the compiler is:

- Stack safety: local variables are laid out on the stack with per-function calculated stack frames. Bounds checking is emitted for array indexing operations; out-of-bounds access calls a panic handler.
- Automatic cleanup: when a variable is declared with the `auto` storage modifier and its type requires cleanup (currently fat pointers returned by `alloc`), the compiler emits cleanup calls at scope exit in LIFO order. Cleanup uses runtime helpers (e.g., `cup_free` or `VirtualFree`/`munmap`).
- `defer`: `defer` statements are scoped: a `defer` declared within a block is executed when the block exits (LIFO). This prevents defers from running if the block was not entered.

Limitations and safety guarantees (current implementation)
- The language is not yet memory-safe in the sense of preventing all use-after-free or aliasing problems — the compiler emits automatic frees but does not perform borrow checking or ownership transfer.
- The runtime enforces bounds checks for array access; this helps prevent simple buffer overruns.
- Unchecked raw pointers and manual `asm` can still produce unsafe behavior — the programmer is responsible for correctness when using low-level features.

Structs and struct literals
---------------------------

Declaring structs:

```cup
struct: Point {
	int64: x;
	int64: y;
}
```

Struct literals (implemented):
- Syntax: `{ field1: expr1, field2: expr2, ... }`
- When used as the initializer for a variable with a struct type, each field expression is evaluated and stored into the struct's stack storage at its field offset.

Example — struct literals and initialization:

```cup
struct: Rect {
	Point: a;
	Point: b;
}

int64: start() {
	var: r = { a: { x: 0, y: 0 }, b: { x: 100, y: 50 } };
	say("Rect a: (%d,%d) b: (%d,%d)\n", r.a.x, r.a.y, r.b.x, r.b.y);
	return 0;
}
```

Notes:
- Field order must match names; missing fields are an error.
- Nested struct literals are supported.

Functions, calling convention, and ABI
-------------------------------------

- On Linux the compiler targets System V AMD64 ABI (RDI, RSI, RDX, RCX, R8, R9 for integer/pointer args). On Windows it targets Microsoft x64 (RCX, RDX, R8, R9 and 32-byte shadow space).
- Fat pointers (arrays/strings) are passed as two arguments (pointer, length) or as a fat pointer in the stack layout as appropriate.
- Error unions are returned in `(rax, rdx)` where `rax` holds the value and `rdx` the error flag.

Example — function and method declaration

```cup
int64: add(int64: a, int64: b) {
	return a + b;
}

// method-like (on struct) example
struct: S { int64: x; }
int64: S:add(int64: v) {
	return this.x + v;
}
```

Defer semantics and examples
---------------------------

- `defer stmt;` registers `stmt` to run when the current block or function exits. Defers execute in LIFO order.
- Because defers are block-scoped, a `defer` inside an `if` will only run if that `if` block is entered.

Example:

```cup
int64: start() {
	{
		auto u8[]: buf = alloc(64);
		defer free(buf);    // frees buf when this block exits
		// use buf
	}
	// buf is freed by the defer above
	return 0;
}
```

Decimal / floating-point behavior
---------------------------------

- Decimal literals (e.g., `1.23`) are parsed as `dec64` by default.
- Arithmetic on decimals uses SSE (`movsd`, `addsd`, `mulsd`, `divsd`) and comparisons use `ucomisd`.
- The compiler emits calls to `fmod` for the `%` operator when applied to decimal operands. The build/link step must link the math library (`-lm`) on POSIX platforms or the appropriate CRT math on Windows.

Caveats and edge cases:
- NaN and signed zeros follow IEEE-754 rules; equality and ordering may behave accordingly.
- For complex math operations (trig, sqrt) the runtime bridges in `lib/cup/runtime/math.cup` forward to system math functions.

Standard library and runtime bridges
----------------------------------

Many standard operations are provided by runtime modules under `lib/cup/runtime/` rather than being hardcoded into the compiler. Examples:
- `memory.cup` — `cup_alloc`, `cup_free`, `cup_copy`
- `file.cup` — file helpers (open/read/write)
- `sys.cup`, `bridges.cup` — platform bridges (GetStdHandle, ReadFile, etc.)
- `math.cup` — wrappers to `sqrt`, `fmod`, etc.

Your program can call these functions (often gated by `#derive` directives to opt into the runtime). The code generator emits `extern` declarations for required runtime helpers.

Unimplemented features & roadmap
--------------------------------

The following features are planned but not fully implemented yet (status notes where applicable):

- `?` error-propagation operator for error unions (TODO) — currently you must handle error unions manually.
- Full borrow-checker / ownership model for comprehensive memory safety (TODO) — current `auto` cleanup is helpful but not a complete safety model.
- Generics (parametric polymorphism) (TODO)
- Pattern matching exhaustiveness checks (partial)
- Two-pass assembler with exact instruction sizing (TODO, high priority for correctness)
- Incremental build caching (implemented in `cup` as timestamp-based; improve to content-hash based cache) — basic timestamp support implemented.

Portability and platform notes
-----------------------------

- The compiler emits x86-64 assembly and supports both Linux (System V) and Windows (Microsoft x64) calling conventions. Conditional inline assembly and runtime bridges in `lib/cup/runtime/` implement platform-specific behavior.
- If you use decimal `%`, make sure `-lm` (or equivalent) is linked — the build manager can be updated to pass `-lm` on link.

Long example — simple JSON-like serializer using structs and arrays
------------------------------------------------------------------

This longer example demonstrates structs, arrays, memory allocation, and `auto` cleanup. It is illustrative and slightly simplified for clarity.

```cup
#derive <io>
#derive <memory>

struct: Person {
	u8[]: name;   // fat pointer (ptr,len)
	int64: age;
}

int64: start() {
	// Allocate a buffer for the name
	auto u8[]: name = alloc(32);
	// Fill the name with a tiny helper (pretend write)
	// ... (omitted) ...

	var: p = { name: name, age: 42 };

	// Serialize
	say("{ \"name\": \"%s\", \"age\": %d }\n", p.name, p.age);

	// `name` will be automatically freed when it goes out of scope thanks to `auto`
	return 0;
}
```

Developer notes & where to look in the source
--------------------------------------------

- Parser: `src/parser.cpp` — parsing rules and AST construction.
- AST definitions: `include/ast.h` — new nodes include `StructLiteralExpr` for struct literals.
- Code generator: `src/codegen.cpp` — emits assembly, implements decimal ops and struct initialization.
- Symbol table & types: `include/symbol_table.h`, `include/type.h` — type layout, field offsets, and stack accounting.
- Runtime: `lib/cup/runtime/` — platform-specific helpers moved into the runtime folder.
- Build manager: `src/build_manager.cpp` — now implements a timestamp-based incremental build skip.

Contributing and extending the language
--------------------------------------

- To add a new runtime feature (for example a new library function), add the helper to `lib/cup/runtime/` and, if needed, add an `extern` declaration in `codegen.cpp` or call it from user code.
- For language changes: update `include/token.h` for new keywords, update `src/lexer.cpp` for tokenization, add parser rules in `src/parser.cpp`, update AST (`include/ast.h`) and adjust codegen (`src/codegen.cpp`).

Final notes on memory safety
---------------------------

C-UP currently provides helpful runtime checks and automatic cleanup for common patterns:
- Bounds checks for array access.
- Automatic cleanup for `auto` variables for fat-pointer-like resources.

However, full memory safety (preventing use-after-free, enforcing aliasing/borrowing semantics, etc.) is not yet implemented. The planned path forward is:
1. Define an ownership/borrowing model and represent ownership in the type system (future type qualifiers).
2. Implement compile-time checks analogous to a borrow checker.
3. Expand runtime checks and safe wrappers around unsafe features.

If you want, I can now:
- Add a short section showing how to use `alloc`/`free` and the runtime helpers with examples, and wire the build to link `-lm` for decimal `%`.
- Implement the `?` operator parsing and a simple codegen prototype.

End of reference.

--- /dev/null
+++ c/cupc/language.md
@@ -0,0 +1,162 @@
+# C-UP Language Reference
+
+This document describes the syntax, semantics, and rules of the C-UP language as currently implemented in the compiler.
+
+## 1. Lexical Structure
+
+*   **Comments**:
+    *   Single line: `// ...`
+    *   Block: `/* ... */` (non-nesting)
+*   **Identifiers**: `[A-Za-z_][A-Za-z0-9_]*`
+*   **Literals**:
+    *   **Integers**: Decimal digits (e.g., `123`).
+    *   **Floats**: Decimal with dot (e.g., `12.34`).
+    *   **Strings**: Double-quoted `"..."`. Supports escapes `\n`, `\t`, `\r`, `\0`, `\"`, `\\`.
+    *   **Booleans**: `true`, `false`.
+    *   **Null**: `null`.
+*   **Keywords**: `if`, `else`, `while`, `for`, `loop`, `match`, `return`, `defer`, `struct`, `module`, `import`, `derive`, `extern`, `const`, `auto`, `asm`, `get`.
+
+## 2. Type System
+
+### Primitive Types
+| Type    | Size    | Description                                           |
+|---------------------------------------------------------------------------|
+| `int64` | 8 bytes | Signed 64-bit integer (default for integer literals). |
+| `int32` | 4 bytes | Signed 32-bit integer.                                |
+| `dec64` | 8 bytes | IEEE-754 double-precision floating point.             |
+| `dec32` | 4 bytes | IEEE-754 single-precision floating point.             |
+| `u8`    | 1 byte  | Unsigned 8-bit byte (used for strings/buffers).       |
+| `bool`  | 1 byte  | Boolean (0 or 1).                                     |
+| `null`  | 0 bytes | Null pointer type.                                    |
+
+### Composite Types
+*   **Arrays / Fat Pointers (`T[]`)**:
+    *   Runtime layout: `[pointer (8 bytes), length (8 bytes)]`.
+    *   Passed in registers (Linux: `rax`/`rdx`, Windows: stack/registers).
+*   **Structs**:
+    *   User-defined aggregate types.
+    *   Passed by value if size <= 8 bytes, otherwise passed by reference (address).
+*   **Error Unions (`!T`)**:
+    *   Represents a value of type `T` OR an error.
+    *   Runtime layout: `[value (8 bytes), error_flag (8 bytes)]`.
+
### Type Inference
*   **`var`**: Used as a type placeholder. The compiler infers the type from the initializer.
	*   `var: x = 10;` (Infers `int64`)
*   **`auto` (cleanup modifier)**: When used before a type, `auto` indicates automatic cleanup of the variable at scope exit (e.g., `auto u8[]: buf = alloc(10);`). `auto` is a storage modifier, not the type placeholder.
+
+## 3. Declarations
+
### Variables
Syntax: `[const | auto] <Type|var>: <name> = <expression>;`

*   **Standard**: `int64: x = 10;`
*   **Constant**: `const int64: PI = 3;` (Compile-time constant).
*   **Auto-Cleanup**: `auto u8[]: buf = alloc(10);`
	*   The `auto` *modifier* registers the variable for automatic cleanup (freeing memory) at scope exit.
+
+### Functions
+Syntax: `<ReturnType>: <name>(<Type>: <arg>, ...) { <body> }`
+
+```cup
+int64: add(int64: a, int64: b) {
+    return a + b;
+}
+```
+
+*   **Entry Point**: `int64: start()`.
+
+### Structs
+Syntax: `struct: <Name> { <Type>: <field>; ... }`
+
+```cup
+struct: Point {
+    int64: x;
+    int64: y;
+}
+```
+
+### Modules
+*   `module <Name>;`: Declares module name.
+*   `import "filename.cup";`: Imports source file.
*   `#derive <lib>`: Enables standard library features (gates built-in functions).
+
+## 4. Statements & Control Flow
+
+*   **If**: `if (cond) { ... } else { ... }`
+*   **While**: `while (cond) { ... }`
+*   **For**: `for (init; cond; inc) { ... }`
+*   **Loop**: `loop { ... }` (Infinite loop).
+*   **Match**:
+    ```cup
+    match (x) {
+        0 => stmt,
+        default => stmt
+    }
+    ```
+*   **Defer**: `defer stmt;` (Executes `stmt` at function exit, LIFO order).
+*   **Return**: `return expr;` or `return;`.
+*   **Inline Assembly**:
+    ```cup
+    asm {
+        mov rax, 1
+    }
+    ```
+
+## 5. Expressions
+
+*   **Arithmetic**: `+`, `-`, `*`, `/`, `%`.
+*   **Bitwise**: `&`, `|`, `^`, `<<` (via `shl`), `>>` (via `shr`).
+*   **Logical**: `&&`, `||`, `!`.
+*   **Comparison**: `==`, `!=`, `<`, `>`, `<=`, `>=`.
+*   **Access**:
+    *   Index: `arr[i]` (Bounds checked).
+    *   Field: `obj.field`.
+    *   Length: `len(arr)`.
+*   **Assignment**: `=`, `+=`, `-=`, etc.
+
+## 6. Built-in Functions (Intrinsics)
+
+These are currently hardcoded in the compiler (`codegen.cpp`) and require specific `derive` directives.
These were historically hardcoded in the compiler (`codegen.cpp`) but many have been migrated to runtime implementations under `lib/cup/runtime/`. The compiler now emits calls to runtime helpers for several standard operations; check the runtime folder for platform-specific behavior.
+
+| Function | Derive | Description |
+| :--- | :--- | :--- |
+| `say(fmt, ...)` | `io` | Formatted output. |
+| `alloc(size)` | `memory` | Allocate memory (returns `u8[]`). |
+| `free(ptr)` | `memory` | Free memory. |
+| `copy(src)` | `memory` | Deep copy a fat pointer. |
+| `panic(msg)` | - | Crash with message. |
+| `assert(cond, msg)` | - | Panic if false. |
+| `len(arr)` | - | Get array length. |
+| `ord(str)` | - | First char code. |
+| `chr(code)` | - | Code to string. |
+| `float_to_int(f)` | - | Cast. |
+| `int_to_float(i)` | - | Cast. |
+
+## 7. ABI & Calling Convention
+
+*   **Linux**: System V AMD64 ABI (RDI, RSI, RDX, RCX, R8, R9).
+*   **Windows**: Microsoft x64 ABI (RCX, RDX, R8, R9 + Shadow Space).
+*   **Fat Pointers**: Passed as two separate arguments (pointer, length) or returned in `rax` (ptr) and `rdx` (len).
+*   **Error Unions**: Returned in `rax` (value) and `rdx` (error flag).
*   **Error Unions**: Returned in `rax` (value) and `rdx` (error flag).

## Appendix — Expanded Reference (merged from legacy guide)

This appendix expands the reference with additional examples, operator details, CLI usage, and standard-library module lists from the older comprehensive guide. It avoids repeating sections already covered above; read the prior sections first for core semantics.

Operators (detailed)
- Arithmetic: `+ - * / %` (integer `%` is remainder; decimal `%` calls `fmod`)
- Comparison: `== != < > <= >=`
- Logical: `&& || !`
- Bitwise: `& | ^ << >>`
- Compound assignments: `+= -= *= /= %=`
- Increment/Decrement: prefix `++`, `--` (postfix not supported)

Operator precedence (high → low):
1. Calls, indexing, field access: `() [] .`
2. Unary: `! ++ --`
3. Multiplicative: `* / %`
4. Additive: `+ -`
5. Relational: `< > <= >=`
6. Equality: `== !=`
7. Bitwise AND: `&`
8. Bitwise OR/XOR: `^ |`
9. Logical AND: `&&`
10. Logical OR: `||`
11. Assignment: `=`, `+=`, ...

Standard library modules (expanded list)
- `#derive <io>` — `say`, formatted I/O helpers
- `#derive <memory>` — `alloc`, `free`, `copy`
- `#derive <file>` — open/read/write helpers
- `#derive <math>` — `sqrt`, `fmod`, `sin`, `cos`, `pow`
- `#derive <string>` — string helpers (wrappers over runtime)
- `#derive <chronos>` — time utilities
- `#derive <sys>` — low-level platform bridges
- `#derive <net>` — networking helpers

Examples (selected)
- Factorial
```cup
int64: factorial(int64: n) {
	if (n <= 1) return 1;
	return n * factorial(n - 1);
}

int64: start() {
	say("5! = %d\n", factorial(5));
	return 0;
}
```

- Array sum
```cup
#derive <memory>

int64: sum_array(int64[]: arr) {
	int64: i = 0; int64: sum = 0;
	while (i < len(arr)) { sum += arr[i]; ++i; }
	return sum;
}
```

CLI & build notes
- Build manager entrypoint: `cup build <source> <output>` — the manager auto-includes runtime modules required by `#derive` directives.
- Linking: decimal `%` uses `fmod` — ensure math lib is linked on POSIX (`-lm`) or use the runtime bridge on Windows.

Compiler internals & troubleshooting
- Parser: `src/parser.cpp` — `#derive` is parsed as a directive token (see lexer).
- Codegen: `src/codegen.cpp` — many intrinsics were moved to `lib/cup/runtime/`; `require_derive()` gates calls.
- Common build issue: missing runtime derive files — ensure `lib/cup/runtime/<name>.cup` exists for every `#derive <name>` used.

If you want, I can now:
- Merge more example files from `test/` into this doc or add a dedicated `EXAMPLES.md`.
- Update the build manager to auto-add `-lm` on POSIX targets when `math` is required.

*** End Appendix ***


